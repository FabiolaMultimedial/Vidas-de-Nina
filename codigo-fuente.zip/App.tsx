// tslint:disable
/* eslint-disable */
import {
  Activity,
  ArrowLeft,
  BookOpen,
  Camera,
  Check,
  Compass,
  Dices,
  Heart,
  Home,
  Menu,
  Play,
  RotateCw,
  Share2,
  Sparkles,
  Trophy,
  Volume2,
  VolumeX,
  X,
  Zap,
} from 'lucide-react';
import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {BOARD_TILES} from './boardData';
import {getConfig} from './constants';
import {Dice3DHandle} from './Dice3D';
import {ALL_ENDINGS, determineEnding, pickClosingPhrase} from './endingsData';
import {GAME_EVENTS} from './eventsData';
import {Game} from './Game';
import {NinaPreview3D} from './NinaPreview3D';
import {getSavedUniverses, saveUniverseResult} from './savedUniverses';
import {
  BoardEvent,
  DecisionOption,
  EndingUniverse,
  NinaStats,
  NinaVisualConfig,
  SavedUniverse,
} from './types';
import BackgroundMusic from './utils/BackgroundMusic';
import {
  gameAudio,
  GameState,
  MenuOverlay,
  useAutoFocus,
  useIsMobile,
} from './utils/helper';
import {
  usePlayground,
  usePlaygroundGameLifecycle,
} from './utils/usePlayground';

interface CustomWindow extends Window {
  canHandleBackKey?: boolean;
}

export default function App() {
  const {sdk} = usePlayground();
  const isMobile = useIsMobile();

  // Primary Game State Machine
  const [gameState, setGameState] = useState<GameState>({
    status: 'START',
    score: 0,
    level: 1,
    moves: 0,
  });

  // Nina's board tracking
  const [currentTileIndex, setCurrentTileIndex] = useState(1);
  const [isHopping, setIsHopping] = useState(false);
  const [hopPath, setHopPath] = useState<number[]>([1]);
  const [hopProgress, setHopProgress] = useState(0);

  // Nina's core Life variables (Money, Happiness, Energy [5 hearts], Relationships, Career, Adventures)
  const [ninaStats, setNinaStats] = useState<NinaStats>({
    money: 1000,
    happiness: 65,
    energy: 4, // 1 to 5 hearts
    career: 20,
    relationships: 30,
    adventures: 15,
  });

  // Decisions memory and story chronicle
  const [historyTags, setHistoryTags] = useState<string[]>([]);
  const [storyTimeline, setStoryTimeline] = useState<string[]>([]);
  const [seenEventIds, setSeenEventIds] = useState<string[]>([]);

  // Active decision modal
  const [currentEvent, setCurrentEvent] = useState<BoardEvent | null>(null);

  // Nina's visual appearance
  const [ninaVisual, setNinaVisual] = useState<NinaVisualConfig>({
    skinColor: '#d4a373',
    hairColor: '#382216',
    outfitColor: '#ec4899',
    pantsColor: '#1e3a8a',
    accessory: 'none',
    auraColor: '#f472b6',
  });

  // Grand Finale & Ending
  const [endingRevealed, setEndingRevealed] = useState<EndingUniverse | null>(null);
  const [isEndPortalActive, setIsEndPortalActive] = useState(false);
  const [isRevealAnimating, setIsRevealAnimating] = useState(false);

  // Screenshot Clean Share Mode
  const [isScreenshotMode, setIsScreenshotMode] = useState(false);

  // Gallery & Dialog Overlays
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const [selectedGalleryUniverse, setSelectedGalleryUniverse] = useState<SavedUniverse | null>(null);
  const [isGameMenuOpen, setIsGameMenuOpen] = useState(false);
  const [isHowToPlayOpen, setIsHowToPlayOpen] = useState(false);

  // Audio toggles
  const [isMusicMuted, setIsMusicMuted] = useState(false);
  const [isSfxMuted, setIsSfxMuted] = useState(false);

  // Feedback Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Dice ref
  const diceRef = useRef<Dice3DHandle>(null);
  const isRollingRef = useRef(false);

  // Auto-focus buttons
  const startBtnRef = useAutoFocus<HTMLButtonElement>(gameState.status === 'START');
  const playAgainBtnRef = useAutoFocus<HTMLButtonElement>(gameState.status === 'VICTORY');

  // SDK Lifecycle hook
  usePlaygroundGameLifecycle(gameState, sdk);

  useEffect(() => {
    (window as CustomWindow).canHandleBackKey = ['PLAYING', 'PAUSED'].includes(
      gameState.status,
    );
  }, [gameState.status]);

  // Show toast notification
  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  }, []);

  // Update Nina's 3D visual appearance dynamically based on choices
  const updateNinaVisual = useCallback(
    (stats: NinaStats, tags: string[]) => {
      let outfit = '#ec4899';
      let pants = '#1e3a8a';
      let acc: NinaVisualConfig['accessory'] = 'none';
      let aura = '#f472b6';

      if (tags.includes('cat_queen') || tags.includes('first_cat')) {
        acc = 'cat';
        outfit = '#e879f9';
        pants = '#86198f';
        aura = '#f0abfc';
      } else if (tags.includes('alpaca_dream') || tags.includes('alpaca_farm_owner')) {
        acc = 'scarf';
        outfit = '#34d399';
        pants = '#065f46';
        aura = '#6ee7b7';
      } else if (tags.includes('wanderlust_init') || stats.adventures >= 50) {
        acc = 'backpack';
        outfit = '#38bdf8';
        pants = '#0369a1';
        aura = '#7dd3fc';
      } else if (tags.includes('viral_celebrity')) {
        acc = 'sunglasses';
        outfit = '#fb923c';
        pants = '#9a3412';
        aura = '#fdba74';
      } else if (tags.includes('master_chef') || tags.includes('secret_supper')) {
        acc = 'chef';
        outfit = '#fb7185';
        pants = '#881337';
        aura = '#fecdd3';
      } else if (tags.includes('ultra_rich') || stats.money >= 2400) {
        acc = 'crown';
        outfit = '#fbbf24';
        pants = '#78350f';
        aura = '#fef08a';
      } else if (tags.includes('tech_savvy') || stats.career >= 60) {
        acc = 'glasses';
        outfit = '#a855f7';
        pants = '#581c87';
        aura = '#d8b4fe';
      } else if (tags.includes('ocean_life') || tags.includes('sea_captain')) {
        acc = 'hat';
        outfit = '#0284c7';
        pants = '#0f172a';
        aura = '#38bdf8';
      }

      setNinaVisual({
        skinColor: '#d4a373',
        hairColor: '#382216',
        outfitColor: outfit,
        pantsColor: pants,
        accessory: acc,
        auraColor: aura,
      });
    },
    [],
  );

  // Initialize fresh game run
  const initGame = useCallback(() => {
    gameAudio.playCrispClick();
    setCurrentTileIndex(1);
    setIsHopping(false);
    setHopPath([1]);
    setHopProgress(0);
    setNinaStats({
      money: getConfig('startingMoney'),
      happiness: getConfig('startingHappiness'),
      energy: 4,
      career: 20,
      relationships: 30,
      adventures: 15,
    });
    setHistoryTags([]);
    setStoryTimeline([]);
    setSeenEventIds([]);
    setCurrentEvent(null);
    setEndingRevealed(null);
    setIsEndPortalActive(false);
    setIsRevealAnimating(false);
    setIsScreenshotMode(false);
    setIsGalleryOpen(false);
    setIsGameMenuOpen(false);
    setSelectedGalleryUniverse(null);

    updateNinaVisual(
      {
        money: getConfig('startingMoney'),
        happiness: getConfig('startingHappiness'),
        energy: 4,
        career: 20,
        relationships: 30,
        adventures: 15,
      },
      [],
    );

    setGameState({
      status: 'PLAYING',
      score: 100,
      level: 1,
      moves: 0,
    });

    if (sdk) {
      sdk.startGame();
    }
  }, [sdk, updateNinaVisual]);

  // Animation callbacks must read the latest choices and stats, not the first render.
  const arrivalHandlers = useRef<{
    destination: () => void;
    event: (tile: number, stage: 1 | 2 | 3 | 4 | 5) => void;
  } | null>(null);

  // Execute gentle, smooth hopping between tiles with low jumps
  const animateHops = useCallback(
    (startTile: number, targetTile: number) => {
      const stepsCount = targetTile - startTile;
      if (stepsCount <= 0) return;

      const pathIndices: number[] = [];
      for (let s = startTile; s <= targetTile; s++) {
        pathIndices.push(s);
      }

      setIsHopping(true);
      let stepIdx = 0;

      const runNextStep = () => {
        if (stepIdx >= pathIndices.length - 1) {
          setIsHopping(false);
          setCurrentTileIndex(targetTile);
          gameAudio.playJumpLandingThud();

          const currentStage = Math.min(
            5,
            Math.floor(((targetTile - 1) / 50) * 5) + 1,
          ) as 1 | 2 | 3 | 4 | 5;

          setGameState((prev) => ({
            ...prev,
            score: prev.score + targetTile * 10,
            level: currentStage,
          }));

          if (targetTile >= 50) {
            arrivalHandlers.current?.destination();
          } else {
            arrivalHandlers.current?.event(targetTile, currentStage);
          }
          return;
        }

        const currentPair = [pathIndices[stepIdx], pathIndices[stepIdx + 1]];
        // Reiniciar el progreso junto con el tramo: si no, Nina se adelanta un instante y retrocede.
        setHopProgress(0);
        setHopPath(currentPair);
        gameAudio.playRetroJump();

        // 320ms per tile hop for calm, smooth motion
        const duration = 320;
        const startTime = performance.now();

        const stepFrame = (now: number) => {
          const elapsed = now - startTime;
          const prog = Math.min(1, elapsed / duration);
          setHopProgress(prog);

          if (prog < 1) {
            requestAnimationFrame(stepFrame);
          } else {
            stepIdx++;
            setCurrentTileIndex(pathIndices[stepIdx]);
            runNextStep();
          }
        };

        requestAnimationFrame(stepFrame);
      };

      runNextStep();
    },
    [],
  );

  // Trigger Event on Tile Arrival with smart tag-based branching
  const triggerTileEvent = useCallback(
    (tileIdx: number, stage: 1 | 2 | 3 | 4 | 5) => {
      let stageEvents = GAME_EVENTS.filter((e) => e.stage === stage);

      stageEvents = stageEvents.filter((e) => {
        if (e.requiresTag && !historyTags.includes(e.requiresTag)) return false;
        if (e.excludesTag && historyTags.includes(e.excludesTag)) return false;
        return true;
      });

      const unplayed = stageEvents.filter((e) => !seenEventIds.includes(e.id));
      const pool = unplayed;

      const picked = pool[Math.floor(Math.random() * pool.length)];
      if (picked) {
        setSeenEventIds((prev) => [...prev, picked.id]);
        setCurrentEvent(picked);
        gameAudio.playCrispClick();
      }
    },
    [seenEventIds, historyTags],
  );

  // Handle Arrival at Tile 50: The Grand Finale
  const handleDestinationReached = useCallback(() => {
    setIsEndPortalActive(true);
    setIsRevealAnimating(true);
    gameAudio.playVictoryFanfare();

    // Determine ending strictly according to accumulated state and choices
    let lastEndingId: string | undefined;
    try {
      lastEndingId = localStorage.getItem('nina_last_ending') || undefined;
    } catch {}
    const finalEnding = {...determineEnding(ninaStats, historyTags, lastEndingId), quote: pickClosingPhrase()};
    try {
      localStorage.setItem('nina_last_ending', finalEnding.id);
    } catch {}
    setEndingRevealed(finalEnding);

    saveUniverseResult(finalEnding, ninaStats, storyTimeline);

    setTimeout(() => {
      setIsRevealAnimating(false);
      setGameState((prev) => ({
        ...prev,
        status: 'VICTORY',
        score: prev.score + 5000 + ninaStats.money + ninaStats.happiness * 20,
      }));
    }, 2200);
  }, [ninaStats, historyTags, storyTimeline]);

  arrivalHandlers.current = {destination: handleDestinationReached, event: triggerTileEvent};

  // Roll the 3D physical dice
  const handleRollDice = useCallback(() => {
    if (
      isHopping ||
      currentEvent ||
      isEndPortalActive ||
      gameState.status !== 'PLAYING'
    ) {
      return;
    }

    const remaining = 50 - currentTileIndex;
    if (remaining <= 0) return;

    const diceRoll = Math.min(Math.floor(Math.random() * 6) + 1, remaining);

    isRollingRef.current = true;
    if (diceRef.current) {
      diceRef.current.roll(diceRoll);
    }
  }, [currentTileIndex, isHopping, currentEvent, isEndPortalActive, gameState.status]);

  // Callback when 3D Dice finishes rolling physically
  const handleDiceRollComplete = useCallback(
    (diceValue: number) => {
      isRollingRef.current = false;
      setGameState((prev) => ({
        ...prev,
        moves: (prev.moves || 0) + 1,
      }));

      const targetTile = Math.min(50, currentTileIndex + diceValue);
      animateHops(currentTileIndex, targetTile);
    },
    [currentTileIndex, animateHops],
  );

  // Player chooses an option on the Decision Card: IMMEDIATE & PERSISTENT STATS UPDATE
  const handleChooseOption = useCallback(
    (option: DecisionOption) => {
      if (!currentEvent) return;

      gameAudio.playConfirmSelect();
      const eff = option.effect;

      // Update the 6 core stats immediately: Money, Happiness, Energy (1-5 hearts), Relationships, Career, Adventures
      const newEnergy = Math.max(1, Math.min(5, ninaStats.energy + (eff.energy !== undefined ? eff.energy : 0)));

      const updatedStats: NinaStats = {
        money: Math.max(0, ninaStats.money + (eff.money || 0)),
        happiness: Math.max(0, Math.min(100, ninaStats.happiness + (eff.happiness || 0))),
        energy: newEnergy,
        career: Math.max(0, Math.min(100, ninaStats.career + (eff.career || 0))),
        relationships: Math.max(0, Math.min(100, ninaStats.relationships + (eff.relationships || 0))),
        adventures: Math.max(0, Math.min(100, ninaStats.adventures + (eff.adventures || 0))),
      };

      setNinaStats(updatedStats);

      const newTags = [...historyTags];
      if (eff.tag && !newTags.includes(eff.tag)) {
        newTags.push(eff.tag);
        setHistoryTags(newTags);
      }

      if (eff.log) {
        setStoryTimeline((prev) => [...prev, eff.log!]);
      }

      if (eff.money && eff.money > 0) {
        gameAudio.playCoinPickup();
      }

      updateNinaVisual(updatedStats, newTags);
      setCurrentEvent(null);
    },
    [currentEvent, ninaStats, historyTags, updateNinaVisual],
  );

  // Keyboard shortcut Space to roll dice, Escape to toggle pause
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (isScreenshotMode) {
          setIsScreenshotMode(false);
          return;
        }
        if (isHowToPlayOpen) {
          setIsHowToPlayOpen(false);
          return;
        }
        if (isGalleryOpen) {
          setIsGalleryOpen(false);
          setSelectedGalleryUniverse(null);
          return;
        }
        if (gameState.status === 'PLAYING') {
          setIsGameMenuOpen((prev) => !prev);
        }
      } else if (e.key === ' ' || e.key === 'Enter') {
        if (gameState.status === 'PLAYING' && !currentEvent && !isHopping && !isEndPortalActive) {
          e.preventDefault();
          handleRollDice();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    gameState.status,
    currentEvent,
    isHopping,
    isEndPortalActive,
    isGameMenuOpen,
    isHowToPlayOpen,
    isGalleryOpen,
    isScreenshotMode,
    handleRollDice,
  ]);

  // Audio toggles
  const handleToggleMusic = () => {
    setIsMusicMuted((prev) => !prev);
  };

  const handleToggleSfx = () => {
    const newMuted = gameAudio.toggleMute();
    setIsSfxMuted(newMuted);
  };

  const currentStageName = useMemo(() => {
    const stage = Math.min(5, Math.floor(((currentTileIndex - 1) / 50) * 5) + 1);
    switch (stage) {
      case 1:
        return 'Los veintitantos';
      case 2:
        return 'La vida adulta';
      case 3:
        return 'Decisiones cuestionables';
      case 4:
        return 'Giros inesperados';
      case 5:
        return 'El destino final';
      default:
        return 'Los veintitantos';
    }
  }, [currentTileIndex]);

  const savedUniverses = useMemo(() => getSavedUniverses(), [isGalleryOpen, gameState.status]);

  const formattedBiography = useMemo(() => {
    if (!endingRevealed) return '';
    if (storyTimeline.length === 0) return endingRevealed.summary;
    return storyTimeline.join('. ') + '.';
  }, [endingRevealed, storyTimeline]);

  return (
    <div className="fixed inset-0 overflow-hidden touch-none flex flex-col bg-zinc-950 text-white font-sans select-none">
      {/* Background Music Player */}
      <BackgroundMusic
        url={getConfig('backgroundMusicUrl')}
        isPlaying={['PLAYING', 'PAUSED', 'LEVEL_COMPLETE'].includes(gameState.status) && !isEndPortalActive}
        isMuted={isMusicMuted}
      />

      {/* ======================================================== */}
      {/* HUD (Top Safe Zone with Stage & The 6 Real Stats)        */}
      {/* ======================================================== */}
      {gameState.status === 'PLAYING' && !endingRevealed && (
        <header className="w-full bg-slate-900/90 backdrop-blur-md border-b border-pink-500/20 px-3 py-2 z-20 shrink-0 flex flex-wrap items-center justify-between gap-2">
          {/* Life Stage & Tile Counter */}
          <div className="flex items-center gap-2">
            <span className="bg-pink-600 text-white text-[11px] font-extrabold px-2.5 py-0.5 rounded-full shadow-sm">
              CASILLA {currentTileIndex} / 50
            </span>
            <span className="text-pink-200 text-xs font-medium hidden sm:inline">
              Etapa: {currentStageName}
            </span>
          </div>

          {/* Core Life Variables: Money, Happiness, Energy (5 Hearts), Career, Relationships, Adventures */}
          <div className="flex items-center gap-2 text-xs flex-wrap">
            {/* Dinero */}
            <div className="flex items-center gap-1 bg-slate-800/80 px-2 py-0.5 rounded-md border border-slate-700">
              <span className="text-yellow-400 font-bold">$</span>
              <span className="font-semibold text-yellow-200">
                {ninaStats.money.toLocaleString()}
              </span>
            </div>

            {/* Felicidad */}
            <div className="flex items-center gap-1 bg-slate-800/80 px-2 py-0.5 rounded-md border border-slate-700">
              <Sparkles size={13} className="text-pink-400" />
              <span className="font-semibold text-pink-200">
                {ninaStats.happiness}/100
              </span>
            </div>

            {/* Energía (Cinco Corazones) */}
            <div className="flex items-center gap-0.5 bg-slate-800/80 px-2 py-0.5 rounded-md border border-slate-700">
              <span className="text-[10px] text-rose-300 font-bold mr-0.5 hidden xs:inline">ENERGÍA:</span>
              {[1, 2, 3, 4, 5].map((h) => (
                <Heart
                  key={h}
                  size={12}
                  className={h <= ninaStats.energy ? 'text-rose-500 fill-rose-500' : 'text-slate-600'}
                />
              ))}
            </div>

            {/* Carrera */}
            <div className="flex items-center gap-1 bg-slate-800/80 px-2 py-0.5 rounded-md border border-slate-700 hidden sm:flex">
              <span className="text-[10px] text-purple-300 font-bold">CARRERA:</span>
              <span className="font-semibold text-purple-200">{ninaStats.career}</span>
            </div>

            {/* Aventura */}
            <div className="flex items-center gap-1 bg-slate-800/80 px-2 py-0.5 rounded-md border border-slate-700 hidden md:flex">
              <Compass size={13} className="text-cyan-400" />
              <span className="font-semibold text-cyan-200">{ninaStats.adventures}</span>
            </div>
          </div>

          {/* Reserved Top-Right Menu Button */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => {
                gameAudio.playCrispClick();
                setIsGameMenuOpen(true);
              }}
              aria-label="Abrir Menú"
              className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-pink-300 border border-slate-700 rounded-lg p-1.5 transition flex items-center gap-1 min-w-[44px] min-h-[44px] justify-center">
              <Menu size={18} />
              <span className="text-xs font-bold hidden md:inline">MENÚ</span>
            </button>
          </div>
        </header>
      )}

      {/* ======================================================== */}
      {/* 3D WEBGL CANVAS WRAPPER                                  */}
      {/* ======================================================== */}
      <div className="flex-1 w-full min-h-0 relative flex items-center justify-center">
        <Game
          gameState={gameState}
          setGameState={setGameState}
          currentTileIndex={currentTileIndex}
          isHopping={isHopping}
          hopPath={hopPath}
          hopProgress={hopProgress}
          ninaVisual={ninaVisual}
          diceRef={diceRef}
          onDiceRollComplete={handleDiceRollComplete}
          endingRevealed={endingRevealed}
          isEndPortalActive={isEndPortalActive}
          ninaStats={ninaStats}
        />

        {/* Floating Bottom Control Bar during gameplay */}
        {gameState.status === 'PLAYING' && !currentEvent && !endingRevealed && !isRevealAnimating && (
          <div className="absolute bottom-6 left-0 right-0 flex justify-center items-center pointer-events-none z-20 px-4">
            <div className="pointer-events-auto">
              <button
                onClick={handleRollDice}
                disabled={isHopping}
                className="bg-gradient-to-r from-pink-500 via-rose-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 active:scale-95 disabled:opacity-50 text-white font-black text-base md:text-lg px-8 py-3.5 rounded-full shadow-2xl border-2 border-white/40 flex items-center gap-3 transition-all transform min-w-[200px] justify-center">
                <Dices size={24} className="animate-spin-slow" />
                <span>{isHopping ? 'AVANZANDO...' : 'TIRAR DADO'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Portal Dramatic Revelation Screen Shimmer */}
        {isRevealAnimating && (
          <div className="absolute inset-0 bg-slate-950/75 backdrop-blur-md flex flex-col items-center justify-center z-30 transition-opacity animate-fade-in p-6 text-center">
            <Sparkles size={64} className="text-yellow-400 animate-spin-slow mb-4" />
            <h2 className="text-2xl md:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-pink-400 to-purple-300 mb-2">
              ¡REVELANDO EL DESTINO DE NINA!
            </h2>
            <p className="text-pink-200 text-sm md:text-base max-w-sm">
              El portal dimensional se abre... Tus decisiones forjaron una vida única e irrepetible.
            </p>
          </div>
        )}
      </div>

      {/* ======================================================== */}
      {/* DECISION & EVENT MODAL                                   */}
      {/* ======================================================== */}
      {currentEvent && (
        <MenuOverlay tone="neutral" zIndex={35}>
          <div className="w-full max-w-md bg-slate-900 border-2 border-pink-500/50 rounded-2xl p-5 shadow-2xl flex flex-col animate-scale-up">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-pink-400 bg-pink-950/60 border border-pink-800 px-2.5 py-0.5 rounded-full">
                Etapa {currentEvent.stage}: {currentStageName}
              </span>
              <span className="text-xs text-slate-400 font-medium">
                Casilla {currentTileIndex}
              </span>
            </div>

            <h2 className="text-lg md:text-xl font-black text-white leading-tight mb-1">
              {currentEvent.title}
            </h2>
            {currentEvent.subtitle && (
              <p className="text-xs text-pink-300 font-semibold mb-3">
                {currentEvent.subtitle}
              </p>
            )}

            <p className="text-sm text-slate-300 bg-slate-800/80 p-3 rounded-xl border border-slate-700/60 mb-4 leading-relaxed">
              {currentEvent.situation}
            </p>

            <div className="flex flex-col gap-2.5">
              {currentEvent.options.map((opt) => (
                <button
                  key={opt.key}
                  onClick={() => handleChooseOption(opt)}
                  className="w-full bg-slate-800 hover:bg-pink-950/40 hover:border-pink-500 active:scale-[0.98] border border-slate-700 p-3 rounded-xl text-left transition flex flex-col gap-1 group min-h-[52px]">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-pink-500 text-white font-black text-xs flex items-center justify-center shrink-0 group-hover:bg-pink-400">
                      {opt.key}
                    </span>
                    <span className="font-bold text-sm text-white group-hover:text-pink-200">
                      {opt.label}
                    </span>
                  </div>
                  <span className="text-xs text-slate-400 pl-8">
                    {opt.description}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </MenuOverlay>
      )}

      {/* ======================================================== */}
      {/* LA GRAN PANTALLA FINAL — MI UNIVERSO                     */}
      {/* Completely Unclipped, Scrollable, Full Texts             */}
      {/* ======================================================== */}
      {gameState.status === 'VICTORY' && endingRevealed && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 backdrop-blur-md p-4 sm:p-6 flex flex-col items-center">
          <div className="w-full max-w-lg my-auto flex flex-col items-center gap-4 py-4 animate-scale-up">
            <div
              id="universe-card-preview"
              className="w-full rounded-3xl p-5 md:p-6 shadow-2xl border-4 text-slate-900 relative flex flex-col items-center"
              style={{
                background: `linear-gradient(135deg, ${endingRevealed.bgGradient[0]}, ${endingRevealed.bgGradient[1]})`,
                borderColor: endingRevealed.accentColor,
              }}>
              <div className="absolute top-3 left-4 text-white/50 text-xl font-bold">✦</div>
              <div className="absolute top-6 right-5 text-white/60 text-lg font-bold">★</div>
              <div className="absolute bottom-4 left-6 text-white/50 text-xl font-bold">★</div>
              <div className="absolute bottom-5 right-5 text-white/60 text-lg font-bold">✦</div>

              <span className="text-xs font-black tracking-widest text-pink-700 uppercase mb-1">
                LAS MIL VIDAS DE NINA
              </span>

              <span
                className="px-4 py-1 rounded-full text-white font-extrabold text-xs tracking-wider mb-2 shadow-sm"
                style={{backgroundColor: endingRevealed.accentColor}}>
                {endingRevealed.universeCode} · {endingRevealed.shortName}
              </span>

              <h1 className="text-2xl md:text-3xl font-black text-center text-slate-900 leading-tight mb-3 px-2 break-words">
                {endingRevealed.title}
              </h1>

              <div className="w-full mb-3">
                <NinaPreview3D ending={endingRevealed} visual={ninaVisual} />
              </div>

              <div className="w-full bg-white/90 rounded-2xl p-3 shadow-inner border border-white mb-3 text-center">
                <p className="text-xs md:text-sm italic font-medium text-slate-700 px-2 leading-relaxed break-words">
                  “{endingRevealed.quote}”
                </p>
              </div>

              <div className="w-full flex flex-col gap-2 mb-3 text-left">
                <div className="bg-white/90 p-3 rounded-2xl border border-white/80 shadow-sm flex flex-col gap-0.5">
                  <span className="text-[11px] font-black text-sky-800 uppercase tracking-wider">
                    Profesión
                  </span>
                  <span className="text-sm font-bold text-slate-900 leading-snug break-words">
                    {endingRevealed.profession}
                  </span>
                </div>

                <div className="bg-white/90 p-3 rounded-2xl border border-white/80 shadow-sm flex flex-col gap-0.5">
                  <span className="text-[11px] font-black text-emerald-800 uppercase tracking-wider">
                    Fortuna
                  </span>
                  <span className="text-sm font-bold text-emerald-800 leading-snug break-words">
                    {endingRevealed.wealthLevel} (${ninaStats.money.toLocaleString()})
                  </span>
                </div>

                <div className="bg-white/90 p-3 rounded-2xl border border-white/80 shadow-sm flex flex-col gap-0.5">
                  <span className="text-[11px] font-black text-purple-800 uppercase tracking-wider">
                    Estilo de vida
                  </span>
                  <span className="text-sm font-bold text-slate-900 leading-snug break-words">
                    {endingRevealed.lifestyle}
                  </span>
                </div>

                <div className="bg-white/90 p-3 rounded-2xl border border-white/80 shadow-sm flex flex-col gap-0.5">
                  <span className="text-[11px] font-black text-rose-800 uppercase tracking-wider">
                    Felicidad y Energía
                  </span>
                  <div className="flex items-center justify-between text-sm font-bold text-rose-700">
                    <span>Felicidad: {ninaStats.happiness}/100</span>
                    <span className="flex items-center gap-0.5">
                      {[1, 2, 3, 4, 5].map((h) => (
                        <Heart
                          key={h}
                          size={13}
                          className={h <= ninaStats.energy ? 'text-rose-500 fill-rose-500' : 'text-slate-300'}
                        />
                      ))}
                    </span>
                  </div>
                </div>
              </div>

              <div className="w-full bg-white/85 p-4 rounded-2xl border border-white/70 text-left mb-3">
                <span className="block text-[11px] font-black text-slate-700 uppercase tracking-wider mb-1.5">
                  Su Historia en este Universo:
                </span>
                <p className="text-xs md:text-sm text-slate-800 leading-relaxed break-words">
                  {formattedBiography}
                </p>
              </div>

              <p
                className="text-xs font-bold text-center tracking-tight"
                style={{color: endingRevealed.accentColor}}>
                ¿Qué vida le tocaría a tu Nina?
              </p>
            </div>

            <div className="w-full flex flex-col gap-2.5">
              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsScreenshotMode(true);
                }}
                className="w-full bg-pink-600 hover:bg-pink-500 active:scale-95 text-white font-bold text-sm md:text-base py-3.5 rounded-2xl shadow-lg flex items-center justify-center gap-2 transition min-h-[50px]">
                <Share2 size={20} />
                <span>COMPARTIR MI UNIVERSO</span>
              </button>

              <button
                ref={playAgainBtnRef}
                autoFocus
                onClick={initGame}
                className="w-full bg-white text-slate-900 hover:bg-yellow-400 active:scale-95 font-black text-sm md:text-base py-3.5 rounded-2xl shadow-lg flex items-center justify-center gap-2 transition min-h-[50px]">
                <RotateCw size={20} />
                <span>VIVIR OTRA VIDA</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SCREENSHOT CLEAN VIEW FOR SHARING                        */}
      {/* ======================================================== */}
      {isScreenshotMode && endingRevealed && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950 p-4 sm:p-6 flex flex-col items-center">
          <div className="w-full max-w-lg flex items-center justify-between py-2 mb-2">
            <button
              onClick={() => setIsScreenshotMode(false)}
              className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-pink-300 px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border border-slate-700 min-h-[44px]">
              <ArrowLeft size={16} />
              <span>Volver</span>
            </button>
            <span className="text-xs font-bold text-pink-300 flex items-center gap-1">
              <Camera size={15} />
              <span>¡Haz una captura de pantalla y comparte tu universo!</span>
            </span>
          </div>

          <div
            className="w-full max-w-lg rounded-3xl p-5 md:p-6 shadow-2xl border-4 text-slate-900 relative flex flex-col items-center mb-6"
            style={{
              background: `linear-gradient(135deg, ${endingRevealed.bgGradient[0]}, ${endingRevealed.bgGradient[1]})`,
              borderColor: endingRevealed.accentColor,
            }}>
            <span className="text-xs font-black tracking-widest text-pink-700 uppercase mb-1">
              LAS MIL VIDAS DE NINA
            </span>

            <span
              className="px-4 py-1 rounded-full text-white font-extrabold text-xs tracking-wider mb-2 shadow-sm"
              style={{backgroundColor: endingRevealed.accentColor}}>
              {endingRevealed.universeCode} · {endingRevealed.shortName}
            </span>

            <h1 className="text-2xl md:text-3xl font-black text-center text-slate-900 leading-tight mb-3 px-2 break-words">
              {endingRevealed.title}
            </h1>

            <div className="w-full mb-3">
              <NinaPreview3D ending={endingRevealed} visual={ninaVisual} />
            </div>

            <div className="w-full bg-white/90 rounded-2xl p-3 shadow-inner border border-white mb-3 text-center">
              <p className="text-xs md:text-sm italic font-medium text-slate-700 px-2 leading-relaxed break-words">
                “{endingRevealed.quote}”
              </p>
            </div>

            <div className="w-full flex flex-col gap-2 mb-3 text-left">
              <div className="bg-white/90 p-3 rounded-2xl border border-white/80 shadow-sm flex flex-col gap-0.5">
                <span className="text-[11px] font-black text-sky-800 uppercase tracking-wider">
                  Profesión
                </span>
                <span className="text-sm font-bold text-slate-900 leading-snug break-words">
                  {endingRevealed.profession}
                </span>
              </div>

              <div className="bg-white/90 p-3 rounded-2xl border border-white/80 shadow-sm flex flex-col gap-0.5">
                <span className="text-[11px] font-black text-emerald-800 uppercase tracking-wider">
                  Fortuna
                </span>
                <span className="text-sm font-bold text-emerald-800 leading-snug break-words">
                  {endingRevealed.wealthLevel} (${ninaStats.money.toLocaleString()})
                </span>
              </div>

              <div className="bg-white/90 p-3 rounded-2xl border border-white/80 shadow-sm flex flex-col gap-0.5">
                <span className="text-[11px] font-black text-purple-800 uppercase tracking-wider">
                  Estilo de vida
                </span>
                <span className="text-sm font-bold text-slate-900 leading-snug break-words">
                  {endingRevealed.lifestyle}
                </span>
              </div>

              <div className="bg-white/90 p-3 rounded-2xl border border-white/80 shadow-sm flex flex-col gap-0.5">
                <span className="text-[11px] font-black text-rose-800 uppercase tracking-wider">
                  Felicidad y Energía
                </span>
                <div className="flex items-center justify-between text-sm font-bold text-rose-700">
                  <span>Felicidad: {ninaStats.happiness}/100</span>
                  <span className="flex items-center gap-0.5">
                    {[1, 2, 3, 4, 5].map((h) => (
                      <Heart
                        key={h}
                        size={13}
                        className={h <= ninaStats.energy ? 'text-rose-500 fill-rose-500' : 'text-slate-300'}
                      />
                    ))}
                  </span>
                </div>
              </div>
            </div>

            <div className="w-full bg-white/85 p-4 rounded-2xl border border-white/70 text-left mb-3">
              <span className="block text-[11px] font-black text-slate-700 uppercase tracking-wider mb-1.5">
                Su Historia en este Universo:
              </span>
              <p className="text-xs md:text-sm text-slate-800 leading-relaxed break-words">
                {formattedBiography}
              </p>
            </div>

            <p
              className="text-xs font-bold text-center tracking-tight"
              style={{color: endingRevealed.accentColor}}>
              ¿Qué vida le tocaría a tu Nina?
            </p>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* START SCREEN                                             */}
      {/* ======================================================== */}
      {gameState.status === 'START' && (
        <MenuOverlay tone="neutral" zIndex={40}>
          <div className="bg-slate-900/95 border-2 border-pink-500/40 p-6 md:p-8 rounded-3xl shadow-2xl flex flex-col items-center w-full max-w-sm text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center shadow-lg mb-4">
              <Dices size={36} className="text-white" />
            </div>

            <h1 className="text-2xl md:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-rose-300 to-purple-400 mb-1 leading-tight">
              LAS MIL VIDAS DE NINA
            </h1>

            <p className="text-pink-300 text-xs md:text-sm font-bold tracking-wide mb-4">
              “Una Nina. Mil destinos posibles.”
            </p>

            <p className="text-slate-300 text-xs md:text-sm mb-6 leading-relaxed">
              ¿En qué universo terminará Nina esta vez? Tira el dado 3D, toma decisiones con consecuencias reales y forja su futuro.
            </p>

            <div className="w-full flex flex-col gap-3">
              <button
                ref={startBtnRef}
                autoFocus
                onClick={initGame}
                data-testid="start-button"
                className="w-full bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 hover:to-rose-500 active:scale-95 text-white py-3.5 rounded-full font-black text-base shadow-lg transition flex items-center justify-center gap-2 min-h-[48px]">
                <Play size={20} className="fill-white" />
                <span>JUGAR</span>
              </button>

              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsGalleryOpen(true);
                }}
                className="w-full bg-slate-800 hover:bg-slate-700 active:scale-95 text-pink-300 border border-slate-700 py-3 rounded-full font-bold text-sm transition flex items-center justify-center gap-2 min-h-[48px]">
                <Trophy size={18} />
                <span>MIS UNIVERSOS ({savedUniverses.length}/{ALL_ENDINGS.length})</span>
              </button>
            </div>
          </div>
        </MenuOverlay>
      )}

      {/* ======================================================== */}
      {/* GAME MENU OVERLAY (PAUSE)                                */}
      {/* ======================================================== */}
      {isGameMenuOpen && (
        <MenuOverlay tone="neutral" zIndex={45}>
          <div className="w-full max-w-sm bg-slate-900 border-2 border-slate-800 rounded-2xl p-6 shadow-2xl flex flex-col items-center">
            <h2 className="text-2xl font-black text-pink-400 mb-6 tracking-wide">
              MENÚ DE JUEGO
            </h2>

            <div className="w-full flex flex-col gap-3">
              <button
                autoFocus
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsGameMenuOpen(false);
                }}
                className="w-full bg-white text-slate-900 hover:bg-yellow-400 active:scale-95 font-bold py-3 rounded-xl transition flex items-center justify-center gap-2 min-h-[48px]">
                <Play size={18} className="fill-current" />
                <span>REANUDAR</span>
              </button>

              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsGalleryOpen(true);
                }}
                className="w-full bg-slate-800 hover:bg-slate-700 active:scale-95 text-white font-bold py-3 rounded-xl border border-slate-700 transition flex items-center justify-center gap-2 min-h-[48px]">
                <Trophy size={18} className="text-yellow-400" />
                <span>MIS UNIVERSOS ({savedUniverses.length})</span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleToggleMusic}
                  className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-white text-xs font-bold py-2.5 px-3 rounded-xl border border-slate-700 flex items-center justify-center gap-2 min-h-[48px]">
                  {isMusicMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                  <span>MÚSICA: {isMusicMuted ? 'OFF' : 'ON'}</span>
                </button>
                <button
                  onClick={handleToggleSfx}
                  className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-white text-xs font-bold py-2.5 px-3 rounded-xl border border-slate-700 flex items-center justify-center gap-2 min-h-[48px]">
                  {isSfxMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                  <span>SFX: {isSfxMuted ? 'OFF' : 'ON'}</span>
                </button>
              </div>

              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsHowToPlayOpen(true);
                }}
                className="w-full bg-slate-800 hover:bg-slate-700 active:scale-95 text-white font-bold py-3 rounded-xl border border-slate-700 transition flex items-center justify-center gap-2 min-h-[48px]">
                <BookOpen size={18} />
                <span>CÓMO JUGAR</span>
              </button>

              <button
                onClick={initGame}
                className="w-full bg-rose-900/60 hover:bg-rose-800/80 active:scale-95 text-rose-200 font-bold py-3 rounded-xl border border-rose-700/60 transition flex items-center justify-center gap-2 min-h-[48px]">
                <RotateCw size={18} />
                <span>REINICIAR PARTIDA</span>
              </button>
            </div>
          </div>
        </MenuOverlay>
      )}

      {/* ======================================================== */}
      {/* HOW TO PLAY OVERLAY                                      */}
      {/* ======================================================== */}
      {isHowToPlayOpen && (
        <MenuOverlay tone="neutral" zIndex={60}>
          <div className="w-full max-w-md bg-slate-900 border-2 border-slate-800 rounded-2xl p-6 shadow-2xl flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-black text-pink-400 flex items-center gap-2">
                <BookOpen size={20} />
                <span>CÓMO JUGAR</span>
              </h2>
              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsHowToPlayOpen(false);
                }}
                className="text-slate-400 hover:text-white p-1 rounded-lg">
                <X size={20} />
              </button>
            </div>

            <div className="space-y-3 text-xs md:text-sm text-slate-300 leading-relaxed overflow-y-auto max-h-[60vh] pr-1">
              <div className="bg-slate-800 p-3 rounded-xl border border-slate-700">
                <strong className="text-pink-300 block mb-1">1. Movimientos Suaves y Dado 3D</strong>
                Lanza el dado 3D. Nina avanzará suavemente con saltos bajos y una cámara isométrica estable.
              </div>
              <div className="bg-slate-800 p-3 rounded-xl border border-slate-700">
                <strong className="text-pink-300 block mb-1">2. Decisiones con Consecuencias Reales</strong>
                Tus elecciones modifican de inmediato Dinero, Felicidad, Energía (5 corazones), Carrera, Relaciones y Aventuras. Las decisiones más exigentes consumen energía, mientras que el descanso la restaura.
              </div>
              <div className="bg-slate-800 p-3 rounded-xl border border-slate-700">
                <strong className="text-pink-300 block mb-1">3. Destinos Verdaderamente Variados</strong>
                El final no es arbitrario: según tu saldo, nivel de energía, carrera y decisiones previas, desbloquearás trayectorias exitosas, bancarrotas con humor, santuarios campestres o vidas bohemias.
              </div>
            </div>

            <button
              onClick={() => {
                gameAudio.playCrispClick();
                setIsHowToPlayOpen(false);
              }}
              className="mt-5 w-full bg-pink-600 hover:bg-pink-500 active:scale-95 text-white font-bold py-3 rounded-xl transition min-h-[48px]">
              ENTENDIDO
            </button>
          </div>
        </MenuOverlay>
      )}

      {/* ======================================================== */}
      {/* MIS UNIVERSOS GALLERY                                    */}
      {/* ======================================================== */}
      {isGalleryOpen && (
        <MenuOverlay tone="neutral" zIndex={55}>
          <div className="w-full max-w-2xl bg-slate-900 border-2 border-slate-800 rounded-3xl p-5 md:p-6 shadow-2xl flex flex-col max-h-[85vh]">
            <div className="flex items-center justify-between mb-4 shrink-0">
              <div>
                <h2 className="text-xl md:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-purple-400">
                  MIS UNIVERSOS
                </h2>
                <p className="text-xs text-slate-400">
                  {savedUniverses.length} de {ALL_ENDINGS.length} vidas descubiertas
                </p>
              </div>
              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsGalleryOpen(false);
                  setSelectedGalleryUniverse(null);
                }}
                className="text-slate-400 hover:text-white p-2 min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg">
                <X size={24} />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 overflow-y-auto pr-1">
              {ALL_ENDINGS.map((ending) => {
                const unlocked = savedUniverses.find((u) => u.id === ending.id);

                return (
                  <div
                    key={ending.id}
                    className={`p-3.5 rounded-2xl border transition flex flex-col justify-between ${
                      unlocked
                        ? 'bg-slate-800/90 border-pink-500/40 hover:border-pink-400 shadow-md'
                        : 'bg-slate-900/60 border-slate-800 opacity-60'
                    }`}>
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span
                          className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                            unlocked ? 'bg-pink-600 text-white' : 'bg-slate-800 text-slate-400'
                          }`}>
                          {ending.universeCode} · {ending.shortName}
                        </span>
                        {unlocked && (
                          <span className="text-[10px] text-slate-400">{unlocked.date}</span>
                        )}
                      </div>

                      <h3 className="font-bold text-sm text-white leading-tight mb-1">
                        {unlocked ? ending.title : '??? Destino Desconocido'}
                      </h3>

                      <p className="text-xs text-slate-400 line-clamp-2">
                        {unlocked ? ending.quote : 'Toma decisiones diferentes en otra partida para descubrir este destino.'}
                      </p>
                    </div>

                    {unlocked && (
                      <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-700/60 text-xs text-pink-300 font-semibold">
                        <span>{unlocked.profession} · ${unlocked.fortune.toLocaleString()}</span>
                        <span className="flex items-center gap-0.5">
                          {[1, 2, 3, 4, 5].map((h) => (
                            <Heart
                              key={h}
                              size={10}
                              className={h <= (unlocked.energy || 3) ? 'text-rose-400 fill-rose-400' : 'text-slate-600'}
                            />
                          ))}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <button
              onClick={() => {
                gameAudio.playCrispClick();
                setIsGalleryOpen(false);
                setSelectedGalleryUniverse(null);
              }}
              className="mt-4 w-full bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 rounded-xl transition min-h-[48px] shrink-0">
              VOLVER
            </button>
          </div>
        </MenuOverlay>
      )}

      {/* ======================================================== */}
      {/* FEEDBACK TOAST NOTIFICATION                              */}
      {/* ======================================================== */}
      {toastMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 bg-slate-900 border-2 border-pink-500 text-white text-xs md:text-sm font-bold px-4 py-2.5 rounded-full shadow-2xl z-50 animate-bounce flex items-center gap-2 pointer-events-none">
          <Sparkles size={16} className="text-yellow-400" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
