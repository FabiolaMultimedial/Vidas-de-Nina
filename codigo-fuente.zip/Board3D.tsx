import {useFrame, useThree} from '@react-three/fiber';
import React, {useMemo, useRef} from 'react';
import * as THREE from 'three';
import {BOARD_TILES} from './boardData';
import {Dice3D, Dice3DHandle} from './Dice3D';
import {NinaModel} from './NinaModel';
import {EndingUniverse, NinaVisualConfig, TileData} from './types';
import {gameAudio} from './utils/helper';

interface Board3DProps {
  currentTileIndex: number; // 1 to 50
  isHopping: boolean;
  hopPath: number[]; // Array of tile indices being traversed
  hopProgress: number; // 0 to 1 between steps
  ninaVisual: NinaVisualConfig;
  diceRef: React.RefObject<Dice3DHandle>;
  onDiceRollComplete: (val: number) => void;
  endingRevealed?: EndingUniverse | null;
  isEndPortalActive?: boolean;
}

export function Board3D({
  currentTileIndex,
  isHopping,
  hopPath,
  hopProgress,
  ninaVisual,
  diceRef,
  onDiceRollComplete,
  endingRevealed,
  isEndPortalActive = false,
}: Board3DProps) {
  const {camera} = useThree();

  const ninaGroupRef = useRef<THREE.Group>(null);
  const portalRingRef = useRef<THREE.Group>(null);

  // Posición continua en el plano del tablero
  const ninaPos = useRef(new THREE.Vector3(0, 0.4, 14));

  // Determine current tile
  const currentTile = useMemo(() => {
    const idx = Math.max(1, Math.min(50, currentTileIndex));
    return BOARD_TILES[idx - 1] || BOARD_TILES[0];
  }, [currentTileIndex]);

  // Smooth character movement and rock-solid camera tracking
  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.1);

    // =========================================================================
    // MOVIMIENTO SUTIL DE NINA:
    // Nina se desliza suavemente sobre el plano X/Z.
    // El brinco vertical es microscópico y muy sutil (0.06), sin saltos abruptos.
    // =========================================================================
    if (isHopping && hopPath.length > 1) {
      const fromTile = BOARD_TILES[hopPath[0] - 1] || currentTile;
      const toTile = BOARD_TILES[hopPath[1] - 1] || currentTile;

      const p1 = new THREE.Vector3(...fromTile.position);
      const p2 = new THREE.Vector3(...toTile.position);

      const t = hopProgress;

      // Desplazamiento X y Z entre baldosas
      ninaPos.current.x = THREE.MathUtils.lerp(p1.x, p2.x, t);
      ninaPos.current.z = THREE.MathUtils.lerp(p1.z, p2.z, t);

      // Brinco extremadamente sutil (0.06) en los pies de Nina
      const subtleHop = Math.sin(t * Math.PI) * 0.06;
      ninaPos.current.y = 0.4 + subtleHop;

      // Nina mira suavemente hacia el frente de su avance
      if (ninaGroupRef.current) {
        const dx = p2.x - p1.x;
        const dz = p2.z - p1.z;
        if (Math.hypot(dx, dz) > 0.05) {
          const targetAngle = Math.atan2(dx, dz);
          ninaGroupRef.current.rotation.y = THREE.MathUtils.lerp(
            ninaGroupRef.current.rotation.y,
            targetAngle,
            5 * dt,
          );
        }
      }
    } else {
      // Reposando en el suelo de la casilla
      const targetPos = new THREE.Vector3(
        currentTile.position[0],
        0.4,
        currentTile.position[2],
      );
      ninaPos.current.lerp(targetPos, 5 * dt);
    }

    if (ninaGroupRef.current) {
      ninaGroupRef.current.position.copy(ninaPos.current);
    }

    // =========================================================================
    // CÁMARA QUE ACOMPAÑA AL PERSONAJE HACIA EL FRENTE / DERECHA / IZQUIERDA:
    // - camera.position.y NUNCA cambia: permanece clavada en 16.5 (CERO movimiento vertical arriba/abajo).
    // - El punto de mira en Y (targetY) NUNCA cambia: permanece clavado en 0.5 a ras de suelo.
    // - La cámara acompaña suavemente a Nina siguiendo su posición X (lateral) y Z (hacia el frente)
    //   con un amortiguamiento continuo muy calmado y sutil (2.2 * dt).
    // =========================================================================
    if (isEndPortalActive) {
      const lastTile = BOARD_TILES[49];
      camera.position.x = THREE.MathUtils.lerp(camera.position.x, lastTile.position[0], 2.0 * dt);
      camera.position.y = THREE.MathUtils.lerp(camera.position.y, 8.5, 2.0 * dt);
      camera.position.z = THREE.MathUtils.lerp(camera.position.z, lastTile.position[2] + 9.5, 2.0 * dt);
      camera.lookAt(lastTile.position[0], 1.5, lastTile.position[2]);
    } else {
      // Seguimiento puramente horizontal (X y Z) hacia el frente y laterales
      const desiredCamX = ninaPos.current.x * 0.55;
      const desiredCamZ = ninaPos.current.z + 15.0;

      // Desplazamiento horizontal fluido
      camera.position.x = THREE.MathUtils.lerp(camera.position.x, desiredCamX, 2.2 * dt);
      camera.position.z = THREE.MathUtils.lerp(camera.position.z, desiredCamZ, 2.2 * dt);

      // Altura Y fija sin ninguna variación
      camera.position.y = 16.5;

      // El punto de mira sigue a Nina en X y Z con altura Y fija en 0.5
      const lookAtX = camera.position.x * 0.75;
      const lookAtZ = ninaPos.current.z - 1.5;
      camera.lookAt(lookAtX, 0.5, lookAtZ);
    }

    // Rotación suave del portal en la casilla final
    if (portalRingRef.current) {
      portalRingRef.current.rotation.z += delta * 1.5;
    }
  });

  return (
    <group>
      {/* 3D TOYBOX PHYSICAL BOARD TABLE */}
      <mesh position={[0, -0.6, 0]} receiveShadow>
        <boxGeometry args={[34, 1.2, 34]} />
        <meshStandardMaterial color="#fff1f2" roughness={0.7} metalness={0.05} />
      </mesh>
      <mesh position={[0, -0.1, 0]} receiveShadow>
        <boxGeometry args={[34.8, 0.4, 34.8]} />
        <meshStandardMaterial color="#fce7f3" roughness={0.5} />
      </mesh>

      <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[32, 32]} />
        <meshStandardMaterial color="#fff7ed" roughness={0.9} />
      </mesh>

      {/* 50 PATH TILES & ROAD TRACK */}
      {BOARD_TILES.map((tile, i) => (
        <BoardTile key={tile.index} tile={tile} isCurrent={tile.index === currentTileIndex} />
      ))}

      {/* Sinuous Connecting Ribbon between Tiles */}
      <BoardPathRibbon tiles={BOARD_TILES} />

      {/* TOY PROPS & MINIATURE DIORAMA ENVIRONMENT */}
      <ToyDioramaScenery />

      {/* THE DESTINY PORTAL AT TILE 50 */}
      <group position={[BOARD_TILES[49].position[0], 0.6, BOARD_TILES[49].position[2]]}>
        <group ref={portalRingRef} position={[0, 2.2, 0]}>
          <mesh>
            <torusGeometry args={[2.2, 0.2, 16, 32]} />
            <meshStandardMaterial
              color="#fbbf24"
              emissive="#f59e0b"
              emissiveIntensity={isEndPortalActive ? 2.5 : 0.8}
              roughness={0.2}
            />
          </mesh>
          <mesh rotation={[0, 0, Math.PI / 4]}>
            <torusGeometry args={[1.8, 0.1, 12, 28]} />
            <meshStandardMaterial
              color="#ec4899"
              emissive="#db2777"
              emissiveIntensity={isEndPortalActive ? 3.0 : 0.6}
            />
          </mesh>
        </group>

        <mesh position={[0, 2.2, 0]}>
          <circleGeometry args={[1.8, 24]} />
          <meshBasicMaterial
            color={isEndPortalActive ? '#f472b6' : '#fde047'}
            transparent
            opacity={isEndPortalActive ? 0.75 : 0.3}
            side={THREE.DoubleSide}
          />
        </mesh>
        <pointLight
          position={[0, 2.2, 0]}
          color="#f43f5e"
          intensity={isEndPortalActive ? 40 : 15}
          distance={10}
        />
      </group>

      {/* 3D NINA PAWN */}
      <group ref={ninaGroupRef}>
        <NinaModel
          visual={ninaVisual}
          state={isHopping ? 'hop' : isEndPortalActive ? 'celebrate' : 'idle'}
          scale={1.3}
        />
      </group>

      {/* 3D ROLLING DICE */}
      <Dice3D
        ref={diceRef}
        position={[
          currentTile.position[0] > 0 ? currentTile.position[0] - 2.8 : currentTile.position[0] + 2.8,
          0.8,
          currentTile.position[2] + 1.2,
        ]}
        onRollComplete={onDiceRollComplete}
        scale={1.4}
      />
    </group>
  );
}

/** Individual 3D Board Tile Component */
function BoardTile({tile, isCurrent}: {tile: TileData; isCurrent: boolean}) {
  return (
    <group position={tile.position}>
      <mesh position={[0, 0.12, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[0.95, 1.05, 0.28, 24]} />
        <meshStandardMaterial
          color={isCurrent ? '#f43f5e' : tile.color}
          roughness={0.4}
          metalness={0.1}
        />
      </mesh>

      <mesh position={[0, 0.27, 0]} receiveShadow>
        <cylinderGeometry args={[0.82, 0.82, 0.04, 24]} />
        <meshStandardMaterial
          color={isCurrent ? '#ffffff' : tile.accentColor}
          roughness={0.3}
        />
      </mesh>

      <TileStamp type={tile.type} isCurrent={isCurrent} />

      {isCurrent && (
        <mesh position={[0, 0.32, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.9, 1.1, 32]} />
          <meshBasicMaterial color="#fbbf24" transparent opacity={0.8} />
        </mesh>
      )}
    </group>
  );
}

function TileStamp({type, isCurrent}: {type: TileData['type']; isCurrent: boolean}) {
  const color = isCurrent ? '#f43f5e' : '#ffffff';

  if (type === 'start') {
    return (
      <mesh position={[0, 0.3, 0]}>
        <cylinderGeometry args={[0.25, 0.25, 0.06, 16]} />
        <meshStandardMaterial color={color} />
      </mesh>
    );
  }
  if (type === 'goal') {
    return (
      <mesh position={[0, 0.3, 0]} rotation={[0, 0, Math.PI / 4]}>
        <boxGeometry args={[0.35, 0.06, 0.35]} />
        <meshStandardMaterial color="#fbbf24" metalness={0.8} roughness={0.2} />
      </mesh>
    );
  }
  if (type === 'career') {
    return (
      <mesh position={[0, 0.3, 0]}>
        <boxGeometry args={[0.35, 0.06, 0.25]} />
        <meshStandardMaterial color={color} />
      </mesh>
    );
  }
  if (type === 'love') {
    return (
      <group position={[0, 0.3, 0]}>
        <mesh position={[-0.08, 0, 0.06]}>
          <sphereGeometry args={[0.1, 8, 8]} />
          <meshStandardMaterial color="#f43f5e" />
        </mesh>
        <mesh position={[0.08, 0, 0.06]}>
          <sphereGeometry args={[0.1, 8, 8]} />
          <meshStandardMaterial color="#f43f5e" />
        </mesh>
      </group>
    );
  }
  if (type === 'money') {
    return (
      <mesh position={[0, 0.3, 0]}>
        <cylinderGeometry args={[0.18, 0.18, 0.06, 12]} />
        <meshStandardMaterial color="#eab308" metalness={0.7} roughness={0.3} />
      </mesh>
    );
  }
  return (
    <mesh position={[0, 0.3, 0]}>
      <octahedronGeometry args={[0.18, 0]} />
      <meshStandardMaterial color={color} />
    </mesh>
  );
}

function BoardPathRibbon({tiles}: {tiles: TileData[]}) {
  const ribbonGeo = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3(
      tiles.map((t) => new THREE.Vector3(t.position[0], 0.04, t.position[2])),
    );
    return new THREE.TubeGeometry(curve, 100, 0.3, 8, false);
  }, [tiles]);

  return (
    <mesh geometry={ribbonGeo} receiveShadow>
      <meshStandardMaterial color="#fde047" roughness={0.6} />
    </mesh>
  );
}

function ToyDioramaScenery() {
  const sceneryProps = useMemo(() => {
    const items: Array<{
      type: 'house' | 'cafe' | 'tree' | 'pine' | 'flower' | 'lamp';
      pos: [number, number, number];
      color: string;
      scale: number;
    }> = [
      {type: 'house', pos: [-12, 0, 10], color: '#fbcfe8', scale: 1.1},
      {type: 'cafe', pos: [-9, 0, 11], color: '#bae6fd', scale: 1.0},
      {type: 'tree', pos: [-14, 0, 7], color: '#6ee7b7', scale: 1.2},
      {type: 'lamp', pos: [-10, 0, 8], color: '#fde047', scale: 1.0},

      {type: 'house', pos: [-8, 0, 0], color: '#fed7aa', scale: 1.0},
      {type: 'tree', pos: [-6, 0, -3], color: '#a7f3d0', scale: 0.9},
      {type: 'pine', pos: [-13, 0, -2], color: '#34d399', scale: 1.3},

      {type: 'house', pos: [-12, 0, -11], color: '#e9d5ff', scale: 1.2},
      {type: 'tree', pos: [-9, 0, -13], color: '#f472b6', scale: 1.1},
      {type: 'tree', pos: [-14, 0, -8], color: '#6ee7b7', scale: 1.3},

      {type: 'house', pos: [8, 0, 4], color: '#bae6fd', scale: 1.1},
      {type: 'tree', pos: [11, 0, 7], color: '#fde047', scale: 1.0},
      {type: 'lamp', pos: [6, 0, 2], color: '#fde047', scale: 1.0},

      {type: 'house', pos: [11, 0, -8], color: '#fbcfe8', scale: 1.4},
      {type: 'cafe', pos: [7, 0, -12], color: '#fed7aa', scale: 1.0},
      {type: 'tree', pos: [13, 0, -12], color: '#a7f3d0', scale: 1.2},
      {type: 'lamp', pos: [9, 0, -6], color: '#fde047', scale: 1.0},

      {type: 'house', pos: [10, 0, 12], color: '#e9d5ff', scale: 1.2},
      {type: 'pine', pos: [13, 0, 11], color: '#10b981', scale: 1.3},
      {type: 'tree', pos: [7, 0, 13], color: '#fb7185', scale: 1.0},
    ];
    return items;
  }, []);

  return (
    <group>
      {sceneryProps.map((item, idx) => {
        if (item.type === 'house' || item.type === 'cafe') {
          return (
            <group key={idx} position={item.pos} scale={item.scale}>
              <mesh position={[0, 0.8, 0]} castShadow receiveShadow>
                <boxGeometry args={[1.8, 1.6, 1.8]} />
                <meshStandardMaterial color={item.color} roughness={0.7} />
              </mesh>
              <mesh position={[0, 2.0, 0]} rotation={[0, Math.PI / 4, 0]} castShadow>
                <coneGeometry args={[1.5, 1.1, 4]} />
                <meshStandardMaterial color="#f43f5e" roughness={0.6} />
              </mesh>
              <mesh position={[0, 0.45, 0.92]}>
                <boxGeometry args={[0.5, 0.8, 0.08]} />
                <meshStandardMaterial color="#78350f" />
              </mesh>
              <mesh position={[-0.45, 1.0, 0.92]}>
                <boxGeometry args={[0.4, 0.4, 0.06]} />
                <meshStandardMaterial color="#bae6fd" roughness={0.2} />
              </mesh>
              <mesh position={[0.45, 1.0, 0.92]}>
                <boxGeometry args={[0.4, 0.4, 0.06]} />
                <meshStandardMaterial color="#bae6fd" roughness={0.2} />
              </mesh>
            </group>
          );
        }

        if (item.type === 'tree') {
          return (
            <group key={idx} position={item.pos} scale={item.scale}>
              <mesh position={[0, 0.6, 0]} castShadow>
                <cylinderGeometry args={[0.16, 0.22, 1.2, 8]} />
                <meshStandardMaterial color="#854d0e" roughness={0.9} />
              </mesh>
              <mesh position={[0, 1.7, 0]} castShadow>
                <sphereGeometry args={[0.9, 12, 12]} />
                <meshStandardMaterial color={item.color} roughness={0.8} />
              </mesh>
            </group>
          );
        }

        if (item.type === 'pine') {
          return (
            <group key={idx} position={item.pos} scale={item.scale}>
              <mesh position={[0, 0.5, 0]} castShadow>
                <cylinderGeometry args={[0.15, 0.25, 1.0, 6]} />
                <meshStandardMaterial color="#713f12" />
              </mesh>
              <mesh position={[0, 1.3, 0]} castShadow>
                <coneGeometry args={[0.85, 1.2, 7]} />
                <meshStandardMaterial color={item.color} roughness={0.8} />
              </mesh>
              <mesh position={[0, 2.0, 0]} castShadow>
                <coneGeometry args={[0.65, 1.0, 7]} />
                <meshStandardMaterial color={item.color} roughness={0.8} />
              </mesh>
            </group>
          );
        }

        if (item.type === 'lamp') {
          return (
            <group key={idx} position={item.pos} scale={item.scale}>
              <mesh position={[0, 0.9, 0]} castShadow>
                <cylinderGeometry args={[0.06, 0.08, 1.8, 8]} />
                <meshStandardMaterial color="#475569" roughness={0.7} />
              </mesh>
              <mesh position={[0, 1.9, 0]}>
                <sphereGeometry args={[0.2, 12, 12]} />
                <meshStandardMaterial
                  color="#fef08a"
                  emissive="#fde047"
                  emissiveIntensity={1.5}
                />
              </mesh>
              <pointLight
                position={[0, 1.9, 0]}
                color="#fde047"
                intensity={8.0}
                distance={5}
              />
            </group>
          );
        }

        return null;
      })}
    </group>
  );
}
