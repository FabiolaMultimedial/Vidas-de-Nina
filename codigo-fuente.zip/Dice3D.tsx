import {useFrame} from '@react-three/fiber';
import React, {forwardRef, useImperativeHandle, useRef, useState} from 'react';
import * as THREE from 'three';
import {gameAudio} from './utils/helper';

export interface Dice3DHandle {
  roll: (targetValue: number) => void;
  isRolling: () => boolean;
}

interface Dice3DProps {
  position?: [number, number, number];
  onRollComplete?: (result: number) => void;
  scale?: number;
}

// Target rotations for each face (1 to 6) to face up (+Y direction):
// In standard orientation:
// Face 1 is +Y (top) -> rot [0, 0, 0]
// Face 6 is -Y (bottom) -> rot [Math.PI, 0, 0]
// Face 2 is +Z (front) -> rot [-Math.PI/2, 0, 0]
// Face 5 is -Z (back) -> rot [Math.PI/2, 0, 0]
// Face 3 is +X (right) -> rot [0, 0, Math.PI/2]
// Face 4 is -X (left) -> rot [0, 0, -Math.PI/2]
const FACE_ROTATIONS: Record<number, [number, number, number]> = {
  1: [0, 0, 0],
  2: [-Math.PI / 2, 0, 0],
  3: [0, 0, Math.PI / 2],
  4: [0, 0, -Math.PI / 2],
  5: [Math.PI / 2, 0, 0],
  6: [Math.PI, 0, 0],
};

export const Dice3D = forwardRef<Dice3DHandle, Dice3DProps>(function Dice3D(
  {position = [0, 1.2, 0], onRollComplete, scale = 1.2},
  ref,
) {
  const groupRef = useRef<THREE.Group>(null);
  const meshRef = useRef<THREE.Group>(null);

  const [rolling, setRolling] = useState(false);
  const rollTimeRef = useRef(0);
  const rollDurationRef = useRef(1.4);
  const targetValRef = useRef(1);

  // Trajectory variables
  const startRot = useRef(new THREE.Euler());
  const spinVel = useRef(new THREE.Vector3());
  const initialPos = useRef(new THREE.Vector3(...position));

  useImperativeHandle(ref, () => ({
    isRolling: () => rolling,
    roll: (targetValue: number) => {
      if (rolling) return;
      targetValRef.current = targetValue;
      rollTimeRef.current = 0;
      setRolling(true);

      if (meshRef.current) {
        startRot.current.copy(meshRef.current.rotation);
      }

      // Random crazy spin velocity
      spinVel.current.set(
        (Math.random() - 0.5) * 25 + 15,
        (Math.random() - 0.5) * 25 + 15,
        (Math.random() - 0.5) * 25 + 15,
      );

      gameAudio.playJumpLandingThud();
    },
  }));

  useFrame((_, delta) => {
    if (!meshRef.current || !groupRef.current) return;

    if (rolling) {
      rollTimeRef.current += delta;
      const progress = Math.min(1, rollTimeRef.current / rollDurationRef.current);

      // Arc jump in Y
      const jumpHeight = Math.sin(progress * Math.PI) * 2.8;
      // Bounce wobble on ground
      const bounce =
        progress > 0.7
          ? Math.abs(Math.sin((progress - 0.7) * Math.PI * 6)) * 0.4 * (1 - progress)
          : 0;

      meshRef.current.position.y = jumpHeight + bounce;

      if (progress < 0.75) {
        // High speed free tumble
        meshRef.current.rotation.x += spinVel.current.x * delta;
        meshRef.current.rotation.y += spinVel.current.y * delta;
        meshRef.current.rotation.z += spinVel.current.z * delta;
      } else {
        // Smoothly settle into exact target face
        const settleProgress = (progress - 0.75) / 0.25;
        const targetRot = FACE_ROTATIONS[targetValRef.current] || [0, 0, 0];

        meshRef.current.rotation.x = THREE.MathUtils.lerp(
          meshRef.current.rotation.x,
          targetRot[0],
          settleProgress * 0.5,
        );
        meshRef.current.rotation.y = THREE.MathUtils.lerp(
          meshRef.current.rotation.y,
          targetRot[1],
          settleProgress * 0.5,
        );
        meshRef.current.rotation.z = THREE.MathUtils.lerp(
          meshRef.current.rotation.z,
          targetRot[2],
          settleProgress * 0.5,
        );
      }

      if (progress >= 1) {
        setRolling(false);
        const finalRot = FACE_ROTATIONS[targetValRef.current];
        if (finalRot) {
          meshRef.current.rotation.set(...finalRot);
        }
        meshRef.current.position.y = 0;
        gameAudio.playJumpLandingThud();
        if (onRollComplete) {
          onRollComplete(targetValRef.current);
        }
      }
    }
  });

  return (
    <group ref={groupRef} position={position} scale={scale}>
      <group ref={meshRef}>
        {/* Rounded Dice Body */}
        <mesh castShadow receiveShadow>
          <boxGeometry args={[1, 1, 1]} />
          <meshStandardMaterial
            color="#ffffff"
            roughness={0.2}
            metalness={0.05}
          />
        </mesh>

        {/* Outer border / toy edge accent */}
        <mesh>
          <boxGeometry args={[0.98, 0.98, 0.98]} />
          <meshStandardMaterial color="#fce7f3" roughness={0.4} />
        </mesh>

        {/* Pips / Dots for Face 1 (+Y) - 1 central pink dot */}
        <mesh position={[0, 0.51, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[0.13, 16]} />
          <meshBasicMaterial color="#ec4899" />
        </mesh>

        {/* Pips for Face 6 (-Y) - 6 dots */}
        <group position={[0, -0.51, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <Pip x={-0.24} y={-0.28} />
          <Pip x={-0.24} y={0} />
          <Pip x={-0.24} y={0.28} />
          <Pip x={0.24} y={-0.28} />
          <Pip x={0.24} y={0} />
          <Pip x={0.24} y={0.28} />
        </group>

        {/* Pips for Face 2 (+Z) - 2 dots diagonal */}
        <group position={[0, 0, 0.51]}>
          <Pip x={-0.22} y={-0.22} />
          <Pip x={0.22} y={0.22} />
        </group>

        {/* Pips for Face 5 (-Z) - 5 dots */}
        <group position={[0, 0, -0.51]} rotation={[0, Math.PI, 0]}>
          <Pip x={-0.24} y={-0.24} />
          <Pip x={0.24} y={-0.24} />
          <Pip x={0} y={0} />
          <Pip x={-0.24} y={0.24} />
          <Pip x={0.24} y={0.24} />
        </group>

        {/* Pips for Face 3 (+X) - 3 dots diagonal */}
        <group position={[0.51, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
          <Pip x={-0.24} y={-0.24} />
          <Pip x={0} y={0} />
          <Pip x={0.24} y={0.24} />
        </group>

        {/* Pips for Face 4 (-X) - 4 dots */}
        <group position={[-0.51, 0, 0]} rotation={[0, -Math.PI / 2, 0]}>
          <Pip x={-0.24} y={-0.24} />
          <Pip x={0.24} y={-0.24} />
          <Pip x={-0.24} y={0.24} />
          <Pip x={0.24} y={0.24} />
        </group>
      </group>
    </group>
  );
});

function Pip({x, y}: {x: number; y: number}) {
  return (
    <mesh position={[x, y, 0]}>
      <circleGeometry args={[0.09, 16]} />
      <meshBasicMaterial color="#334155" />
    </mesh>
  );
}
