import {Canvas, useFrame, useThree} from '@react-three/fiber';
import {Bloom, EffectComposer} from '@react-three/postprocessing';
import React, {Suspense, useEffect, useRef, useState} from 'react';
import * as THREE from 'three';
import {Board3D} from './Board3D';
import {BOARD_TILES} from './boardData';
import {getConfig} from './constants';
import {Dice3DHandle} from './Dice3D';
import {EndingUniverse, NinaStats, NinaVisualConfig} from './types';
import {GameState} from './utils/helper';

export interface GameProps {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  currentTileIndex: number;
  isHopping: boolean;
  hopPath: number[];
  hopProgress: number;
  ninaVisual: NinaVisualConfig;
  diceRef: React.RefObject<Dice3DHandle>;
  onDiceRollComplete: (val: number) => void;
  endingRevealed: EndingUniverse | null;
  isEndPortalActive: boolean;
  ninaStats: NinaStats;
}

/** Camera sync helper */
function CameraController() {
  const {camera} = useThree();

  useEffect(() => {
    if (camera instanceof THREE.PerspectiveCamera) {
      camera.fov = getConfig('fov');
      camera.updateProjectionMatrix();
    }
  }, [camera]);

  return null;
}

/** Sun light with shadow camera bounds */
function SunLight() {
  const lightRef = useRef<THREE.DirectionalLight>(null);

  return (
    <directionalLight
      ref={lightRef}
      position={[12, 28, 16]}
      intensity={getConfig('sunIntensity')}
      color={getConfig('sunColor')}
      castShadow
      shadow-mapSize={[2048, 2048]}
      shadow-camera-near={0.5}
      shadow-camera-far={70}
      shadow-camera-left={-22}
      shadow-camera-right={22}
      shadow-camera-top={22}
      shadow-camera-bottom={-22}
      shadow-bias={-0.0004}
    />
  );
}

/** Soft floating pastel dust particles */
function AmbientDustParticles() {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const count = 45;

  const dummy = useRef(new THREE.Object3D());
  const particles = useRef(
    Array.from({length: count}, () => ({
      x: (Math.random() - 0.5) * 32,
      y: 1 + Math.random() * 8,
      z: (Math.random() - 0.5) * 32,
      speed: 0.2 + Math.random() * 0.4,
      scale: 0.08 + Math.random() * 0.12,
    })),
  );

  useFrame((_, delta) => {
    if (!meshRef.current) return;
    particles.current.forEach((p, i) => {
      p.y += p.speed * delta;
      if (p.y > 9) p.y = 1;

      dummy.current.position.set(p.x, p.y, p.z);
      dummy.current.scale.set(p.scale, p.scale, p.scale);
      dummy.current.updateMatrix();
      meshRef.current?.setMatrixAt(i, dummy.current.matrix);
    });
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <sphereGeometry args={[1, 8, 8]} />
      <meshBasicMaterial color="#fbcfe8" transparent opacity={0.4} />
    </instancedMesh>
  );
}

export function Game({
  gameState,
  setGameState,
  currentTileIndex,
  isHopping,
  hopPath,
  hopProgress,
  ninaVisual,
  diceRef,
  onDiceRollComplete,
  endingRevealed,
  isEndPortalActive,
  ninaStats,
}: GameProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  return (
    <div ref={containerRef} className="w-full h-full canvas-wrapper relative">
      <Canvas
        shadows
        dpr={[1, 2]}
        camera={{
          fov: getConfig('fov'),
          near: 0.1,
          far: 1000,
          position: [getConfig('cameraX'), getConfig('cameraY'), getConfig('cameraZ')],
        }}
        gl={{
          antialias: true,
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 1.1,
        }}
        scene={{
          background: new THREE.Color(getConfig('backgroundColor')),
        }}>
        <Suspense fallback={null}>
          <CameraController />

          {/* Physically-scaled lighting rig */}
          <ambientLight
            color={getConfig('ambientColor')}
            intensity={getConfig('ambientIntensity')}
          />
          <SunLight />
          <hemisphereLight
            color={getConfig('hemiSkyColor')}
            groundColor={getConfig('hemiGroundColor')}
            intensity={getConfig('hemiIntensity')}
          />

          {/* Gentle Floating Pastel Sparkles */}
          <AmbientDustParticles />

          {/* 3D Toybox Board Scene */}
          <Board3D
            currentTileIndex={currentTileIndex}
            isHopping={isHopping}
            hopPath={hopPath}
            hopProgress={hopProgress}
            ninaVisual={ninaVisual}
            diceRef={diceRef}
            onDiceRollComplete={onDiceRollComplete}
            endingRevealed={endingRevealed}
            isEndPortalActive={isEndPortalActive}
          />

          {/* Post Processing Bloom */}
          <EffectComposer>
            <Bloom
              luminanceThreshold={0.9}
              luminanceSmoothing={0.4}
              intensity={0.4}
              mipmapBlur
            />
          </EffectComposer>
        </Suspense>
      </Canvas>
    </div>
  );
}
