import {useFrame} from '@react-three/fiber';
import React, {forwardRef, useRef} from 'react';
import * as THREE from 'three';
import {NinaVisualConfig} from './types';

export interface NinaModelProps {
  visual?: NinaVisualConfig;
  state?: 'idle' | 'hop' | 'celebrate' | 'ponder';
  scale?: number;
  rotationY?: number;
}

export const NinaModel = forwardRef<THREE.Group, NinaModelProps>(function NinaModel(
  {
    visual = {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#ec4899',
      pantsColor: '#1e3a8a',
      accessory: 'none',
      auraColor: '#f472b6',
    },
    state = 'idle',
    scale = 1.0,
    rotationY = 0,
  }: NinaModelProps,
  ref,
) {
  const leftArmRef = useRef<THREE.Group>(null);
  const rightArmRef = useRef<THREE.Group>(null);
  const headRef = useRef<THREE.Group>(null);
  const bodyRef = useRef<THREE.Group>(null);

  useFrame(({clock}) => {
    const t = clock.getElapsedTime();

    if (state === 'idle') {
      if (bodyRef.current) {
        bodyRef.current.position.y = Math.sin(t * 3) * 0.03;
      }
      if (headRef.current) {
        headRef.current.rotation.y = Math.sin(t * 1.5) * 0.1;
        headRef.current.rotation.z = Math.sin(t * 2) * 0.03;
      }
      if (leftArmRef.current && rightArmRef.current) {
        leftArmRef.current.rotation.z = 0.2 + Math.sin(t * 2.5) * 0.05;
        rightArmRef.current.rotation.z = -0.2 - Math.sin(t * 2.5) * 0.05;
      }
    } else if (state === 'celebrate') {
      if (bodyRef.current) {
        bodyRef.current.position.y = Math.abs(Math.sin(t * 8)) * 0.25;
      }
      if (leftArmRef.current && rightArmRef.current) {
        leftArmRef.current.rotation.z = 2.4 + Math.sin(t * 8) * 0.3;
        rightArmRef.current.rotation.z = -2.4 - Math.sin(t * 8) * 0.3;
      }
    } else if (state === 'hop') {
      if (bodyRef.current) {
        bodyRef.current.position.y = Math.abs(Math.sin(t * 12)) * 0.3;
      }
      if (leftArmRef.current && rightArmRef.current) {
        leftArmRef.current.rotation.x = Math.sin(t * 12) * 0.6;
        rightArmRef.current.rotation.x = -Math.sin(t * 12) * 0.6;
      }
    } else if (state === 'ponder') {
      if (headRef.current) {
        headRef.current.rotation.z = -0.15;
      }
      if (rightArmRef.current) {
        rightArmRef.current.rotation.x = -1.2;
        rightArmRef.current.rotation.y = 0.4;
      }
    }
  });

  return (
    <group ref={ref} scale={scale} rotation={[0, rotationY, 0]}>
      {/* Base aura ring */}
      {visual.auraColor && (
        <mesh position={[0, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.55, 0.75, 32]} />
          <meshBasicMaterial color={visual.auraColor} transparent opacity={0.65} />
        </mesh>
      )}

      {/* Main animated body wrapper */}
      <group ref={bodyRef} position={[0, 0, 0]}>
        {/* Shoes */}
        <mesh position={[-0.18, 0.1, 0.05]} castShadow>
          <boxGeometry args={[0.16, 0.12, 0.28]} />
          <meshStandardMaterial color="#ffffff" roughness={0.6} />
        </mesh>
        <mesh position={[0.18, 0.1, 0.05]} castShadow>
          <boxGeometry args={[0.16, 0.12, 0.28]} />
          <meshStandardMaterial color="#ffffff" roughness={0.6} />
        </mesh>

        {/* Legs / Chic Trousers */}
        <mesh position={[-0.18, 0.55, 0]} castShadow>
          <cylinderGeometry args={[0.1, 0.09, 0.8, 12]} />
          <meshStandardMaterial color={visual.pantsColor} roughness={0.7} />
        </mesh>
        <mesh position={[0.18, 0.55, 0]} castShadow>
          <cylinderGeometry args={[0.1, 0.09, 0.8, 12]} />
          <meshStandardMaterial color={visual.pantsColor} roughness={0.7} />
        </mesh>

        {/* Hips / Belt */}
        <mesh position={[0, 0.95, 0]} castShadow>
          <cylinderGeometry args={[0.26, 0.24, 0.22, 14]} />
          <meshStandardMaterial color={visual.pantsColor} roughness={0.7} />
        </mesh>
        <mesh position={[0, 1.05, 0.2]}>
          <boxGeometry args={[0.12, 0.08, 0.04]} />
          <meshStandardMaterial color="#fbbf24" metalness={0.8} roughness={0.3} />
        </mesh>

        {/* Torso / Casual Chic Top or Jacket */}
        <mesh position={[0, 1.35, 0]} castShadow>
          <capsuleGeometry args={[0.24, 0.42, 6, 12]} />
          <meshStandardMaterial color={visual.outfitColor} roughness={0.65} />
        </mesh>

        {/* Chic collar / necklace */}
        <mesh position={[0, 1.62, 0.15]}>
          <torusGeometry args={[0.12, 0.025, 8, 16]} />
          <meshStandardMaterial color="#fef08a" metalness={0.7} roughness={0.3} />
        </mesh>

        {/* Arms */}
        <group ref={leftArmRef} position={[-0.35, 1.5, 0]}>
          <mesh position={[0, -0.32, 0]} castShadow>
            <cylinderGeometry args={[0.07, 0.06, 0.65, 10]} />
            <meshStandardMaterial color={visual.outfitColor} />
          </mesh>
          <mesh position={[0, -0.68, 0]} castShadow>
            <sphereGeometry args={[0.07, 10, 10]} />
            <meshStandardMaterial color={visual.skinColor} />
          </mesh>
        </group>

        <group ref={rightArmRef} position={[0.35, 1.5, 0]}>
          <mesh position={[0, -0.32, 0]} castShadow>
            <cylinderGeometry args={[0.07, 0.06, 0.65, 10]} />
            <meshStandardMaterial color={visual.outfitColor} />
          </mesh>
          <mesh position={[0, -0.68, 0]} castShadow>
            <sphereGeometry args={[0.07, 10, 10]} />
            <meshStandardMaterial color={visual.skinColor} />
          </mesh>
        </group>

        {/* Head and Hair Group */}
        <group ref={headRef} position={[0, 1.82, 0]}>
          {/* Neck */}
          <mesh position={[0, -0.12, 0]} castShadow>
            <cylinderGeometry args={[0.09, 0.1, 0.18, 10]} />
            <meshStandardMaterial color={visual.skinColor} />
          </mesh>

          {/* Head */}
          <mesh position={[0, 0.15, 0]} castShadow>
            <sphereGeometry args={[0.26, 18, 18]} />
            <meshStandardMaterial color={visual.skinColor} roughness={0.8} />
          </mesh>

          {/* Cheerful Eyes */}
          <mesh position={[-0.09, 0.18, 0.23]}>
            <sphereGeometry args={[0.035, 10, 10]} />
            <meshBasicMaterial color="#271b12" />
          </mesh>
          <mesh position={[-0.08, 0.19, 0.25]}>
            <sphereGeometry args={[0.012, 8, 8]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
          <mesh position={[0.09, 0.18, 0.23]}>
            <sphereGeometry args={[0.035, 10, 10]} />
            <meshBasicMaterial color="#271b12" />
          </mesh>
          <mesh position={[0.1, 0.19, 0.25]}>
            <sphereGeometry args={[0.012, 8, 8]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>

          {/* Peach Blush cheeks */}
          <mesh position={[-0.14, 0.12, 0.21]}>
            <sphereGeometry args={[0.045, 8, 8]} />
            <meshBasicMaterial color="#fb7185" transparent opacity={0.6} />
          </mesh>
          <mesh position={[0.14, 0.12, 0.21]}>
            <sphereGeometry args={[0.045, 8, 8]} />
            <meshBasicMaterial color="#fb7185" transparent opacity={0.6} />
          </mesh>

          {/* Gentle Smile */}
          <mesh position={[0, 0.08, 0.24]} rotation={[0, 0, Math.PI]}>
            <torusGeometry args={[0.05, 0.015, 8, 12, Math.PI * 0.8]} />
            <meshBasicMaterial color="#881337" />
          </mesh>

          {/* Loose, Sleek Medium-Length Dark Chestnut Hair (No pigtails or buns) */}
          {/* Main top dome of hair */}
          <mesh position={[0, 0.22, -0.02]} castShadow>
            <sphereGeometry args={[0.295, 20, 20]} />
            <meshStandardMaterial color={visual.hairColor} roughness={0.75} />
          </mesh>

          {/* Front fringe / smooth parted bangs */}
          <mesh position={[0, 0.3, 0.14]} rotation={[0.35, 0, 0]} castShadow>
            <cylinderGeometry args={[0.26, 0.28, 0.16, 16]} />
            <meshStandardMaterial color={visual.hairColor} roughness={0.75} />
          </mesh>
          <mesh position={[-0.1, 0.28, 0.2]} rotation={[0.2, 0.1, -0.15]} castShadow>
            <boxGeometry args={[0.16, 0.08, 0.06]} />
            <meshStandardMaterial color={visual.hairColor} roughness={0.75} />
          </mesh>
          <mesh position={[0.1, 0.28, 0.2]} rotation={[0.2, -0.1, 0.15]} castShadow>
            <boxGeometry args={[0.16, 0.08, 0.06]} />
            <meshStandardMaterial color={visual.hairColor} roughness={0.75} />
          </mesh>

          {/* Left loose straight hair strand flowing over shoulder */}
          <group position={[-0.24, 0.02, 0.04]} rotation={[0, 0, 0.04]}>
            <mesh castShadow>
              <capsuleGeometry args={[0.085, 0.52, 6, 12]} />
              <meshStandardMaterial color={visual.hairColor} roughness={0.75} />
            </mesh>
            {/* Soft tapered tip past the shoulder */}
            <mesh position={[0.02, -0.28, 0.02]} rotation={[0, 0, -0.06]} castShadow>
              <coneGeometry args={[0.075, 0.16, 8]} />
              <meshStandardMaterial color={visual.hairColor} roughness={0.75} />
            </mesh>
          </group>

          {/* Right loose straight hair strand flowing over shoulder */}
          <group position={[0.24, 0.02, 0.04]} rotation={[0, 0, -0.04]}>
            <mesh castShadow>
              <capsuleGeometry args={[0.085, 0.52, 6, 12]} />
              <meshStandardMaterial color={visual.hairColor} roughness={0.75} />
            </mesh>
            {/* Soft tapered tip past the shoulder */}
            <mesh position={[-0.02, -0.28, 0.02]} rotation={[0, 0, 0.06]} castShadow>
              <coneGeometry args={[0.075, 0.16, 8]} />
              <meshStandardMaterial color={visual.hairColor} roughness={0.75} />
            </mesh>
          </group>

          {/* Back smooth curtain of loose hair falling past shoulders */}
          <group position={[0, 0.02, -0.15]}>
            <mesh castShadow>
              <capsuleGeometry args={[0.17, 0.54, 6, 14]} />
              <meshStandardMaterial color={visual.hairColor} roughness={0.75} />
            </mesh>
            {/* Lower back hair drape */}
            <mesh position={[0, -0.18, 0]} castShadow>
              <cylinderGeometry args={[0.22, 0.25, 0.28, 14]} />
              <meshStandardMaterial color={visual.hairColor} roughness={0.75} />
            </mesh>
          </group>

          {/* Accessories */}
          {visual.accessory === 'crown' && (
            <group position={[0, 0.45, 0]}>
              <mesh castShadow>
                <cylinderGeometry args={[0.18, 0.14, 0.18, 6]} />
                <meshStandardMaterial color="#fbbf24" metalness={0.9} roughness={0.2} />
              </mesh>
              <mesh position={[0, 0.12, 0]}>
                <sphereGeometry args={[0.04, 8, 8]} />
                <meshStandardMaterial color="#f43f5e" metalness={0.5} roughness={0.1} />
              </mesh>
            </group>
          )}

          {visual.accessory === 'glasses' && (
            <group position={[0, 0.18, 0.26]}>
              <mesh position={[-0.1, 0, 0]}>
                <torusGeometry args={[0.06, 0.012, 8, 16]} />
                <meshStandardMaterial color="#475569" metalness={0.8} roughness={0.3} />
              </mesh>
              <mesh position={[0.1, 0, 0]}>
                <torusGeometry args={[0.06, 0.012, 8, 16]} />
                <meshStandardMaterial color="#475569" metalness={0.8} roughness={0.3} />
              </mesh>
              <mesh position={[0, 0, 0]}>
                <boxGeometry args={[0.06, 0.01, 0.01]} />
                <meshStandardMaterial color="#475569" />
              </mesh>
            </group>
          )}

          {visual.accessory === 'sunglasses' && (
            <group position={[0, 0.18, 0.26]}>
              <mesh position={[-0.1, 0, 0]}>
                <boxGeometry args={[0.12, 0.08, 0.02]} />
                <meshStandardMaterial color="#0f172a" metalness={0.9} roughness={0.1} />
              </mesh>
              <mesh position={[0.1, 0, 0]}>
                <boxGeometry args={[0.12, 0.08, 0.02]} />
                <meshStandardMaterial color="#0f172a" metalness={0.9} roughness={0.1} />
              </mesh>
              <mesh position={[0, 0, 0]}>
                <boxGeometry args={[0.08, 0.02, 0.02]} />
                <meshStandardMaterial color="#0f172a" />
              </mesh>
            </group>
          )}

          {visual.accessory === 'hat' && (
            <group position={[0, 0.42, 0]}>
              {/* Sun/traveler hat */}
              <mesh castShadow>
                <cylinderGeometry args={[0.42, 0.42, 0.04, 20]} />
                <meshStandardMaterial color="#fef08a" roughness={0.9} />
              </mesh>
              <mesh position={[0, 0.1, 0]} castShadow>
                <cylinderGeometry args={[0.22, 0.25, 0.18, 18]} />
                <meshStandardMaterial color="#fde047" roughness={0.9} />
              </mesh>
              <mesh position={[0, 0.04, 0]}>
                <torusGeometry args={[0.26, 0.02, 8, 18]} />
                <meshStandardMaterial color="#f43f5e" />
              </mesh>
            </group>
          )}

          {visual.accessory === 'chef' && (
            <group position={[0, 0.48, 0]}>
              <mesh castShadow>
                <cylinderGeometry args={[0.22, 0.22, 0.15, 16]} />
                <meshStandardMaterial color="#ffffff" roughness={0.8} />
              </mesh>
              <mesh position={[0, 0.16, 0]} castShadow>
                <sphereGeometry args={[0.28, 14, 14]} />
                <meshStandardMaterial color="#ffffff" roughness={0.8} />
              </mesh>
            </group>
          )}

          {visual.accessory === 'scarf' && (
            <group position={[0, -0.16, 0.05]}>
              <mesh castShadow>
                <torusGeometry args={[0.22, 0.06, 8, 18]} />
                <meshStandardMaterial color="#f43f5e" roughness={0.8} />
              </mesh>
              <mesh position={[0.1, -0.18, 0.18]} rotation={[0.2, 0, -0.3]}>
                <boxGeometry args={[0.1, 0.28, 0.04]} />
                <meshStandardMaterial color="#f43f5e" roughness={0.8} />
              </mesh>
            </group>
          )}
        </group>

        {/* Back Accessory: Explorer Backpack */}
        {visual.accessory === 'backpack' && (
          <group position={[0, 1.3, -0.26]}>
            <mesh castShadow>
              <boxGeometry args={[0.38, 0.45, 0.24]} />
              <meshStandardMaterial color="#b45309" roughness={0.8} />
            </mesh>
            <mesh position={[0, -0.1, -0.06]}>
              <boxGeometry args={[0.28, 0.18, 0.14]} />
              <meshStandardMaterial color="#d97706" roughness={0.8} />
            </mesh>
          </group>
        )}

        {/* Companion: Cute Cat sitting on her side or base */}
        {visual.accessory === 'cat' && (
          <group position={[0.55, 0.2, 0.15]} rotation={[0, -0.4, 0]}>
            {/* Cat body */}
            <mesh castShadow>
              <capsuleGeometry args={[0.14, 0.22, 4, 10]} />
              <meshStandardMaterial color="#fb923c" roughness={0.85} />
            </mesh>
            {/* Cat head */}
            <mesh position={[0, 0.24, 0.06]} castShadow>
              <sphereGeometry args={[0.12, 12, 12]} />
              <meshStandardMaterial color="#fb923c" roughness={0.85} />
            </mesh>
            {/* Ears */}
            <mesh position={[-0.06, 0.35, 0.06]} rotation={[0, 0, 0.4]}>
              <coneGeometry args={[0.04, 0.08, 4]} />
              <meshStandardMaterial color="#ea580c" />
            </mesh>
            <mesh position={[0.06, 0.35, 0.06]} rotation={[0, 0, -0.4]}>
              <coneGeometry args={[0.04, 0.08, 4]} />
              <meshStandardMaterial color="#ea580c" />
            </mesh>
            {/* Tail */}
            <mesh position={[0, 0.05, -0.16]} rotation={[-0.8, 0, 0]}>
              <cylinderGeometry args={[0.03, 0.025, 0.24, 6]} />
              <meshStandardMaterial color="#fb923c" />
            </mesh>
          </group>
        )}
      </group>
    </group>
  );
});
