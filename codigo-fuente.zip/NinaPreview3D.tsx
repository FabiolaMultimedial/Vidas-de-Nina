import {Canvas, useFrame, useThree} from '@react-three/fiber';
import React, {Suspense, useEffect, useRef} from 'react';
import * as THREE from 'three';
import {NinaModel} from './NinaModel';
import {EndingUniverse, NinaVisualConfig} from './types';

interface NinaPreview3DProps {
  ending: EndingUniverse;
  visual?: NinaVisualConfig;
}

/**
 * 3D Miniature Vignette Scene matching each specific universe outcome:
 * - Magnate / Millonaria: Golden floor, palace pillars, diamond sparkle, crown
 * - Gatos: Warm rug, toy scratching post, multiple cute cats, soft pink light
 * - Viajera / Aventura: Earth globe, traveler crate, green grass, compass
 * - Bancarrota: Cardboard boxes, comical tilted stool, scattered papers
 * - Mar / Capitana: Sandy floor, ocean blue deck, lifesaver ring, seashell
 * - Cafe / Chef: Wooden counter, coffee mugs, chef accessories
 * - Alpacas: Fluffy miniature wool bales, farm fence, grass
 * - Default / Bohemia: Painter easel, pastel rug, plant pots
 */
export function NinaPreview3D({ending, visual}: NinaPreview3DProps) {
  const vis = visual || ending.visual;

  return (
    <div className="w-full h-44 md:h-52 relative rounded-2xl overflow-hidden border-2 border-white/70 shadow-inner bg-gradient-to-b from-white/95 to-pink-50/80">
      <Canvas
        camera={{position: [0, 1.4, 3.2], fov: 42}}
        gl={{antialias: true, alpha: true}}>
        <Suspense fallback={null}>
          <ambientLight intensity={1.8} color="#fff1f2" />
          <directionalLight position={[4, 7, 5]} intensity={2.8} color="#fffbeb" castShadow />
          <hemisphereLight skyColor="#bae6fd" groundColor="#fbcfe8" intensity={1.0} />

          {/* Universe-specific 3D prop diorama */}
          <EndingPropsDiorama endingId={ending.id} />

          {/* Nina Character Model in Celebration/Characteristic Pose */}
          <group position={[0, -0.45, 0]}>
            <NinaModel
              visual={vis}
              state={ending.id.includes('caos') || ending.id.includes('bancarrota') ? 'ponder' : 'celebrate'}
              scale={1.05}
            />
          </group>

          {/* Camera Subtle Breathing Motion */}
          <GentleCameraWobble />
        </Suspense>
      </Canvas>

      {/* Subtle corner badge reminding universe theme */}
      <div className="absolute bottom-2 right-2 bg-slate-900/60 backdrop-blur-sm text-white text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border border-white/20 pointer-events-none">
        {ending.shortName}
      </div>
    </div>
  );
}

function GentleCameraWobble() {
  const {camera} = useThree();
  useFrame(({clock}) => {
    const t = clock.getElapsedTime();
    camera.position.x = Math.sin(t * 0.8) * 0.15;
    camera.position.y = 1.35 + Math.cos(t * 0.6) * 0.05;
    camera.lookAt(0, 0.8, 0);
  });
  return null;
}

/** Specific 3D miniature scenery items placed around Nina */
function EndingPropsDiorama({endingId}: {endingId: string}) {
  // Cats ending
  if (endingId.includes('gatos') || endingId.includes('refugio')) {
    return (
      <group position={[0, -0.45, 0]}>
        {/* Soft pink round rug */}
        <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[1.5, 24]} />
          <meshStandardMaterial color="#fce7f3" roughness={0.8} />
        </mesh>
        {/* Cat companion on left */}
        <group position={[-0.8, 0.1, 0.3]} rotation={[0, 0.6, 0]}>
          <mesh>
            <capsuleGeometry args={[0.12, 0.2, 4, 10]} />
            <meshStandardMaterial color="#fb923c" />
          </mesh>
          <mesh position={[0, 0.2, 0.05]}>
            <sphereGeometry args={[0.1, 10, 10]} />
            <meshStandardMaterial color="#fb923c" />
          </mesh>
        </group>
        {/* White fluffy cat on right */}
        <group position={[0.75, 0.08, 0.2]} rotation={[0, -0.5, 0]}>
          <mesh>
            <capsuleGeometry args={[0.11, 0.18, 4, 10]} />
            <meshStandardMaterial color="#ffffff" />
          </mesh>
          <mesh position={[0, 0.18, 0.05]}>
            <sphereGeometry args={[0.09, 10, 10]} />
            <meshStandardMaterial color="#ffffff" />
          </mesh>
        </group>
        {/* Small cat bowl */}
        <mesh position={[-0.45, 0.05, 0.6]}>
          <cylinderGeometry args={[0.1, 0.08, 0.06, 12]} />
          <meshStandardMaterial color="#f43f5e" />
        </mesh>
      </group>
    );
  }

  // Magnate / Multimillonaria / Inmobiliaria
  if (endingId.includes('magnate') || endingId.includes('multimillonaria') || endingId.includes('lujo')) {
    return (
      <group position={[0, -0.45, 0]}>
        {/* Golden marble podium */}
        <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[1.6, 24]} />
          <meshStandardMaterial color="#fef08a" metalness={0.4} roughness={0.3} />
        </mesh>
        {/* Small golden pillars in background */}
        <mesh position={[-1.1, 0.7, -0.6]}>
          <cylinderGeometry args={[0.12, 0.14, 1.4, 12]} />
          <meshStandardMaterial color="#fde047" metalness={0.7} roughness={0.2} />
        </mesh>
        <mesh position={[1.1, 0.7, -0.6]}>
          <cylinderGeometry args={[0.12, 0.14, 1.4, 12]} />
          <meshStandardMaterial color="#fde047" metalness={0.7} roughness={0.2} />
        </mesh>
        {/* Sparkling diamond crystal prop */}
        <mesh position={[0.8, 0.25, 0.4]} rotation={[0.4, 0.5, 0]}>
          <octahedronGeometry args={[0.16, 0]} />
          <meshStandardMaterial color="#67e8f9" metalness={0.8} roughness={0.1} />
        </mesh>
      </group>
    );
  }

  // Bancarrota / Caos
  if (endingId.includes('bancarrota') || endingId.includes('caos')) {
    return (
      <group position={[0, -0.45, 0]}>
        <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[1.5, 24]} />
          <meshStandardMaterial color="#e2e8f0" roughness={0.9} />
        </mesh>
        {/* Cardboard moving box */}
        <mesh position={[-0.75, 0.2, 0.2]} rotation={[0, 0.3, 0]}>
          <boxGeometry args={[0.45, 0.4, 0.45]} />
          <meshStandardMaterial color="#d97706" roughness={0.9} />
        </mesh>
        {/* Second smaller tilted box */}
        <mesh position={[0.75, 0.16, 0.3]} rotation={[0.1, -0.4, 0.15]}>
          <boxGeometry args={[0.35, 0.32, 0.35]} />
          <meshStandardMaterial color="#b45309" roughness={0.9} />
        </mesh>
      </group>
    );
  }

  // Mar / Capitana / Olas
  if (endingId.includes('mar') || endingId.includes('olas') || endingId.includes('capitana')) {
    return (
      <group position={[0, -0.45, 0]}>
        {/* Sand / wooden deck */}
        <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[1.5, 24]} />
          <meshStandardMaterial color="#fed7aa" roughness={0.9} />
        </mesh>
        {/* Life preserver ring */}
        <mesh position={[0.8, 0.15, 0.3]} rotation={[0.3, 0.2, 0.6]}>
          <torusGeometry args={[0.2, 0.06, 12, 20]} />
          <meshStandardMaterial color="#f43f5e" roughness={0.4} />
        </mesh>
        {/* Sea conch / shell */}
        <mesh position={[-0.7, 0.08, 0.4]}>
          <coneGeometry args={[0.1, 0.2, 8]} />
          <meshStandardMaterial color="#ffffff" roughness={0.5} />
        </mesh>
      </group>
    );
  }

  // Alpacas
  if (endingId.includes('alpaca')) {
    return (
      <group position={[0, -0.45, 0]}>
        {/* Green grass circle */}
        <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[1.5, 24]} />
          <meshStandardMaterial color="#86efac" roughness={0.8} />
        </mesh>
        {/* Wool bale */}
        <mesh position={[-0.75, 0.2, 0.2]}>
          <sphereGeometry args={[0.24, 12, 12]} />
          <meshStandardMaterial color="#fef08a" roughness={1.0} />
        </mesh>
        {/* Wooden farm fence post */}
        <mesh position={[0.8, 0.3, -0.3]}>
          <boxGeometry args={[0.08, 0.6, 0.08]} />
          <meshStandardMaterial color="#78350f" />
        </mesh>
      </group>
    );
  }

  // Cafeteria / Panaderia / Chef
  if (endingId.includes('cafe') || endingId.includes('panaderia') || endingId.includes('chef')) {
    return (
      <group position={[0, -0.45, 0]}>
        {/* Warm wood parquet floor */}
        <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[1.5, 24]} />
          <meshStandardMaterial color="#fed7aa" roughness={0.6} />
        </mesh>
        {/* Little cafe table with coffee cup */}
        <mesh position={[0.75, 0.3, 0.2]}>
          <cylinderGeometry args={[0.25, 0.25, 0.04, 16]} />
          <meshStandardMaterial color="#78350f" />
        </mesh>
        <mesh position={[0.75, 0.15, 0.2]}>
          <cylinderGeometry args={[0.04, 0.04, 0.3, 8]} />
          <meshStandardMaterial color="#78350f" />
        </mesh>
        <mesh position={[0.75, 0.35, 0.2]}>
          <cylinderGeometry args={[0.05, 0.04, 0.08, 10]} />
          <meshStandardMaterial color="#ffffff" />
        </mesh>
      </group>
    );
  }

  // Default: Pastel Rug + Plant Pot
  return (
    <group position={[0, -0.45, 0]}>
      <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[1.5, 24]} />
        <meshStandardMaterial color="#fbcfe8" roughness={0.7} />
      </mesh>
      {/* Little green plant in pot */}
      <group position={[0.8, 0, 0.2]}>
        <mesh position={[0, 0.15, 0]}>
          <cylinderGeometry args={[0.12, 0.09, 0.25, 12]} />
          <meshStandardMaterial color="#ea580c" />
        </mesh>
        <mesh position={[0, 0.35, 0]}>
          <sphereGeometry args={[0.16, 10, 10]} />
          <meshStandardMaterial color="#34d399" />
        </mesh>
      </group>
    </group>
  );
}
