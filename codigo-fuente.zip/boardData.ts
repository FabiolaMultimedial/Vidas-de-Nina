import {TileData} from './types';

/**
 * Generates an aesthetic winding 3D board path of 50 tiles.
 * Sinuous S-shaped curves across 5 themed life stages.
 */
export function generateBoardTiles(total = 50): TileData[] {
  const tiles: TileData[] = [];

  // Stage palettes
  const STAGE_THEMES = [
    {stage: 1, name: 'Los veintitantos', color: '#fbcfe8', accent: '#f472b6'},
    {stage: 2, name: 'La vida adulta', color: '#a7f3d0', accent: '#34d399'},
    {stage: 3, name: 'Decisiones cuestionables', color: '#e9d5ff', accent: '#c084fc'},
    {stage: 4, name: 'Giros inesperados', color: '#bae6fd', accent: '#38bdf8'},
    {stage: 5, name: 'El destino final', color: '#fef08a', accent: '#fbbf24'},
  ];

  // Mathematical serpentine path across a ~32x32 board
  // We can interpolate an undulating curve with 5 major segments
  for (let i = 0; i < total; i++) {
    const t = i / (total - 1); // 0 to 1
    const stageIndex = Math.min(4, Math.floor(t * 5));
    const stage = (stageIndex + 1) as 1 | 2 | 3 | 4 | 5;
    const theme = STAGE_THEMES[stageIndex];

    // S-curve parametric formula
    // i moves generally from left-bottom to right-top in waves
    const wave = Math.sin(t * Math.PI * 4.5);
    const waveCos = Math.cos(t * Math.PI * 4.5);

    // X coordinates weave between -13 and +13
    const x = wave * 13 + Math.sin(t * Math.PI * 2) * 2;
    // Z coordinates progress from +14 (start) to -14 (finish)
    const z = 14 - t * 28 + waveCos * 1.5;
    // Slight height undulation for subtle toy board realism
    const y = 0.2 + Math.sin(t * Math.PI * 8) * 0.08;

    let type: TileData['type'] = 'adventure';
    if (i === 0) type = 'start';
    else if (i === total - 1) type = 'goal';
    else {
      const typeMod = (i * 7 + stage) % 5;
      if (typeMod === 0) type = 'career';
      else if (typeMod === 1) type = 'love';
      else if (typeMod === 2) type = 'money';
      else if (typeMod === 3) type = 'twist';
      else type = 'adventure';
    }

    tiles.push({
      index: i + 1,
      position: [Number(x.toFixed(2)), Number(y.toFixed(2)), Number(z.toFixed(2))],
      stage,
      type,
      label: i === 0 ? 'INICIO' : i === total - 1 ? 'DESTINO' : `${i + 1}`,
      color: i === 0 ? '#f43f5e' : i === total - 1 ? '#eab308' : theme.color,
      accentColor: theme.accent,
    });
  }

  return tiles;
}

export const BOARD_TILES = generateBoardTiles(50);
