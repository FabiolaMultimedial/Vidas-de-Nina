import {MusicTrack} from './utils/helper';

/** Game configuration schema for LAS MIL VIDAS DE NINA. */
export const CONFIG = {
  // --- Game ---
  title: {
    value: 'Las Mil Vidas de Nina',
    type: 'string',
    label: 'Game Title',
    group: 'Game',
  },
  baseCanvasWidth: {
    value: 1280,
    type: 'number',
    label: 'Base Canvas Width',
    group: 'Game',
  },
  baseCanvasHeight: {
    value: 720,
    type: 'number',
    label: 'Base Canvas Height',
    group: 'Game',
  },

  // --- Camera ---
  fov: {
    value: 45,
    type: 'number',
    label: 'Field of View',
    group: 'Camera',
    min: 30,
    max: 90,
    step: 5,
  },
  cameraX: {
    value: 0,
    type: 'number',
    label: 'Camera X',
    group: 'Camera',
  },
  cameraY: {
    value: 14,
    type: 'number',
    label: 'Camera Y',
    group: 'Camera',
  },
  cameraZ: {
    value: 15,
    type: 'number',
    label: 'Camera Z',
    group: 'Camera',
  },

  // --- Theme & Visuals ---
  backgroundColor: {
    value: '#fce7f3', // Pastel rose sky/mist
    type: 'color',
    label: 'Background Color',
    group: 'Theme',
  },
  primaryColor: {
    value: '#ec4899',
    type: 'color',
    label: 'Primary Color',
    group: 'Theme',
  },
  fontFamily: {
    value: 'system-ui, -apple-system, sans-serif',
    type: 'string',
    label: 'Font Family',
    group: 'Theme',
  },
  ambientColor: {
    value: '#ffe4e6',
    type: 'color',
    label: 'Ambient Light Color',
    group: 'Visuals',
  },
  ambientIntensity: {
    value: 1.6,
    type: 'number',
    label: 'Ambient Intensity',
    group: 'Visuals',
    min: 0,
    max: 5,
    step: 0.1,
  },
  sunColor: {
    value: '#fffbeb',
    type: 'color',
    label: 'Sun Color',
    group: 'Visuals',
  },
  sunIntensity: {
    value: 3.2,
    type: 'number',
    label: 'Sun Intensity',
    group: 'Visuals',
    min: 0,
    max: 10,
    step: 0.1,
  },
  hemiSkyColor: {
    value: '#bae6fd',
    type: 'color',
    label: 'Hemisphere Sky Color',
    group: 'Visuals',
  },
  hemiGroundColor: {
    value: '#fbcfe8',
    type: 'color',
    label: 'Hemisphere Ground Color',
    group: 'Visuals',
  },
  hemiIntensity: {
    value: 0.8,
    type: 'number',
    label: 'Hemisphere Intensity',
    group: 'Visuals',
    min: 0,
    max: 2,
    step: 0.1,
  },

  // --- Physics ---
  gravity: {
    value: -18.0,
    type: 'number',
    label: 'Gravity',
    group: 'Physics',
    min: -30,
    max: 0,
    step: 0.5,
  },

  // --- System ---
  targetFPS: {
    value: 60,
    type: 'number',
    label: 'Target FPS',
    group: 'System',
  },
  stepMs: {
    value: 1000 / 60,
    type: 'number',
    label: 'Step MS',
    group: 'System',
  },
  maxSubSteps: {
    value: 5,
    type: 'number',
    label: 'Max Sub Steps',
    group: 'System',
  },

  // --- Gameplay Rules ---
  totalTiles: {
    value: 50,
    type: 'number',
    label: 'Total Tiles',
    group: 'Rules',
    min: 30,
    max: 70,
    step: 5,
  },
  hopSpeed: {
    value: 5.5,
    type: 'number',
    label: 'Hop Speed',
    group: 'Rules',
    min: 2,
    max: 10,
    step: 0.5,
  },
  startingMoney: {
    value: 1000,
    type: 'number',
    label: 'Starting Money',
    group: 'Rules',
    min: 0,
    max: 5000,
    step: 250,
  },
  startingHappiness: {
    value: 70,
    type: 'number',
    label: 'Starting Happiness',
    group: 'Rules',
    min: 30,
    max: 100,
    step: 5,
  },

  // --- Audio ---
  defaultMusicVolume: {
    value: 0.4,
    type: 'number',
    label: 'Default Music Volume',
    group: 'Audio',
  },
  defaultSfxVolume: {
    value: 0.6,
    type: 'number',
    label: 'Default SFX Volume',
    group: 'Audio',
  },
  backgroundMusicUrl: {
    value: 'https://storage.googleapis.com/assets-gen-playground/musiclibrary/candy_pop.mp3',
    type: 'string',
    label: 'Background Music URL',
    group: 'Audio',
  },
};

// Merge customized config values if present (injected by Playground)
const {playgroundConfig} = globalThis as {
  playgroundConfig?: Record<string, unknown>;
};
if (playgroundConfig) {
  for (const [key, value] of Object.entries(playgroundConfig)) {
    if (key in CONFIG) {
      Object.assign(CONFIG[key as keyof typeof CONFIG], {value});
    }
  }
}

/** Type helper for reading values in game code. */
export type ConfigKey = keyof typeof CONFIG;

/**
 * Gets a configuration value by key.
 * @param key The configuration key.
 * @return The configuration value.
 */
export function getConfig<K extends ConfigKey>(
  key: K,
): (typeof CONFIG)[K]['value'] {
  return CONFIG[key].value;
}

/** Available background music tracks. */
export const AVAILABLE_MUSIC_TRACKS: readonly MusicTrack[] = [
  {
    name: 'candy_pop',
    url: 'https://storage.googleapis.com/assets-gen-playground/musiclibrary/candy_pop.mp3',
    description: 'Bubbly, cute toy-piano pop, ideal for playful board games.',
  },
  {
    name: 'island_breeze',
    url: 'https://storage.googleapis.com/assets-gen-playground/musiclibrary/island_breeze.mp3',
    description: 'Carefree steel drums and ukulele, perfect for relaxed gameplay.',
  },
  {
    name: 'meadow_morning',
    url: 'https://storage.googleapis.com/assets-gen-playground/musiclibrary/meadow_morning.mp3',
    description: 'Cozy acoustic folk with guitar and glockenspiel.',
  },
];
