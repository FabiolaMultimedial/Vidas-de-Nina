import {EndingUniverse, NinaStats, NinaVisualConfig} from './types';

/** The 15 destinies Nina can discover through her choices. */
export const ALL_ENDINGS: EndingUniverse[] = [
  {
    id: 'magnate_accidental',
    universeCode: 'UNIVERSO #024',
    shortName: 'La magnate accidental',
    title: '¡LA MAGNATE ACCIDENTAL!',
    quote: 'Empezó ahorrando monedas y terminó comprando medio vecindario.',
    profession: 'Empresaria Inmobiliaria & Inversora',
    wealthLevel: 'Multimillonaria ($$$$)',
    lifestyle: 'Áticos de lujo, chofer y 12 gatos mimados',
    summary: 'Arriesgó en grande, capitalizó sus decisiones financieras y forjó una fortuna colosal.',
    bgGradient: ['#fef08a', '#f472b6'],
    accentColor: '#eab308',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#fbbf24',
      pantsColor: '#78350f',
      accessory: 'crown',
      auraColor: '#facc15',
    },
    requirements: (stats, tags) =>
      stats.money >= 2200 && stats.career >= 40,
  },
  {
    id: 'reina_gatos',
    universeCode: 'UNIVERSO #013',
    shortName: 'La reina de los gatos',
    title: '¡LA REINA DE LOS GATOS!',
    quote: 'Empezó con uno en la banqueta y ahora tiene un parlamento felino.',
    profession: 'Emperatriz de la República Gatuna',
    wealthLevel: 'Riqueza en atún y ronroneos',
    lifestyle: 'Batas de seda, cojines bordados y 30 felinos felices',
    summary: 'Adoptó a cada gatito que cruzó su puerta y convirtió su mansión en el santuario más dulce del país.',
    bgGradient: ['#fbcfe8', '#c084fc'],
    accentColor: '#d946ef',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#e879f9',
      pantsColor: '#86198f',
      accessory: 'cat',
      auraColor: '#f472b6',
    },
    requirements: (stats, tags) =>
      tags.includes('cat_queen') ||
      tags.includes('first_cat') ||
      tags.includes('shelter_hero'),
  },
  {
    id: 'duena_cafeteria',
    universeCode: 'UNIVERSO #018',
    shortName: 'La dueña del café',
    title: '¡LA DUEÑA DEL CAFÉ!',
    quote: 'El café más aromático de la ciudad y el jazz más suave de la tarde.',
    profession: 'Maestra Barista & Anfitriona',
    wealthLevel: 'Negocio próspero y clientes leales',
    lifestyle: 'Granos tostados a mano y charlas cálidas',
    summary: 'Dejó la oficina, compró una máquina de espresso y su local se convirtió en el corazón del barrio.',
    bgGradient: ['#fde68a', '#fdba74'],
    accentColor: '#b45309',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#d97706',
      pantsColor: '#78350f',
      accessory: 'scarf',
      auraColor: '#f59e0b',
    },
    requirements: (stats, tags) =>
      tags.includes('cafe_owner') || tags.includes('coffee_barista'),
  },
  {
    id: 'chef_estelar',
    universeCode: 'UNIVERSO #031',
    shortName: 'La gran chef',
    title: '¡LA GRAN CHEF!',
    quote: 'Su bistró de alta cocina conquistó a los críticos más exigentes.',
    profession: 'Chef Propietaria & Maestra Culinaria',
    wealthLevel: 'Restaurante con reservas de seis meses',
    lifestyle: 'Ollas de cobre, recetas familiares y copas de vino',
    summary: 'Transformó su talento gastronómico en un bistró legendario donde cada cena es una obra de arte.',
    bgGradient: ['#fed7aa', '#fecdd3'],
    accentColor: '#e11d48',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#f43f5e',
      pantsColor: '#881337',
      accessory: 'chef',
      auraColor: '#fda4af',
    },
    requirements: (stats, tags) =>
      tags.includes('master_chef') || tags.includes('secret_supper'),
  },
  {
    id: 'celeb_accidental',
    universeCode: 'UNIVERSO #077',
    shortName: 'Famosa por accidente',
    title: '¡FAMOSA POR ACCIDENTE!',
    quote: 'Se cayó en el súper con tres sandías y ahora tiene millones de fans.',
    profession: 'Celebridad de Internet & Humorista',
    wealthLevel: 'Patrocinios millonarios',
    lifestyle: 'Alfombras rojas, podcasts y autógrafos en servilletas',
    summary: 'Un video viral de su tropiezo cómico la convirtió en estrella mundial del entretenimiento.',
    bgGradient: ['#fed7aa', '#f43f5e'],
    accentColor: '#f97316',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#fb923c',
      pantsColor: '#9a3412',
      accessory: 'sunglasses',
      auraColor: '#fdba74',
    },
    requirements: (stats, tags) =>
      tags.includes('viral_celebrity') || tags.includes('merch_queen') || tags.includes('tv_star'),
  },
  {
    id: 'reina_alpacas',
    universeCode: 'UNIVERSO #055',
    shortName: 'La reina de las alpacas',
    title: '¡LA REINA DE LAS ALPACAS!',
    quote: 'Compró una finca en las colinas y ahora tiene un reino de lana suave.',
    profession: 'Granjera Suprema & Diseñadora Textil',
    wealthLevel: 'Economía circular y cobijas que abrigan al mundo',
    lifestyle: 'Pasto verde, alpacas que comen de su mano y aire puro',
    summary: 'Dejó la urbe para fundar el santuario de alpacas más tierno y codiciado del país.',
    bgGradient: ['#a7f3d0', '#fef08a'],
    accentColor: '#059669',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#34d399',
      pantsColor: '#065f46',
      accessory: 'scarf',
      auraColor: '#6ee7b7',
    },
    requirements: (stats, tags) =>
      tags.includes('alpaca_dream') || tags.includes('alpaca_farm_owner'),
  },
  {
    id: 'viajera_eterna',
    universeCode: 'UNIVERSO #042',
    shortName: 'La viajera eterna',
    title: '¡LA VIAJERA ETERNA!',
    quote: 'Su pasaporte tiene más sellos que una oficina postal de Tokio.',
    profession: 'Exploradora & Cronista Nómada',
    wealthLevel: 'Libertad absoluta y millas infinitas',
    lifestyle: 'Mochila liviana, trenes nocturnos y amaneceres en 5 continentes',
    summary: 'Aprendió cuatro idiomas, vendió trastos innecesarios y convirtió el planeta en su hogar.',
    bgGradient: ['#bae6fd', '#a7f3d0'],
    accentColor: '#0ea5e9',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#38bdf8',
      pantsColor: '#0369a1',
      accessory: 'backpack',
      auraColor: '#38bdf8',
    },
    requirements: (stats, tags) =>
      stats.adventures >= 45 || tags.includes('wanderlust_init'),
  },
  {
    id: 'capitana_mar',
    universeCode: 'UNIVERSO #052',
    shortName: 'La capitana de altamar',
    title: '¡LA CAPITANA DE ALTAMAR!',
    quote: 'Restauró un velero clásico y ahora surca las olas con brújula de bronce.',
    profession: 'Navegante Oceánica & Capitana',
    wealthLevel: 'Riqueza en puertos acogedores y atardeceres dorados',
    lifestyle: 'Velas al viento y camarote con mapas antiguos',
    summary: 'Conoce cada caleta y cada faro de la costa; el océano es su verdadero patio de recreo.',
    bgGradient: ['#bae6fd', '#c7d2fe'],
    accentColor: '#3b82f6',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#2563eb',
      pantsColor: '#1e3a8a',
      accessory: 'hat',
      auraColor: '#60a5fa',
    },
    requirements: (stats, tags) =>
      tags.includes('sea_captain') || tags.includes('floating_bistro'),
  },
  {
    id: 'directora_ejecutiva',
    universeCode: 'UNIVERSO #089',
    shortName: 'La gran directora',
    title: '¡LA GRAN DIRECTORA!',
    quote: 'Subió cada peldaño de la jerarquía y ahora preside la junta directiva.',
    profession: 'CEO de Corporación Global',
    wealthLevel: 'Sueldo ejecutivo y acciones ($$$$)',
    lifestyle: 'Trajes sastre impecables y agendas internacionales',
    summary: 'Su disciplina y liderazgo la catapultaron a la cima del mundo empresarial.',
    bgGradient: ['#e9d5ff', '#a5f3fc'],
    accentColor: '#9333ea',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#a855f7',
      pantsColor: '#581c87',
      accessory: 'glasses',
      auraColor: '#c084fc',
    },
    requirements: (stats, tags) =>
      stats.career >= 55 && (tags.includes('corporate_ladder') || tags.includes('tech_savvy')),
  },
  {
    id: 'bancarrota_dramatica',
    universeCode: 'UNIVERSO #008',
    shortName: 'Bancarrota con estilo',
    title: '¡BANCARROTA CON ESTILO!',
    quote: 'Perdió hasta el último centavo, pero nadie le quita la sonrisa.',
    profession: 'Ex-Emprendedora & Reinventora',
    wealthLevel: 'Bolsillos transparentes ($0)',
    lifestyle: 'Ramen instantáneo, cupones y anécdotas hilarantes',
    summary: 'Apostó a inversiones locas y quebró, pero su buen humor y amigos leales siguen intactos.',
    bgGradient: ['#e2e8f0', '#cbd5e1'],
    accentColor: '#64748b',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#94a3b8',
      pantsColor: '#334155',
      accessory: 'none',
      auraColor: '#cbd5e1',
    },
    requirements: (stats, tags) =>
      stats.money <= 400 || tags.includes('crypto_ruined'),
  },
  {
    id: 'rica_pero_estresada',
    universeCode: 'UNIVERSO #022',
    shortName: 'La millonaria agobiada',
    title: '¡LA MILLONARIA AGOBIADA!',
    quote: 'Tiene tres áticos de lujo, pero duerme 4 horas mirando correos.',
    profession: 'Inversora de Alto Rendimiento',
    wealthLevel: 'Cuentas bancarias millonarias ($$$$)',
    lifestyle: 'Café triple de noche, llamadas urgentes y mansiones vacías',
    summary: 'Consiguió amasar una inmensa fortuna a costa de agotar por completo su energía vital.',
    bgGradient: ['#cbd5e1', '#fbcfe8'],
    accentColor: '#475569',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#475569',
      pantsColor: '#1e293b',
      accessory: 'glasses',
      auraColor: '#94a3b8',
    },
    requirements: (stats, tags) =>
      stats.money >= 1800 && (stats.energy <= 2 || stats.happiness <= 50),
  },
  {
    id: 'campeona_siesta',
    universeCode: 'UNIVERSO #030',
    shortName: 'La reina de la siesta',
    title: '¡LA REINA DE LA SIESTA!',
    quote: 'En un mundo que corre sin parar, Nina dominó el arte de la siesta perfecta.',
    profession: 'Maestra de la Serenidad & Experta en Descanso',
    wealthLevel: 'Paz mental infinita y cero prisas',
    lifestyle: 'Pijamas de seda, almohadas ergonómicas y té caliente',
    summary: 'Rechazó el estrés para demostrarle al mundo que descansar y vivir el presente es una virtud suprema.',
    bgGradient: ['#e9d5ff', '#fed7aa'],
    accentColor: '#8b5cf6',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#c4b5fd',
      pantsColor: '#5b21b6',
      accessory: 'none',
      auraColor: '#ddd6fe',
    },
    requirements: (stats, tags) =>
      stats.energy >= 4 && tags.includes('deep_rest'),
  },
  {
    id: 'frente_al_mar',
    universeCode: 'UNIVERSO #033',
    shortName: 'La guardiana de las olas',
    title: '¡LA GUARDIANA DE LAS OLAS!',
    quote: 'Cambió los tacones por arena tibia y conchitas de mar.',
    profession: 'Escritora Costera & Maestra de Yoga',
    wealthLevel: 'Suficiente para fruta tropical y café fresco',
    lifestyle: 'Cabaña de madera, brisa salada y paseos descalza',
    summary: 'Se mudó a una costa tranquila, escribe novelas junto al mar y despide al sol cada tarde.',
    bgGradient: ['#bae6fd', '#fed7aa'],
    accentColor: '#0284c7',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#38bdf8',
      pantsColor: '#0284c7',
      accessory: 'hat',
      auraColor: '#7dd3fc',
    },
    requirements: (stats, tags) =>
      tags.includes('ocean_life') || tags.includes('surf_guru'),
  },
  {
    id: 'vida_bohemia_feliz',
    universeCode: 'UNIVERSO #019',
    shortName: 'La artista bohemia',
    title: '¡LA ARTISTA BOHEMIA!',
    quote: 'Pinta cuadros, hace cerámica y sus amigos llenan la casa de música.',
    profession: 'Artesana & Creadora Independiente',
    wealthLevel: 'Suficiente para arcilla, queso y buen vino',
    lifestyle: 'Taller colorido, plantas y veladas bohemias',
    summary: 'Eligió el arte y la libertad; vive de sus creaciones manuales rodeada de personas queridas.',
    bgGradient: ['#fed7aa', '#fbcfe8'],
    accentColor: '#f97316',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#f97316',
      pantsColor: '#7c2d12',
      accessory: 'scarf',
      auraColor: '#fdba74',
    },
    requirements: (stats, tags) =>
      tags.includes('artisan_soul') || tags.includes('thrifter'),
  },
  {
    id: 'vida_sencilla_feliz',
    universeCode: 'UNIVERSO #001',
    shortName: 'La sabia de la calma',
    title: '¡LA SABIA DE LA CALMA!',
    quote: 'Descubrió que la mayor riqueza cabe en una taza de té y una buena risa.',
    profession: 'Hortelana & Vecina Entrañable',
    wealthLevel: 'Tranquilidad económica y cero deudas',
    lifestyle: 'Huerto con tomates jugosos y sobremesas largas',
    summary: 'Eludió las prisas modernas, cuidó sus afectos y cosechó una paz que el dinero jamás podrá comprar.',
    bgGradient: ['#fbcfe8', '#fef08a'],
    accentColor: '#f43f5e',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#f472b6',
      pantsColor: '#9d174d',
      accessory: 'none',
      auraColor: '#fbcfe8',
    },
    requirements: (stats, tags) =>
      stats.happiness >= 75 && stats.relationships >= 45 && stats.career < 50 && stats.money < 1800,
  },
];

/** Major life choices outweigh generic stats; related choices reinforce one another. */
const ENDING_TAGS: Record<string, Record<string, number>> = {
  magnate_accidental: {wealthy_investor: 100, ultra_rich: 110, crypto_lucky: 45, frugal_mindset: 25},
  reina_gatos: {cat_queen: 110, sanctuary_founder: 110, first_cat: 45, shelter_hero: 55},
  duena_cafeteria: {cafe_owner: 110, coffee_barista: 80, entrepreneur_spark: 35},
  chef_estelar: {master_chef: 110, secret_supper: 100, floating_bistro: 55},
  celeb_accidental: {viral_celebrity: 110, merch_queen: 100, tv_star: 110},
  reina_alpacas: {alpaca_dream: 110, alpaca_farm_owner: 120},
  viajera_eterna: {wanderlust_init: 100},
  capitana_mar: {sea_captain: 120, floating_bistro: 100},
  directora_ejecutiva: {corporate_ladder: 70, tech_savvy: 55, remote_tech: 90, green_ceo: 120},
  bancarrota_dramatica: {},
  rica_pero_estresada: {},
  campeona_siesta: {deep_rest: 105, bold_negotiator: 35},
  frente_al_mar: {ocean_life: 120, surf_guru: 110},
  vida_bohemia_feliz: {artisan_soul: 100, thrifter: 45, independent_queen: 25},
  vida_sencilla_feliz: {humanitarian_hero: 90},
};

export function determineEnding(stats: NinaStats, tags: string[]): EndingUniverse {
  const uniqueTags = [...new Set(tags)].filter((tag) => tag !== 'universe_unlocked');
  const money = Math.max(0, stats.money);
  const metricScores: Record<string, number> = {
    magnate_accidental: Math.min(40, money / 120) + stats.career * 0.1,
    reina_gatos: stats.relationships * 0.15,
    duena_cafeteria: stats.relationships * 0.12 + stats.career * 0.08,
    chef_estelar: stats.career * 0.15,
    celeb_accidental: stats.career * 0.1 + stats.adventures * 0.1,
    reina_alpacas: stats.happiness * 0.1,
    viajera_eterna: stats.adventures * 0.65,
    capitana_mar: stats.adventures * 0.2,
    directora_ejecutiva: stats.career * 0.35,
    bancarrota_dramatica: money <= 400 ? 160 + (400 - money) / 20 : 0,
    rica_pero_estresada: money >= 1800 && (stats.energy <= 2 || stats.happiness <= 50) ? 165 : 0,
    campeona_siesta: stats.energy >= 4 ? 30 + stats.energy * 4 : 0,
    frente_al_mar: stats.adventures * 0.1 + stats.happiness * 0.1,
    vida_bohemia_feliz: stats.relationships * 0.25,
    vida_sencilla_feliz: stats.happiness >= 75 && stats.relationships >= 45 && stats.career < 50 && money < 1800 ? 55 : 0,
  };

  const scored = ALL_ENDINGS.map((ending) => {
    const affinities = ENDING_TAGS[ending.id];
    // Bankruptcy must reflect current finances, not an old loss already recovered from.
    const matches = uniqueTags.flatMap((tag, index) => affinities[tag]
      ? [{weight: affinities[tag], index}] : []);
    const strongest = matches.length ? Math.max(...matches.map((match) => match.weight)) : 0;
    const reinforcement = matches.reduce((sum, match) => sum + match.weight, 0) - strongest;
    const latest = matches.length ? Math.max(...matches.map((match) => match.index)) : -1;
    const recency = latest >= 0 ? 8 * (latest + 1) / uniqueTags.length : 0;
    return {ending, score: strongest + Math.min(35, reinforcement * 0.35) + recency + metricScores[ending.id], latest};
  });

  // Stable for the same story; never biased by the order of the ending catalogue.
  scored.sort((a, b) => b.score - a.score || b.latest - a.latest || a.ending.id.localeCompare(b.ending.id));
  return scored[0].ending;
}

/**
 * Frases finales: cada partida muestra una distinta al azar,
 * para que nadie vea siempre el mismo cierre.
 */
export const CLOSING_PHRASES: string[] = [
  'Nina miró atrás, sonrió y supo que cada tropiezo valió la pena.',
  'No fue la vida que planeó, pero fue exactamente la que necesitaba.',
  'Entre risas, errores y chocolate, Nina escribió su mejor historia.',
  'Mil vidas posibles y esta es la que le quedó perfecta.',
  'Nina descubrió que la felicidad era el camino, no la meta.',
  'Con los bolsillos llenos de recuerdos, Nina se sintió millonaria.',
  'Si pudiera empezar otra vez, cambiaría poco y bailaría más.',
  'Cada decisión dejó una huella y todas juntas formaron un mapa precioso.',
  'Nina aprendió a decir que sí a lo que ama y que no a lo que pesa.',
  'Al final, lo que importó fue con quién compartió la mesa.',
  'Una vida imperfecta, graciosa y totalmente suya.',
  'Nina cerró los ojos, escuchó su propia risa y supo que estaba en casa.',
  'Sus mejores aventuras empezaron cuando se atrevió a no tener un plan.',
  'El universo le guiñó un ojo y ella le devolvió una carcajada.',
  'Nina no ganó todos los juegos, pero jamás dejó de jugar.',
];

export function pickClosingPhrase(): string {
  return CLOSING_PHRASES[Math.floor(Math.random() * CLOSING_PHRASES.length)];
}
