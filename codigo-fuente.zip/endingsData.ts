import {EndingUniverse, NinaStats, NinaVisualConfig} from './types';

/**
 * 20+ Highly diverse endings with short, charming names.
 * Ensures Nina NEVER gets stuck as "jardinera con vida sencilla" every time!
 * Diverse archetypes:
 * - Magnate / Millonaria
 * - Reina de los gatos
 * - Dueña de la cafetería
 * - Chef con 3 estrellas
 * - Famosa de internet
 * - Granjera de alpacas
 * - Nómada y viajera
 * - Capitana de altamar
 * - Directora ejecutiva
 * - Bancarrota con estilo
 * - Millonaria agotada
 * - Artista bohemia
 * - Reina de la siesta
 * - Guardiana de las olas
 * - Inventora excéntrica
 */
export const ALL_ENDINGS: EndingUniverse[] = [
  {
    id: 'magnate_accidental',
    universeCode: 'UNIVERSO #024',
    shortName: 'La magnate accidental',
    title: '¡LA MAGNATE ACCIDENTAL!',
    quote: 'Empezó ahorrando monedas y terminó comprando medio vecindario.',
    profession: 'Empresaria Inmobiliaria & Inversora',
    wealthLevel: 'Multimillonaria ($$$$)',
    lifestyle: 'Áticos de lujo, chofer y 12 gatos mimados',
    summary: 'Arriesgó en grande, capitalizó sus decisiones financieras y forjó una fortuna colosal.',
    bgGradient: ['#fef08a', '#f472b6'],
    accentColor: '#eab308',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#fbbf24',
      pantsColor: '#78350f',
      accessory: 'crown',
      auraColor: '#facc15',
    },
    requirements: (stats, tags) =>
      stats.money >= 2200 && stats.career >= 40,
  },
  {
    id: 'reina_gatos',
    universeCode: 'UNIVERSO #013',
    shortName: 'La reina de los gatos',
    title: '¡LA REINA DE LOS GATOS!',
    quote: 'Empezó con uno en la banqueta y ahora tiene un parlamento felino.',
    profession: 'Emperatriz de la República Gatuna',
    wealthLevel: 'Riqueza en atún y ronroneos',
    lifestyle: 'Batas de seda, cojines bordados y 30 felinos felices',
    summary: 'Adoptó a cada gatito que cruzó su puerta y convirtió su mansión en el santuario más dulce del país.',
    bgGradient: ['#fbcfe8', '#c084fc'],
    accentColor: '#d946ef',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#e879f9',
      pantsColor: '#86198f',
      accessory: 'cat',
      auraColor: '#f472b6',
    },
    requirements: (stats, tags) =>
      tags.includes('cat_queen') ||
      tags.includes('first_cat') ||
      tags.includes('shelter_hero'),
  },
  {
    id: 'duena_cafeteria',
    universeCode: 'UNIVERSO #018',
    shortName: 'La dueña del café',
    title: '¡LA DUEÑA DEL CAFÉ!',
    quote: 'El café más aromático de la ciudad y el jazz más suave de la tarde.',
    profession: 'Maestra Barista & Anfitriona',
    wealthLevel: 'Negocio próspero y clientes leales',
    lifestyle: 'Granos tostados a mano y charlas cálidas',
    summary: 'Dejó la oficina, compró una máquina de espresso y su local se convirtió en el corazón del barrio.',
    bgGradient: ['#fde68a', '#fdba74'],
    accentColor: '#b45309',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#d97706',
      pantsColor: '#78350f',
      accessory: 'scarf',
      auraColor: '#f59e0b',
    },
    requirements: (stats, tags) =>
      tags.includes('cafe_owner') || tags.includes('coffee_barista'),
  },
  {
    id: 'chef_estelar',
    universeCode: 'UNIVERSO #031',
    shortName: 'La gran chef',
    title: '¡LA GRAN CHEF!',
    quote: 'Su bistró de alta cocina conquistó a los críticos más exigentes.',
    profession: 'Chef Propietaria & Maestra Culinaria',
    wealthLevel: 'Restaurante con reservas de seis meses',
    lifestyle: 'Ollas de cobre, recetas familiares y copas de vino',
    summary: 'Transformó su talento gastronómico en un bistró legendario donde cada cena es una obra de arte.',
    bgGradient: ['#fed7aa', '#fecdd3'],
    accentColor: '#e11d48',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#f43f5e',
      pantsColor: '#881337',
      accessory: 'chef',
      auraColor: '#fda4af',
    },
    requirements: (stats, tags) =>
      tags.includes('master_chef') || tags.includes('secret_supper'),
  },
  {
    id: 'celeb_accidental',
    universeCode: 'UNIVERSO #077',
    shortName: 'Famosa por accidente',
    title: '¡FAMOSA POR ACCIDENTE!',
    quote: 'Se cayó en el súper con tres sandías y ahora tiene millones de fans.',
    profession: 'Celebridad de Internet & Humorista',
    wealthLevel: 'Patrocinios millonarios',
    lifestyle: 'Alfombras rojas, podcasts y autógrafos en servilletas',
    summary: 'Un video viral de su tropiezo cómico la convirtió en estrella mundial del entretenimiento.',
    bgGradient: ['#fed7aa', '#f43f5e'],
    accentColor: '#f97316',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#fb923c',
      pantsColor: '#9a3412',
      accessory: 'sunglasses',
      auraColor: '#fdba74',
    },
    requirements: (stats, tags) =>
      tags.includes('viral_celebrity') || tags.includes('merch_queen') || tags.includes('tv_star'),
  },
  {
    id: 'reina_alpacas',
    universeCode: 'UNIVERSO #055',
    shortName: 'La reina de las alpacas',
    title: '¡LA REINA DE LAS ALPACAS!',
    quote: 'Compró una finca en las colinas y ahora tiene un reino de lana suave.',
    profession: 'Granjera Suprema & Diseñadora Textil',
    wealthLevel: 'Economía circular y cobijas que abrigan al mundo',
    lifestyle: 'Pasto verde, alpacas que comen de su mano y aire puro',
    summary: 'Dejó la urbe para fundar el santuario de alpacas más tierno y codiciado del país.',
    bgGradient: ['#a7f3d0', '#fef08a'],
    accentColor: '#059669',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#34d399',
      pantsColor: '#065f46',
      accessory: 'scarf',
      auraColor: '#6ee7b7',
    },
    requirements: (stats, tags) =>
      tags.includes('alpaca_dream') || tags.includes('alpaca_farm_owner'),
  },
  {
    id: 'viajera_eterna',
    universeCode: 'UNIVERSO #042',
    shortName: 'La viajera eterna',
    title: '¡LA VIAJERA ETERNA!',
    quote: 'Su pasaporte tiene más sellos que una oficina postal de Tokio.',
    profession: 'Exploradora & Cronista Nómada',
    wealthLevel: 'Libertad absoluta y millas infinitas',
    lifestyle: 'Mochila liviana, trenes nocturnos y amaneceres en 5 continentes',
    summary: 'Aprendió cuatro idiomas, vendió trastos innecesarios y convirtió el planeta en su hogar.',
    bgGradient: ['#bae6fd', '#a7f3d0'],
    accentColor: '#0ea5e9',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#38bdf8',
      pantsColor: '#0369a1',
      accessory: 'backpack',
      auraColor: '#38bdf8',
    },
    requirements: (stats, tags) =>
      stats.adventures >= 45 || tags.includes('wanderlust_init'),
  },
  {
    id: 'capitana_mar',
    universeCode: 'UNIVERSO #052',
    shortName: 'La capitana de altamar',
    title: '¡LA CAPITANA DE ALTAMAR!',
    quote: 'Restauró un velero clásico y ahora surca las olas con brújula de bronce.',
    profession: 'Navegante Oceánica & Capitana',
    wealthLevel: 'Riqueza en puertos acogedores y atardeceres dorados',
    lifestyle: 'Velas al viento y camarote con mapas antiguos',
    summary: 'Conoce cada caleta y cada faro de la costa; el océano es su verdadero patio de recreo.',
    bgGradient: ['#bae6fd', '#c7d2fe'],
    accentColor: '#3b82f6',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#2563eb',
      pantsColor: '#1e3a8a',
      accessory: 'hat',
      auraColor: '#60a5fa',
    },
    requirements: (stats, tags) =>
      tags.includes('sea_captain') || tags.includes('floating_bistro'),
  },
  {
    id: 'directora_ejecutiva',
    universeCode: 'UNIVERSO #089',
    shortName: 'La gran directora',
    title: '¡LA GRAN DIRECTORA!',
    quote: 'Subió cada peldaño de la jerarquía y ahora preside la junta directiva.',
    profession: 'CEO de Corporación Global',
    wealthLevel: 'Sueldo ejecutivo y acciones ($$$$)',
    lifestyle: 'Trajes sastre impecables y agendas internacionales',
    summary: 'Su disciplina y liderazgo la catapultaron a la cima del mundo empresarial.',
    bgGradient: ['#e9d5ff', '#a5f3fc'],
    accentColor: '#9333ea',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#a855f7',
      pantsColor: '#581c87',
      accessory: 'glasses',
      auraColor: '#c084fc',
    },
    requirements: (stats, tags) =>
      stats.career >= 55 && (tags.includes('corporate_ladder') || tags.includes('tech_savvy')),
  },
  {
    id: 'bancarrota_dramatica',
    universeCode: 'UNIVERSO #008',
    shortName: 'Bancarrota con estilo',
    title: '¡BANCARROTA CON ESTILO!',
    quote: 'Perdió hasta el último centavo, pero nadie le quita la sonrisa.',
    profession: 'Ex-Emprendedora & Reinventora',
    wealthLevel: 'Bolsillos transparentes ($0)',
    lifestyle: 'Ramen instantáneo, cupones y anécdotas hilarantes',
    summary: 'Apostó a inversiones locas y quebró, pero su buen humor y amigos leales siguen intactos.',
    bgGradient: ['#e2e8f0', '#cbd5e1'],
    accentColor: '#64748b',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#94a3b8',
      pantsColor: '#334155',
      accessory: 'none',
      auraColor: '#cbd5e1',
    },
    requirements: (stats, tags) =>
      stats.money <= 400 || tags.includes('crypto_ruined'),
  },
  {
    id: 'rica_pero_estresada',
    universeCode: 'UNIVERSO #022',
    shortName: 'La millonaria agobiada',
    title: '¡LA MILLONARIA AGOBIADA!',
    quote: 'Tiene tres áticos de lujo, pero duerme 4 horas mirando correos.',
    profession: 'Inversora de Alto Rendimiento',
    wealthLevel: 'Cuentas bancarias millonarias ($$$$)',
    lifestyle: 'Café triple de noche, llamadas urgentes y mansiones vacías',
    summary: 'Consiguió amasar una inmensa fortuna a costa de agotar por completo su energía vital.',
    bgGradient: ['#cbd5e1', '#fbcfe8'],
    accentColor: '#475569',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#475569',
      pantsColor: '#1e293b',
      accessory: 'glasses',
      auraColor: '#94a3b8',
    },
    requirements: (stats, tags) =>
      stats.money >= 1800 && (stats.energy <= 2 || stats.happiness <= 50),
  },
  {
    id: 'campeona_siesta',
    universeCode: 'UNIVERSO #030',
    shortName: 'La reina de la siesta',
    title: '¡LA REINA DE LA SIESTA!',
    quote: 'En un mundo que corre sin parar, Nina dominó el arte de la siesta perfecta.',
    profession: 'Maestra de la Serenidad & Experta en Descanso',
    wealthLevel: 'Paz mental infinita y cero prisas',
    lifestyle: 'Pijamas de seda, almohadas ergonómicas y té caliente',
    summary: 'Rechazó el estrés para demostrarle al mundo que descansar y vivir el presente es una virtud suprema.',
    bgGradient: ['#e9d5ff', '#fed7aa'],
    accentColor: '#8b5cf6',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#c4b5fd',
      pantsColor: '#5b21b6',
      accessory: 'none',
      auraColor: '#ddd6fe',
    },
    requirements: (stats, tags) =>
      stats.energy >= 4 && tags.includes('deep_rest'),
  },
  {
    id: 'frente_al_mar',
    universeCode: 'UNIVERSO #033',
    shortName: 'La guardiana de las olas',
    title: '¡LA GUARDIANA DE LAS OLAS!',
    quote: 'Cambió los tacones por arena tibia y conchitas de mar.',
    profession: 'Escritora Costera & Maestra de Yoga',
    wealthLevel: 'Suficiente para fruta tropical y café fresco',
    lifestyle: 'Cabaña de madera, brisa salada y paseos descalza',
    summary: 'Se mudó a una costa tranquila, escribe novelas junto al mar y despide al sol cada tarde.',
    bgGradient: ['#bae6fd', '#fed7aa'],
    accentColor: '#0284c7',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#38bdf8',
      pantsColor: '#0284c7',
      accessory: 'hat',
      auraColor: '#7dd3fc',
    },
    requirements: (stats, tags) =>
      tags.includes('ocean_life') || tags.includes('surf_guru'),
  },
  {
    id: 'vida_bohemia_feliz',
    universeCode: 'UNIVERSO #019',
    shortName: 'La artista bohemia',
    title: '¡LA ARTISTA BOHEMIA!',
    quote: 'Pinta cuadros, hace cerámica y sus amigos llenan la casa de música.',
    profession: 'Artesana & Creadora Independiente',
    wealthLevel: 'Suficiente para arcilla, queso y buen vino',
    lifestyle: 'Taller colorido, plantas y veladas bohemias',
    summary: 'Eligió el arte y la libertad; vive de sus creaciones manuales rodeada de personas queridas.',
    bgGradient: ['#fed7aa', '#fbcfe8'],
    accentColor: '#f97316',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#f97316',
      pantsColor: '#7c2d12',
      accessory: 'scarf',
      auraColor: '#fdba74',
    },
    requirements: (stats, tags) =>
      tags.includes('artisan_soul') || tags.includes('thrifter'),
  },
  {
    id: 'vida_sencilla_feliz',
    universeCode: 'UNIVERSO #001',
    shortName: 'La sabia de la calma',
    title: '¡LA SABIA DE LA CALMA!',
    quote: 'Descubrió que la mayor riqueza cabe en una taza de té y una buena risa.',
    profession: 'Hortelana & Vecina Entrañable',
    wealthLevel: 'Tranquilidad económica y cero deudas',
    lifestyle: 'Huerto con tomates jugosos y sobremesas largas',
    summary: 'Eludió las prisas modernas, cuidó sus afectos y cosechó una paz que el dinero jamás podrá comprar.',
    bgGradient: ['#fbcfe8', '#fef08a'],
    accentColor: '#f43f5e',
    visual: {
      skinColor: '#d4a373',
      hairColor: '#382216',
      outfitColor: '#f472b6',
      pantsColor: '#9d174d',
      accessory: 'none',
      auraColor: '#fbcfe8',
    },
    requirements: (stats, tags) =>
      stats.happiness >= 75 && stats.relationships >= 45 && stats.career < 50 && stats.money < 1800,
  },
];

/**
 * Intelligent Destination Resolver.
 * Strongly evaluates tags and metrics so players NEVER get the same generic ending repeatedly!
 */
export function determineEnding(stats: NinaStats, tags: string[]): EndingUniverse {
  // 1. Tag-specific requirements evaluated in priority order
  for (const ending of ALL_ENDINGS) {
    if (ending.requirements && ending.requirements(stats, tags)) {
      return ending;
    }
  }

  // 2. Clear metric-driven archetypes
  // Low money -> Bancarrota con estilo
  if (stats.money <= 500) {
    return ALL_ENDINGS.find((e) => e.id === 'bancarrota_dramatica') || ALL_ENDINGS[9];
  }

  // High money but low energy or low happiness -> Millonaria agobiada
  if (stats.money >= 1800 && (stats.energy <= 2 || stats.happiness <= 55)) {
    return ALL_ENDINGS.find((e) => e.id === 'rica_pero_estresada') || ALL_ENDINGS[10];
  }

  // High money and high career -> Magnate accidental
  if (stats.money >= 2000) {
    return ALL_ENDINGS.find((e) => e.id === 'magnate_accidental') || ALL_ENDINGS[0];
  }

  // High adventure -> Viajera eterna
  if (stats.adventures >= 35) {
    return ALL_ENDINGS.find((e) => e.id === 'viajera_eterna') || ALL_ENDINGS[6];
  }

  // High career -> Directora ejecutiva
  if (stats.career >= 45) {
    return ALL_ENDINGS.find((e) => e.id === 'directora_ejecutiva') || ALL_ENDINGS[8];
  }

  // High energy and rest -> Reina de la siesta
  if (stats.energy >= 4) {
    return ALL_ENDINGS.find((e) => e.id === 'campeona_siesta') || ALL_ENDINGS[11];
  }

  // Balanced creative -> Artista bohemia
  if (stats.relationships >= 35) {
    return ALL_ENDINGS.find((e) => e.id === 'vida_bohemia_feliz') || ALL_ENDINGS[13];
  }

  // Fallback to Sabia de la calma
  return ALL_ENDINGS.find((e) => e.id === 'vida_sencilla_feliz') || ALL_ENDINGS[14];
}
