import {BoardEvent} from './types';

/**
 * Robust catalog of 20+ varied situations across stages.
 * Each choice produces distinct impacts on Money, Happiness, Energy (-2 to +2), Career, Relationships and Adventures.
 * Generates unique storyline logs and unlocks varied tags for divergent destinations.
 */
export const GAME_EVENTS: BoardEvent[] = [
  // ==========================================
  // ETAPA 1: LOS VEINTITANTOS (6 eventos)
  // ==========================================
  {
    id: 'e1_jefe_ascenso',
    stage: 1,
    title: 'TU JEFE TE OFRECE UN ASCENSO',
    subtitle: 'Viene con aumento, pero responderás mensajes en domingo.',
    situation: 'Te ofrecen coordinar el equipo con 50% más de sueldo a cambio de estar siempre disponible.',
    category: 'work',
    options: [
      {
        key: 'A',
        label: 'Aceptar porque necesitas dinero',
        description: 'Tus ingresos aumentan, pero tu energía cae en picado.',
        effect: {money: 750, energy: -2, career: 25, happiness: -15, tag: 'corporate_ladder', log: 'Aceptó un ascenso corporativo absorbente'},
      },
      {
        key: 'B',
        label: 'Renunciar para emprender',
        description: 'Gastas ahorros en tu proyecto, pero recuperas tu ilusión.',
        effect: {money: -350, energy: -1, career: 15, happiness: 20, adventures: 20, tag: 'entrepreneur_spark', log: 'Renunció para emprender su propio negocio'},
      },
      {
        key: 'C',
        label: 'Pedir vacaciones y probar suerte',
        description: 'Tu jefa se sorprende, pero te concede días de descanso.',
        effect: {money: -50, energy: 2, happiness: 25, career: -5, tag: 'bold_negotiator', log: 'Negoció vacaciones sin miedo y recargó pilas'},
      },
    ],
  },
  {
    id: 'e1_piso_compartido',
    stage: 1,
    title: 'SE BUSCA COMPAÑERO DE PISO',
    subtitle: 'El alquiler en la ciudad está por las nubes.',
    situation: 'Encuentras un piso compartido con tres personas bohemias que tocan el ukelele de madrugada.',
    category: 'friendship',
    options: [
      {
        key: 'A',
        label: 'Aceptar el cuarto pequeño',
        description: 'Ahorras bastante pero duermes con tapones.',
        effect: {money: 350, energy: -1, relationships: 15, happiness: -5, log: 'Vivió en piso compartido con bohemios ruidosos'},
      },
      {
        key: 'B',
        label: 'Alquilar un estudio tú sola',
        description: 'Paz absoluta, aunque tu cuenta bancaria sufra.',
        effect: {money: -450, energy: 1, happiness: 25, tag: 'independent_queen', log: 'Alquiló su propio estudio independiente'},
      },
      {
        key: 'C',
        label: 'Volver a casa familiar un tiempo',
        description: 'Comida casera deliciosa, pero cero privacidad.',
        effect: {money: 400, energy: 1, relationships: 20, happiness: 5, log: 'Volvió al nido familiar para ahorrar'},
      },
    ],
  },
  {
    id: 'e1_viaje_mochilazo',
    stage: 1,
    title: 'VIAJE MOCHILERO IMPROVISADO',
    subtitle: 'Tres semanas recorriendo pueblitos en tren.',
    situation: 'Tus amigos compran boletos baratos sin alojamiento reservado.',
    category: 'travel',
    options: [
      {
        key: 'A',
        label: 'Empacar la mochila y salir corriendo',
        description: 'Gastas dinero y energía caminando, pero vives una gran aventura.',
        effect: {money: -350, energy: -1, happiness: 35, adventures: 40, tag: 'wanderlust_init', log: 'Recorrió pueblos de mochilera viviendo aventuras'},
      },
      {
        key: 'B',
        label: 'Quedarte a trabajar horas extras',
        description: 'El banco sonríe; tu espíritu aventurero bosteza.',
        effect: {money: 450, energy: -2, career: 20, happiness: -10, log: 'Eligió horas extras y acumuló ahorros'},
      },
      {
        key: 'C',
        label: 'Unirte solo el último fin de semana',
        description: 'Llegas directo a la fiesta final sin gastar demasiado.',
        effect: {money: -120, energy: 0, happiness: 20, relationships: 20, log: 'Se unió a la fiesta final con amigos'},
      },
    ],
  },
  {
    id: 'e1_bootcamp_tech',
    stage: 1,
    title: 'CURSO INTENSIVO DE NOCHE',
    subtitle: 'Aprender diseño digital y código.',
    situation: 'Ofrecen un curso intensivo que exige estudiar 4 horas diarias tras el trabajo.',
    category: 'work',
    options: [
      {
        key: 'A',
        label: 'Pagar matrícula y desvelarte estudiando',
        description: 'Agotamiento puro, pero adquieres habilidades cotizadas.',
        effect: {money: -300, energy: -2, career: 35, happiness: -5, tag: 'tech_savvy', log: 'Se desveló estudiando código para superarse'},
      },
      {
        key: 'B',
        label: 'Aprender gratis a tu propio ritmo',
        description: 'Avanzas despacio pero sin perder horas de sueño.',
        effect: {money: 0, energy: 0, career: 15, happiness: 15, log: 'Estudió a su propio ritmo con calma'},
      },
      {
        key: 'C',
        label: 'Inscribirte mejor a un taller de cerámica',
        description: 'Modelas arcilla relajada y haces nuevas amistades.',
        effect: {money: -120, energy: 1, happiness: 30, adventures: 15, tag: 'artisan_soul', log: 'Descubrió su pasión por la cerámica artesanal'},
      },
    ],
  },
  {
    id: 'e1_gatito_lluvia',
    stage: 1,
    title: 'UN GATITO EN EL PORTAL',
    subtitle: 'Llueve torrencialmente y te mira fijamente.',
    situation: 'Una pequeña bola de pelos maúlla aterida de frío bajo tu escalera.',
    category: 'absurd',
    options: [
      {
        key: 'A',
        label: 'Adoptarlo y comprarle camita',
        description: 'Gastas en veterinario, pero tu hogar se llena de ternura.',
        effect: {money: -150, energy: 1, happiness: 40, relationships: 15, tag: 'first_cat', log: 'Adoptó a su primer gatito bajo la lluvia'},
      },
      {
        key: 'B',
        label: 'Buscarle un hogar con una vecina adinerada',
        description: 'El gato vivirá como rey y tú lo visitas a menudo.',
        effect: {money: 50, energy: 0, happiness: 20, relationships: 20, log: 'Le encontró un hogar palaciego a un gatito'},
      },
      {
        key: 'C',
        label: 'Llevarlo al refugio y hacerte voluntaria',
        description: 'Cansas tus fines de semana cuidando animales con amor.',
        effect: {money: -40, energy: -1, happiness: 35, adventures: 15, tag: 'shelter_hero', log: 'Se unió como voluntaria de rescate animal'},
      },
    ],
  },
  {
    id: 'e1_oferta_linea',
    stage: 1,
    title: 'OFERTA IRRESISTIBLE EN LÍNEA',
    subtitle: 'Un abrigo de diseñador con supuesto descuento.',
    situation: 'Aparece en pantalla ese abrigo que siempre quisiste, pero el precio sigue siendo alto.',
    category: 'money',
    options: [
      {
        key: 'A',
        label: 'Comprarlo en cuotas sin pensar',
        description: 'Luce fabuloso aunque tengas que apretarte el cinturón.',
        effect: {money: -300, energy: 0, happiness: 15, tag: 'chic_fashion', log: 'Compró ropa de diseñador a crédito'},
      },
      {
        key: 'B',
        label: 'Cerrar la pestaña y meter dinero al ahorro',
        description: 'Fuerza de voluntad que protege tu economía.',
        effect: {money: 200, energy: 0, happiness: 5, tag: 'frugal_mindset', log: 'Demostró disciplina de ahorro impecable'},
      },
      {
        key: 'C',
        label: 'Buscarlo vintage en un mercadillo',
        description: 'Encuentras uno retro aún más original por poco dinero.',
        effect: {money: -60, energy: -1, happiness: 25, adventures: 15, tag: 'thrifter', log: 'Cazó tesoros vintage en el mercadillo'},
      },
    ],
  },

  // ==========================================
  // ETAPA 2: LA VIDA ADULTA (5 eventos)
  // ==========================================
  {
    id: 'e2_herencia_gatos',
    stage: 2,
    title: 'UNA TÍA LEJANA TE DEJA UNA HERENCIA',
    subtitle: 'Incluye una casona antigua y 23 gatos persas.',
    situation: 'El testamento condiciona la propiedad a cuidar con amor a todo el séquito felino.',
    category: 'absurd',
    options: [
      {
        key: 'A',
        label: 'Quedarte con todo y gobernar la mansión',
        description: 'Mucho mantenimiento diario, pero vives como emperatriz felina.',
        effect: {money: 800, energy: -1, happiness: 45, tag: 'cat_queen', log: 'Heredó la casona de los 23 gatos persas'},
      },
      {
        key: 'B',
        label: 'Vender la propiedad e invertir en fondos',
        description: 'Reubicas a los gatos y te aseguras capital financiero sólido.',
        effect: {money: 2200, energy: 0, career: 25, happiness: 10, tag: 'wealthy_investor', log: 'Vendió la herencia para invertir en bienes raíces'},
      },
      {
        key: 'C',
        label: 'Convertirla en un santuario animal abierto',
        description: 'Abres las puertas como refugio y cafetería comunitaria.',
        effect: {money: 300, energy: -2, happiness: 55, adventures: 25, tag: 'sanctuary_founder', log: 'Fundó el santuario felino más querido del país'},
      },
    ],
  },
  {
    id: 'e2_crisis_30',
    stage: 2,
    title: 'CRISIS VOCACIONAL DE LOS 30',
    subtitle: 'El reporte de auditoría te provoca ganas de correr.',
    situation: 'Sientes que la rutina de oficina te está apagando el brillo y la salud.',
    category: 'life_change',
    options: [
      {
        key: 'A',
        label: 'Abrir una pequeña cafetería acogedora',
        description: 'Madrugones intensos, pero aromas tostados y satisfacción diaria.',
        effect: {money: -500, energy: -2, happiness: 45, career: 30, tag: 'cafe_owner', log: 'Abrió la cafetería de sus sueños con aromas de café'},
      },
      {
        key: 'B',
        label: 'Especializarte en tecnología remota',
        description: 'Trabajo internacional desde casa con altos ingresos y descansos.',
        effect: {money: 850, energy: 1, career: 40, happiness: 15, tag: 'remote_tech', log: 'Se especializó en consultoría tecnológica remota'},
      },
      {
        key: 'C',
        label: 'Tomar un año sabático de descanso',
        description: 'Vives de tus ahorros y recuperas al 100% tu vitalidad.',
        effect: {money: -600, energy: 3, happiness: 40, adventures: 20, tag: 'deep_rest', log: 'Se tomó un año sabático para recargar su energía vital'},
      },
    ],
  },
  {
    id: 'e2_inversion_quesocoin',
    stage: 2,
    title: 'UN CONOCIDO TE HABLA DE QUESOCOIN',
    subtitle: 'La nueva criptomoneda revolucionaria según Twitter.',
    situation: 'Afirma que el token respalda queso parmesano digital y que se irá a la estratósfera.',
    category: 'money',
    options: [
      {
        key: 'A',
        label: 'Invertir una pequeña suma por diversión',
        description: '¡Sube milagrosamente y vendes a tiempo con ganancia!',
        effect: {money: 900, energy: 0, happiness: 20, tag: 'crypto_lucky', log: 'Multiplicó ahorros en la ruleta del quesocoin'},
      },
      {
        key: 'B',
        label: 'Reírte y comprar queso de verdad en el mercado',
        description: 'Cenas una tabla gourmet deliciosa y duermes en paz.',
        effect: {money: -40, energy: 1, happiness: 25, relationships: 20, log: 'Prefirió queso real comestible y cero estrés'},
      },
      {
        key: 'C',
        label: 'Meter todos tus ahorros al token',
        description: 'La moneda cae a cero al día siguiente. Desastre total.',
        effect: {money: -900, energy: -2, happiness: -30, tag: 'crypto_ruined', log: 'Perdió gran parte de sus ahorros en quesocoin'},
      },
    ],
  },
  {
    id: 'e2_mudanza_alpacas',
    stage: 2,
    title: 'MUDARTE AL CAMPO O SEGUIR EN LA URBE',
    subtitle: 'El smog te agobia, pero amas las comodidades de la ciudad.',
    situation: 'Sale a la venta una finca rústica cerca de las montañas con pastos verdes.',
    category: 'life_change',
    options: [
      {
        key: 'A',
        label: 'Comprar la finca y criar alpacas',
        description: 'Trabajo físico rural, pero aire puro y lana suave.',
        effect: {money: -500, energy: -1, happiness: 50, adventures: 35, tag: 'alpaca_dream', log: 'Se mudó a las colinas verdes a criar alpacas'},
      },
      {
        key: 'B',
        label: 'Quedarte en el centro y rentarla los fines de semana',
        description: 'Ingresos extras sin dejar tu comodidad urbana.',
        effect: {money: 400, energy: 0, career: 20, happiness: 25, log: 'Dueña de cabaña de descanso campestre'},
      },
      {
        key: 'C',
        label: 'Comprar un ático con terraza en el centro',
        description: 'Inversión costosa, pero vistas panorámicas nocturnas.',
        effect: {money: -700, energy: 0, career: 30, happiness: 30, tag: 'urban_penthouse', log: 'Adquirió un ático cosmopolita en la gran urbe'},
      },
    ],
  },
  {
    id: 'e2_escuela_gastronomia',
    stage: 2,
    title: 'CURSO MAESTRO DE GASTRONOMÍA',
    subtitle: 'Un chef reconocido te ofrece formación intensiva.',
    situation: 'Beca intensiva para dominar cocina internacional en Europa.',
    category: 'work',
    options: [
      {
        key: 'A',
        label: 'Hacer maletas y formarte como chef',
        description: 'Jornadas de 14 horas de pie, pero te vuelves una artista culinaria.',
        effect: {money: -300, energy: -2, career: 40, happiness: 40, adventures: 30, tag: 'master_chef', log: 'Se graduó como chef profesional en Europa'},
      },
      {
        key: 'B',
        label: 'Ofrecer cenas clandestinas en tu departamento',
        description: 'Cobras muy bien los fines de semana por menús gourmet.',
        effect: {money: 750, energy: -1, career: 25, happiness: 30, tag: 'secret_supper', log: 'Reina de las cenas clandestinas más exclusivas'},
      },
      {
        key: 'C',
        label: 'Cocinar solo para tu familia y amigos',
        description: 'Platos deliciosos y charlas largas que nutren tus afectos.',
        effect: {money: -60, energy: 1, happiness: 35, relationships: 40, log: 'El corazón cálido de los banquetes familiares'},
      },
    ],
  },

  // ==========================================
  // ETAPA 3: LAS DECISIONES CUESTIONABLES (4 eventos)
  // ==========================================
  {
    id: 'e3_viral_caida',
    stage: 3,
    title: 'TE HACES VIRAL POR ACCIDENTE',
    subtitle: 'Tu caída en el supermercado tiene 45 millones de vistas.',
    situation: 'Resbalaste con una cáscara de plátano cargando tres sandías. El video es comedia pura.',
    category: 'fame',
    options: [
      {
        key: 'A',
        label: 'Convertirte en influencer del humor',
        description: 'Grabaciones sin parar que agotan tu energía, pero dejan fortuna.',
        effect: {money: 1600, energy: -2, career: 30, happiness: 20, tag: 'viral_celebrity', log: 'Se volvió estrella viral de internet por su caída cómica'},
      },
      {
        key: 'B',
        label: 'Desaparecer de internet dos semanas',
        description: 'Mantienes tu privacidad y descansas desconectada.',
        effect: {money: 0, energy: 2, happiness: 25, career: -10, log: 'Eludió la fama efímera y cuidó su tranquilidad'},
      },
      {
        key: 'C',
        label: 'Vender camisetas con tu foto cayéndote',
        description: '¡El merchandising se agota en 48 horas!',
        effect: {money: 1300, energy: -1, adventures: 20, happiness: 30, tag: 'merch_queen', log: 'Capitalizó su caída en un imperio de camisetas'},
      },
    ],
  },
  {
    id: 'e3_reality_show',
    stage: 3,
    title: 'CASTING PARA REALITY SHOW',
    subtitle: 'Prometen fama instantánea y millones en premios.',
    situation: 'Los productores buscan concursantes con personalidad chispeante.',
    category: 'fame',
    options: [
      {
        key: 'A',
        label: 'Entrar y competir con recetas familiares',
        description: 'Tres meses de tensión bajo cámaras, pero sales como estrella.',
        effect: {money: 1800, energy: -2, career: 40, happiness: 25, tag: 'tv_star', log: 'Triunfó como finalista estelar en el reality show'},
      },
      {
        key: 'B',
        label: 'Declinar la oferta para evitar polémicas',
        description: 'Proteges tu salud mental y duermes tranquila.',
        effect: {money: 0, energy: 1, happiness: 30, relationships: 25, log: 'Protegió su intimidad de los reflectores televisivos'},
      },
      {
        key: 'C',
        label: 'Pedir puesto de redactora detrás de cámaras',
        description: 'Sueldo digno y aprendes la industria sin exponerte.',
        effect: {money: 700, energy: -1, career: 25, happiness: 20, log: 'Trabajó como productora creativa tras bambalinas'},
      },
    ],
  },
  {
    id: 'e3_velero_restaurar',
    stage: 3,
    title: 'UN VELERO ABANDONADO EN LA MARINA',
    subtitle: 'Necesita lija, pintura y una capitana audaz.',
    situation: 'El puerto remata un bote de madera clásica con camarote acogedor.',
    category: 'travel',
    options: [
      {
        key: 'A',
        label: 'Comprarlo, restaurarlo y navegar',
        description: 'Gastas dinero y sudor lijando, pero surcas las olas libre.',
        effect: {money: -600, energy: -1, adventures: 55, happiness: 50, tag: 'sea_captain', log: 'Restauró un velero y se convirtió en capitana de altamar'},
      },
      {
        key: 'B',
        label: 'Convertirlo en restaurante flotante',
        description: 'Negocio próspero sobre el agua que atrae turistas.',
        effect: {money: 1400, energy: -2, career: 35, happiness: 30, tag: 'floating_bistro', log: 'Dueña del bistró flotante más romántico del puerto'},
      },
      {
        key: 'C',
        label: 'Revenderlo rápido con comisión',
        description: 'Ganancia monetaria limpia sin mover un dedo.',
        effect: {money: 800, energy: 0, happiness: 15, log: 'Comercializó el velero con ganancia rápida'},
      },
    ],
  },
  {
    id: 'e3_deudas_tarjetas',
    stage: 3,
    title: 'ALERTA DE SOBREGIRO BANCARIO',
    subtitle: 'Los gastos en proyectos desordenados empezaron a morder.',
    situation: 'Te llega una notificación de intereses acumulados en tus cuentas.',
    category: 'crisis',
    options: [
      {
        key: 'A',
        label: 'Austeridad radical y liquidar todo de golpe',
        description: 'Agotas tus ahorros, pero te libras del fantasma de la deuda.',
        effect: {money: -500, energy: 1, happiness: 15, log: 'Liquidó sus deudas con disciplina estricta'},
      },
      {
        key: 'B',
        label: 'Pedir otro préstamo para tapar el hueco',
        description: 'La bola de nieve de intereses se vuelve aplastante.',
        effect: {money: -700, energy: -2, happiness: -25, log: 'Se enredó en préstamos que casi la llevan a la quiebra'},
      },
      {
        key: 'C',
        label: 'Vender pertenencias caras que ya no usas',
        description: 'Recuperas liquidez y adoptas un estilo de vida más austero.',
        effect: {money: 450, energy: 0, happiness: 25, log: 'Vendió pertenencias innecesarias para sanear sus finanzas'},
      },
    ],
  },

  // ==========================================
  // ETAPA 4: LOS GIROS INESPERADOS (3 eventos)
  // ==========================================
  {
    id: 'e4_patente_multinacional',
    stage: 4,
    title: 'OFERTA MILLONARIA POR TU PATENTE',
    subtitle: 'Aquel invento que registraste resulta crucial para una multinacional.',
    situation: 'Te citan en un rascacielos con un cheque de siete cifras listo.',
    category: 'money',
    options: [
      {
        key: 'A',
        label: 'Vender la patente y retirarte con fortuna',
        description: 'Tus cuentas bancarias ahora tienen ceros de sobra.',
        effect: {money: 3500, energy: 2, career: 45, happiness: 35, tag: 'ultra_rich', log: 'Venta millonaria de patente tecnológica'},
      },
      {
        key: 'B',
        label: 'Mantener el control y producirlo de forma ecológica',
        description: 'Lideras una corporación ética con jornadas de alta exigencia.',
        effect: {money: 1800, energy: -2, career: 55, happiness: 45, tag: 'green_ceo', log: 'Presidió una corporación ecológica global'},
      },
      {
        key: 'C',
        label: 'Liberar la patente para toda la humanidad',
        description: 'Ganas el agradecimiento mundial y paz interior.',
        effect: {money: 0, energy: 1, happiness: 65, relationships: 45, tag: 'humanitarian_hero', log: 'Regaló su innovación tecnológica a la humanidad'},
      },
    ],
  },
  {
    id: 'e4_frente_mar_retiro',
    stage: 4,
    title: 'CASA DE MADERA FRENTE AL OCÉANO',
    subtitle: 'El sonido de las olas rompiendo a veinte metros.',
    situation: 'Sale la oportunidad de comprar un terreno donde el mar es color turquesa.',
    category: 'life_change',
    options: [
      {
        key: 'A',
        label: 'Comprarla para vivir descalza y tranquila',
        description: 'Gastas ahorros, pero tu salud y energía alcanzan su cénit.',
        effect: {money: -800, energy: 2, happiness: 65, adventures: 40, tag: 'ocean_life', log: 'Estableció su santuario frente al mar infinito'},
      },
      {
        key: 'B',
        label: 'Montar escuela de surf y yoga frente a las olas',
        description: 'Trabajo diario activo y alumnos de todo el mundo.',
        effect: {money: 1200, energy: -1, career: 35, happiness: 50, tag: 'surf_guru', log: 'Directora de escuela de surf y bienestar marino'},
      },
      {
        key: 'C',
        label: 'Rentarla para retiros de escritores',
        description: 'Ingresos pasivos constantes y charlas enriquecedoras.',
        effect: {money: 1600, energy: 1, career: 25, happiness: 40, log: 'Anfitriona de retiros creativos frente al mar'},
      },
    ],
  },
  {
    id: 'e4_burnout_agotamiento',
    stage: 4,
    title: 'EL CUERPO PIDE UN FRENO TOTAL',
    subtitle: 'El cansancio acumulado de años exige descanso.',
    situation: 'Tu energía está al límite y sientes que necesitas frenar en seco.',
    category: 'crisis',
    options: [
      {
        key: 'A',
        label: 'Vivir en el bosque sin pantallas seis meses',
        description: 'Duermes diez horas diarias y recuperas todos tus corazones.',
        effect: {money: -350, energy: 3, happiness: 60, adventures: 30, tag: 'deep_rest', log: 'Pausa profunda en el bosque que restauró su salud'},
      },
      {
        key: 'B',
        label: 'Seguir trabajando a base de café doble',
        description: 'Avanzas en la empresa a costa de tu salud física.',
        effect: {money: 1100, energy: -3, career: 40, happiness: -20, log: 'Ignoró el cansancio y acumuló dinero al costo de su salud'},
      },
      {
        key: 'C',
        label: 'Aprender jardinería y cuidar plantas en casa',
        description: 'Paz doméstica sin grandes gastos.',
        effect: {money: -50, energy: 2, happiness: 45, relationships: 25, log: 'Sanó su estrés cuidando flores y huertos'},
      },
    ],
  },

  // ==========================================
  // ETAPA 5: EL DESTINO FINAL (1 evento)
  // ==========================================
  {
    id: 'e5_gran_balance',
    stage: 5,
    title: 'EL PORTAL DE LAS MIL VIDAS',
    subtitle: 'Las 50 casillas han forjado una vida única e irrepetible.',
    situation: 'Un portal 3D resplandeciente en tonos pastel se abre ante ti revelando tu universo definitivo.',
    category: 'extraordinary',
    options: [
      {
        key: 'A',
        label: 'Cruzar el portal sonriendo con gratitud',
        description: '¡Tu universo alternativo queda grabado para siempre!',
        effect: {happiness: 50, energy: 1, tag: 'universe_unlocked', log: 'Cruzó el portal con plenitud hacia su destino final'},
      },
      {
        key: 'B',
        label: 'Dar un último salto de alegría',
        description: 'Energía pura y optimismo hacia tu nueva vida.',
        effect: {happiness: 55, adventures: 30, tag: 'universe_unlocked', log: 'Saltó con júbilo hacia las estrellas'},
      },
      {
        key: 'C',
        label: 'Llevarte a tus compañeros de viaje al otro lado',
        description: 'Nadie se queda atrás; el destino se comparte.',
        effect: {happiness: 50, relationships: 50, tag: 'universe_unlocked', log: 'Cruzó el portal rodeada de sus seres queridos'},
      },
    ],
  },
];
