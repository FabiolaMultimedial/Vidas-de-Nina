import {BoardEvent} from './types';

/**
 * Robust catalog of 20+ varied situations across stages.
 * Each choice produces distinct impacts on Money, Happiness, Energy (-2 to +2), Career, Relationships and Adventures.
 * Generates unique storyline logs and unlocks varied tags for divergent destinations.
 */
const BASE_EVENTS: BoardEvent[] = [
  // ==========================================
  // ETAPA 1: LOS VEINTITANTOS (6 eventos)
  // ==========================================
  {
    id: 'e1_jefe_ascenso',
    stage: 1,
    title: 'TU JEFE TE OFRECE UN ASCENSO',
    subtitle: 'Viene con aumento, pero responderás mensajes en domingo.',
    situation: 'Te ofrecen coordinar el equipo con 50% más de sueldo a cambio de estar siempre disponible.',
    category: 'work',
    options: [
      {
        key: 'A',
        label: 'Aceptar porque necesitas dinero',
        description: 'Tus ingresos aumentan, pero tu energía cae en picado.',
        effect: {money: 750, energy: -2, career: 25, happiness: -15, tag: 'corporate_ladder', log: 'Aceptó un ascenso corporativo absorbente'},
      },
      {
        key: 'B',
        label: 'Renunciar para emprender',
        description: 'Gastas ahorros en tu proyecto, pero recuperas tu ilusión.',
        effect: {money: -350, energy: -1, career: 15, happiness: 20, adventures: 20, tag: 'entrepreneur_spark', log: 'Renunció para emprender su propio negocio'},
      },
      {
        key: 'C',
        label: 'Pedir vacaciones y probar suerte',
        description: 'Tu jefa se sorprende, pero te concede días de descanso.',
        effect: {money: -50, energy: 2, happiness: 25, career: -5, tag: 'bold_negotiator', log: 'Negoció vacaciones sin miedo y recargó pilas'},
      },
    ],
  },
  {
    id: 'e1_piso_compartido',
    stage: 1,
    title: 'SE BUSCA COMPAÑERO DE PISO',
    subtitle: 'El alquiler en la ciudad está por las nubes.',
    situation: 'Encuentras un piso compartido con tres personas bohemias que tocan el ukelele de madrugada.',
    category: 'friendship',
    options: [
      {
        key: 'A',
        label: 'Aceptar el cuarto pequeño',
        description: 'Ahorras bastante pero duermes con tapones.',
        effect: {money: 350, energy: -1, relationships: 15, happiness: -5, log: 'Vivió en piso compartido con bohemios ruidosos'},
      },
      {
        key: 'B',
        label: 'Alquilar un estudio tú sola',
        description: 'Paz absoluta, aunque tu cuenta bancaria sufra.',
        effect: {money: -450, energy: 1, happiness: 25, tag: 'independent_queen', log: 'Alquiló su propio estudio independiente'},
      },
      {
        key: 'C',
        label: 'Volver a casa familiar un tiempo',
        description: 'Comida casera deliciosa, pero cero privacidad.',
        effect: {money: 400, energy: 1, relationships: 20, happiness: 5, log: 'Volvió al nido familiar para ahorrar'},
      },
    ],
  },
  {
    id: 'e1_viaje_mochilazo',
    stage: 1,
    title: 'VIAJE MOCHILERO IMPROVISADO',
    subtitle: 'Tres semanas recorriendo pueblitos en tren.',
    situation: 'Tus amigos compran boletos baratos sin alojamiento reservado.',
    category: 'travel',
    options: [
      {
        key: 'A',
        label: 'Empacar la mochila y salir corriendo',
        description: 'Gastas dinero y energía caminando, pero vives una gran aventura.',
        effect: {money: -350, energy: -1, happiness: 35, adventures: 40, tag: 'wanderlust_init', log: 'Recorrió pueblos de mochilera viviendo aventuras'},
      },
      {
        key: 'B',
        label: 'Quedarte a trabajar horas extras',
        description: 'El banco sonríe; tu espíritu aventurero bosteza.',
        effect: {money: 450, energy: -2, career: 20, happiness: -10, log: 'Eligió horas extras y acumuló ahorros'},
      },
      {
        key: 'C',
        label: 'Unirte solo el último fin de semana',
        description: 'Llegas directo a la fiesta final sin gastar demasiado.',
        effect: {money: -120, energy: 0, happiness: 20, relationships: 20, log: 'Se unió a la fiesta final con amigos'},
      },
    ],
  },
  {
    id: 'e1_bootcamp_tech',
    stage: 1,
    title: 'CURSO INTENSIVO DE NOCHE',
    subtitle: 'Aprender diseño digital y código.',
    situation: 'Ofrecen un curso intensivo que exige estudiar 4 horas diarias tras el trabajo.',
    category: 'work',
    options: [
      {
        key: 'A',
        label: 'Pagar matrícula y desvelarte estudiando',
        description: 'Agotamiento puro, pero adquieres habilidades cotizadas.',
        effect: {money: -300, energy: -2, career: 35, happiness: -5, tag: 'tech_savvy', log: 'Se desveló estudiando código para superarse'},
      },
      {
        key: 'B',
        label: 'Aprender gratis a tu propio ritmo',
        description: 'Avanzas despacio pero sin perder horas de sueño.',
        effect: {money: 0, energy: 0, career: 15, happiness: 15, log: 'Estudió a su propio ritmo con calma'},
      },
      {
        key: 'C',
        label: 'Inscribirte mejor a un taller de cerámica',
        description: 'Modelas arcilla relajada y haces nuevas amistades.',
        effect: {money: -120, energy: 1, happiness: 30, adventures: 15, tag: 'artisan_soul', log: 'Descubrió su pasión por la cerámica artesanal'},
      },
    ],
  },
  {
    id: 'e1_gatito_lluvia',
    stage: 1,
    title: 'UN GATITO EN EL PORTAL',
    subtitle: 'Llueve torrencialmente y te mira fijamente.',
    situation: 'Una pequeña bola de pelos maúlla aterida de frío bajo tu escalera.',
    category: 'absurd',
    options: [
      {
        key: 'A',
        label: 'Adoptarlo y comprarle camita',
        description: 'Gastas en veterinario, pero tu hogar se llena de ternura.',
        effect: {money: -150, energy: 1, happiness: 40, relationships: 15, tag: 'first_cat', log: 'Adoptó a su primer gatito bajo la lluvia'},
      },
      {
        key: 'B',
        label: 'Buscarle un hogar con una vecina adinerada',
        description: 'El gato vivirá como rey y tú lo visitas a menudo.',
        effect: {money: 50, energy: 0, happiness: 20, relationships: 20, log: 'Le encontró un hogar palaciego a un gatito'},
      },
      {
        key: 'C',
        label: 'Llevarlo al refugio y hacerte voluntaria',
        description: 'Cansas tus fines de semana cuidando animales con amor.',
        effect: {money: -40, energy: -1, happiness: 35, adventures: 15, tag: 'shelter_hero', log: 'Se unió como voluntaria de rescate animal'},
      },
    ],
  },
  {
    id: 'e1_oferta_linea',
    stage: 1,
    title: 'OFERTA IRRESISTIBLE EN LÍNEA',
    subtitle: 'Un abrigo de diseñador con supuesto descuento.',
    situation: 'Aparece en pantalla ese abrigo que siempre quisiste, pero el precio sigue siendo alto.',
    category: 'money',
    options: [
      {
        key: 'A',
        label: 'Comprarlo en cuotas sin pensar',
        description: 'Luce fabuloso aunque tengas que apretarte el cinturón.',
        effect: {money: -300, energy: 0, happiness: 15, tag: 'chic_fashion', log: 'Compró ropa de diseñador a crédito'},
      },
      {
        key: 'B',
        label: 'Cerrar la pestaña y meter dinero al ahorro',
        description: 'Fuerza de voluntad que protege tu economía.',
        effect: {money: 200, energy: 0, happiness: 5, tag: 'frugal_mindset', log: 'Demostró disciplina de ahorro impecable'},
      },
      {
        key: 'C',
        label: 'Buscarlo vintage en un mercadillo',
        description: 'Encuentras uno retro aún más original por poco dinero.',
        effect: {money: -60, energy: -1, happiness: 25, adventures: 15, tag: 'thrifter', log: 'Cazó tesoros vintage en el mercadillo'},
      },
    ],
  },

  // ==========================================
  // ETAPA 2: LA VIDA ADULTA (5 eventos)
  // ==========================================
  {
    id: 'e2_herencia_gatos',
    stage: 2,
    title: 'UNA TÍA LEJANA TE DEJA UNA HERENCIA',
    subtitle: 'Incluye una casona antigua y 23 gatos persas.',
    situation: 'El testamento condiciona la propiedad a cuidar con amor a todo el séquito felino.',
    category: 'absurd',
    options: [
      {
        key: 'A',
        label: 'Quedarte con todo y gobernar la mansión',
        description: 'Mucho mantenimiento diario, pero vives como emperatriz felina.',
        effect: {money: 800, energy: -1, happiness: 45, tag: 'cat_queen', log: 'Heredó la casona de los 23 gatos persas'},
      },
      {
        key: 'B',
        label: 'Vender la propiedad e invertir en fondos',
        description: 'Reubicas a los gatos y te aseguras capital financiero sólido.',
        effect: {money: 2200, energy: 0, career: 25, happiness: 10, tag: 'wealthy_investor', log: 'Vendió la herencia para invertir en bienes raíces'},
      },
      {
        key: 'C',
        label: 'Convertirla en un santuario animal abierto',
        description: 'Abres las puertas como refugio y cafetería comunitaria.',
        effect: {money: 300, energy: -2, happiness: 55, adventures: 25, tag: 'sanctuary_founder', log: 'Fundó el santuario felino más querido del país'},
      },
    ],
  },
  {
    id: 'e2_crisis_30',
    stage: 2,
    title: 'CRISIS VOCACIONAL DE LOS 30',
    subtitle: 'El reporte de auditoría te provoca ganas de correr.',
    situation: 'Sientes que la rutina de oficina te está apagando el brillo y la salud.',
    category: 'life_change',
    options: [
      {
        key: 'A',
        label: 'Abrir una pequeña cafetería acogedora',
        description: 'Madrugones intensos, pero aromas tostados y satisfacción diaria.',
        effect: {money: -500, energy: -2, happiness: 45, career: 30, tag: 'cafe_owner', log: 'Abrió la cafetería de sus sueños con aromas de café'},
      },
      {
        key: 'B',
        label: 'Especializarte en tecnología remota',
        description: 'Trabajo internacional desde casa con altos ingresos y descansos.',
        effect: {money: 850, energy: 1, career: 40, happiness: 15, tag: 'remote_tech', log: 'Se especializó en consultoría tecnológica remota'},
      },
      {
        key: 'C',
        label: 'Tomar un año sabático de descanso',
        description: 'Vives de tus ahorros y recuperas al 100% tu vitalidad.',
        effect: {money: -600, energy: 3, happiness: 40, adventures: 20, tag: 'deep_rest', log: 'Se tomó un año sabático para recargar su energía vital'},
      },
    ],
  },
  {
    id: 'e2_inversion_quesocoin',
    stage: 2,
    title: 'UN CONOCIDO TE HABLA DE QUESOCOIN',
    subtitle: 'La nueva criptomoneda revolucionaria según Twitter.',
    situation: 'Afirma que el token respalda queso parmesano digital y que se irá a la estratósfera.',
    category: 'money',
    options: [
      {
        key: 'A',
        label: 'Invertir una pequeña suma por diversión',
        description: '¡Sube milagrosamente y vendes a tiempo con ganancia!',
        effect: {money: 900, energy: 0, happiness: 20, tag: 'crypto_lucky', log: 'Multiplicó ahorros en la ruleta del quesocoin'},
      },
      {
        key: 'B',
        label: 'Reírte y comprar queso de verdad en el mercado',
        description: 'Cenas una tabla gourmet deliciosa y duermes en paz.',
        effect: {money: -40, energy: 1, happiness: 25, relationships: 20, log: 'Prefirió queso real comestible y cero estrés'},
      },
      {
        key: 'C',
        label: 'Meter todos tus ahorros al token',
        description: 'La moneda cae a cero al día siguiente. Desastre total.',
        effect: {money: -900, energy: -2, happiness: -30, tag: 'crypto_ruined', log: 'Perdió gran parte de sus ahorros en quesocoin'},
      },
    ],
  },
  {
    id: 'e2_mudanza_alpacas',
    stage: 2,
    title: 'MUDARTE AL CAMPO O SEGUIR EN LA URBE',
    subtitle: 'El smog te agobia, pero amas las comodidades de la ciudad.',
    situation: 'Sale a la venta una finca rústica cerca de las montañas con pastos verdes.',
    category: 'life_change',
    options: [
      {
        key: 'A',
        label: 'Comprar la finca y criar alpacas',
        description: 'Trabajo físico rural, pero aire puro y lana suave.',
        effect: {money: -500, energy: -1, happiness: 50, adventures: 35, tag: 'alpaca_dream', log: 'Se mudó a las colinas verdes a criar alpacas'},
      },
      {
        key: 'B',
        label: 'Quedarte en el centro y rentarla los fines de semana',
        description: 'Ingresos extras sin dejar tu comodidad urbana.',
        effect: {money: 400, energy: 0, career: 20, happiness: 25, log: 'Dueña de cabaña de descanso campestre'},
      },
      {
        key: 'C',
        label: 'Comprar un ático con terraza en el centro',
        description: 'Inversión costosa, pero vistas panorámicas nocturnas.',
        effect: {money: -700, energy: 0, career: 30, happiness: 30, tag: 'urban_penthouse', log: 'Adquirió un ático cosmopolita en la gran urbe'},
      },
    ],
  },
  {
    id: 'e2_escuela_gastronomia',
    stage: 2,
    title: 'CURSO MAESTRO DE GASTRONOMÍA',
    subtitle: 'Un chef reconocido te ofrece formación intensiva.',
    situation: 'Beca intensiva para dominar cocina internacional en Europa.',
    category: 'work',
    options: [
      {
        key: 'A',
        label: 'Hacer maletas y formarte como chef',
        description: 'Jornadas de 14 horas de pie, pero te vuelves una artista culinaria.',
        effect: {money: -300, energy: -2, career: 40, happiness: 40, adventures: 30, tag: 'master_chef', log: 'Se graduó como chef profesional en Europa'},
      },
      {
        key: 'B',
        label: 'Ofrecer cenas clandestinas en tu departamento',
        description: 'Cobras muy bien los fines de semana por menús gourmet.',
        effect: {money: 750, energy: -1, career: 25, happiness: 30, tag: 'secret_supper', log: 'Reina de las cenas clandestinas más exclusivas'},
      },
      {
        key: 'C',
        label: 'Cocinar solo para tu familia y amigos',
        description: 'Platos deliciosos y charlas largas que nutren tus afectos.',
        effect: {money: -60, energy: 1, happiness: 35, relationships: 40, log: 'El corazón cálido de los banquetes familiares'},
      },
    ],
  },

  // ==========================================
  // ETAPA 3: LAS DECISIONES CUESTIONABLES (4 eventos)
  // ==========================================
  {
    id: 'e3_viral_caida',
    stage: 3,
    title: 'TE HACES VIRAL POR ACCIDENTE',
    subtitle: 'Tu caída en el supermercado tiene 45 millones de vistas.',
    situation: 'Resbalaste con una cáscara de plátano cargando tres sandías. El video es comedia pura.',
    category: 'fame',
    options: [
      {
        key: 'A',
        label: 'Convertirte en influencer del humor',
        description: 'Grabaciones sin parar que agotan tu energía, pero dejan fortuna.',
        effect: {money: 1600, energy: -2, career: 30, happiness: 20, tag: 'viral_celebrity', log: 'Se volvió estrella viral de internet por su caída cómica'},
      },
      {
        key: 'B',
        label: 'Desaparecer de internet dos semanas',
        description: 'Mantienes tu privacidad y descansas desconectada.',
        effect: {money: 0, energy: 2, happiness: 25, career: -10, log: 'Eludió la fama efímera y cuidó su tranquilidad'},
      },
      {
        key: 'C',
        label: 'Vender camisetas con tu foto cayéndote',
        description: '¡El merchandising se agota en 48 horas!',
        effect: {money: 1300, energy: -1, adventures: 20, happiness: 30, tag: 'merch_queen', log: 'Capitalizó su caída en un imperio de camisetas'},
      },
    ],
  },
  {
    id: 'e3_reality_show',
    stage: 3,
    title: 'CASTING PARA REALITY SHOW',
    subtitle: 'Prometen fama instantánea y millones en premios.',
    situation: 'Los productores buscan concursantes con personalidad chispeante.',
    category: 'fame',
    options: [
      {
        key: 'A',
        label: 'Entrar y competir con recetas familiares',
        description: 'Tres meses de tensión bajo cámaras, pero sales como estrella.',
        effect: {money: 1800, energy: -2, career: 40, happiness: 25, tag: 'tv_star', log: 'Triunfó como finalista estelar en el reality show'},
      },
      {
        key: 'B',
        label: 'Declinar la oferta para evitar polémicas',
        description: 'Proteges tu salud mental y duermes tranquila.',
        effect: {money: 0, energy: 1, happiness: 30, relationships: 25, log: 'Protegió su intimidad de los reflectores televisivos'},
      },
      {
        key: 'C',
        label: 'Pedir puesto de redactora detrás de cámaras',
        description: 'Sueldo digno y aprendes la industria sin exponerte.',
        effect: {money: 700, energy: -1, career: 25, happiness: 20, log: 'Trabajó como productora creativa tras bambalinas'},
      },
    ],
  },
  {
    id: 'e3_velero_restaurar',
    stage: 3,
    title: 'UN VELERO ABANDONADO EN LA MARINA',
    subtitle: 'Necesita lija, pintura y una capitana audaz.',
    situation: 'El puerto remata un bote de madera clásica con camarote acogedor.',
    category: 'travel',
    options: [
      {
        key: 'A',
        label: 'Comprarlo, restaurarlo y navegar',
        description: 'Gastas dinero y sudor lijando, pero surcas las olas libre.',
        effect: {money: -600, energy: -1, adventures: 55, happiness: 50, tag: 'sea_captain', log: 'Restauró un velero y se convirtió en capitana de altamar'},
      },
      {
        key: 'B',
        label: 'Convertirlo en restaurante flotante',
        description: 'Negocio próspero sobre el agua que atrae turistas.',
        effect: {money: 1400, energy: -2, career: 35, happiness: 30, tag: 'floating_bistro', log: 'Dueña del bistró flotante más romántico del puerto'},
      },
      {
        key: 'C',
        label: 'Revenderlo rápido con comisión',
        description: 'Ganancia monetaria limpia sin mover un dedo.',
        effect: {money: 800, energy: 0, happiness: 15, log: 'Comercializó el velero con ganancia rápida'},
      },
    ],
  },
  {
    id: 'e3_deudas_tarjetas',
    stage: 3,
    title: 'ALERTA DE SOBREGIRO BANCARIO',
    subtitle: 'Los gastos en proyectos desordenados empezaron a morder.',
    situation: 'Te llega una notificación de intereses acumulados en tus cuentas.',
    category: 'crisis',
    options: [
      {
        key: 'A',
        label: 'Austeridad radical y liquidar todo de golpe',
        description: 'Agotas tus ahorros, pero te libras del fantasma de la deuda.',
        effect: {money: -500, energy: 1, happiness: 15, log: 'Liquidó sus deudas con disciplina estricta'},
      },
      {
        key: 'B',
        label: 'Pedir otro préstamo para tapar el hueco',
        description: 'La bola de nieve de intereses se vuelve aplastante.',
        effect: {money: -700, energy: -2, happiness: -25, log: 'Se enredó en préstamos que casi la llevan a la quiebra'},
      },
      {
        key: 'C',
        label: 'Vender pertenencias caras que ya no usas',
        description: 'Recuperas liquidez y adoptas un estilo de vida más austero.',
        effect: {money: 450, energy: 0, happiness: 25, log: 'Vendió pertenencias innecesarias para sanear sus finanzas'},
      },
    ],
  },

  // ==========================================
  // ETAPA 4: LOS GIROS INESPERADOS (3 eventos)
  // ==========================================
  {
    id: 'e4_patente_multinacional',
    stage: 4,
    title: 'OFERTA MILLONARIA POR TU PATENTE',
    subtitle: 'Aquel invento que registraste resulta crucial para una multinacional.',
    situation: 'Te citan en un rascacielos con un cheque de siete cifras listo.',
    category: 'money',
    options: [
      {
        key: 'A',
        label: 'Vender la patente y retirarte con fortuna',
        description: 'Tus cuentas bancarias ahora tienen ceros de sobra.',
        effect: {money: 3500, energy: 2, career: 45, happiness: 35, tag: 'ultra_rich', log: 'Venta millonaria de patente tecnológica'},
      },
      {
        key: 'B',
        label: 'Mantener el control y producirlo de forma ecológica',
        description: 'Lideras una corporación ética con jornadas de alta exigencia.',
        effect: {money: 1800, energy: -2, career: 55, happiness: 45, tag: 'green_ceo', log: 'Presidió una corporación ecológica global'},
      },
      {
        key: 'C',
        label: 'Liberar la patente para toda la humanidad',
        description: 'Ganas el agradecimiento mundial y paz interior.',
        effect: {money: 0, energy: 1, happiness: 65, relationships: 45, tag: 'humanitarian_hero', log: 'Regaló su innovación tecnológica a la humanidad'},
      },
    ],
  },
  {
    id: 'e4_frente_mar_retiro',
    stage: 4,
    title: 'CASA DE MADERA FRENTE AL OCÉANO',
    subtitle: 'El sonido de las olas rompiendo a veinte metros.',
    situation: 'Sale la oportunidad de comprar un terreno donde el mar es color turquesa.',
    category: 'life_change',
    options: [
      {
        key: 'A',
        label: 'Comprarla para vivir descalza y tranquila',
        description: 'Gastas ahorros, pero tu salud y energía alcanzan su cénit.',
        effect: {money: -800, energy: 2, happiness: 65, adventures: 40, tag: 'ocean_life', log: 'Estableció su santuario frente al mar infinito'},
      },
      {
        key: 'B',
        label: 'Montar escuela de surf y yoga frente a las olas',
        description: 'Trabajo diario activo y alumnos de todo el mundo.',
        effect: {money: 1200, energy: -1, career: 35, happiness: 50, tag: 'surf_guru', log: 'Directora de escuela de surf y bienestar marino'},
      },
      {
        key: 'C',
        label: 'Rentarla para retiros de escritores',
        description: 'Ingresos pasivos constantes y charlas enriquecedoras.',
        effect: {money: 1600, energy: 1, career: 25, happiness: 40, log: 'Anfitriona de retiros creativos frente al mar'},
      },
    ],
  },
  {
    id: 'e4_burnout_agotamiento',
    stage: 4,
    title: 'EL CUERPO PIDE UN FRENO TOTAL',
    subtitle: 'El cansancio acumulado de años exige descanso.',
    situation: 'Tu energía está al límite y sientes que necesitas frenar en seco.',
    category: 'crisis',
    options: [
      {
        key: 'A',
        label: 'Vivir en el bosque sin pantallas seis meses',
        description: 'Duermes diez horas diarias y recuperas todos tus corazones.',
        effect: {money: -350, energy: 3, happiness: 60, adventures: 30, tag: 'deep_rest', log: 'Pausa profunda en el bosque que restauró su salud'},
      },
      {
        key: 'B',
        label: 'Seguir trabajando a base de café doble',
        description: 'Avanzas en la empresa a costa de tu salud física.',
        effect: {money: 1100, energy: -3, career: 40, happiness: -20, log: 'Ignoró el cansancio y acumuló dinero al costo de su salud'},
      },
      {
        key: 'C',
        label: 'Aprender jardinería y cuidar plantas en casa',
        description: 'Paz doméstica sin grandes gastos.',
        effect: {money: -50, energy: 2, happiness: 45, relationships: 25, log: 'Sanó su estrés cuidando flores y huertos'},
      },
    ],
  },

  // ==========================================
  // ETAPA 5: EL DESTINO FINAL (1 evento)
  // ==========================================
  {
    id: 'e5_gran_balance',
    stage: 5,
    title: 'EL PORTAL DE LAS MIL VIDAS',
    subtitle: 'Las 50 casillas han forjado una vida única e irrepetible.',
    situation: 'Un portal 3D resplandeciente en tonos pastel se abre ante ti revelando tu universo definitivo.',
    category: 'extraordinary',
    options: [
      {
        key: 'A',
        label: 'Cruzar el portal sonriendo con gratitud',
        description: '¡Tu universo alternativo queda grabado para siempre!',
        effect: {happiness: 50, energy: 1, tag: 'universe_unlocked', log: 'Cruzó el portal con plenitud hacia su destino final'},
      },
      {
        key: 'B',
        label: 'Dar un último salto de alegría',
        description: 'Energía pura y optimismo hacia tu nueva vida.',
        effect: {happiness: 55, adventures: 30, tag: 'universe_unlocked', log: 'Saltó con júbilo hacia las estrellas'},
      },
      {
        key: 'C',
        label: 'Llevarte a tus compañeros de viaje al otro lado',
        description: 'Nadie se queda atrás; el destino se comparte.',
        effect: {happiness: 50, relationships: 50, tag: 'universe_unlocked', log: 'Cruzó el portal rodeada de sus seres queridos'},
      },
    ],
  },
];

const EXTRA_EVENTS: BoardEvent[] = [
  // ---------- ETAPA 3 ----------
  {
    id: 'e3_boda_ex',
    stage: 3,
    title: 'TE INVITAN A LA BODA DE TU EX',
    subtitle: 'Con acompañante opcional y buffet ilimitado.',
    situation: 'Llega una invitación dorada. Todo el mundo estará ahí y todos van a mirar.',
    category: 'love',
    options: [
      {
        key: 'A',
        label: 'Ir con la mejor actitud y bailar toda la noche',
        description: 'Te sorprendes de lo bien que lo pasas.',
        effect: {money: -100, happiness: 30, relationships: 20, log: 'Bailó en la boda de su ex como si nada'},
      },
      {
        key: 'B',
        label: 'Mandar un regalo y quedarte en casa con pizza',
        description: 'Cero drama, cero tacones.',
        effect: {money: -40, energy: 1, happiness: 15, log: 'Prefirió una noche de pizza a la boda de su ex'},
      },
      {
        key: 'C',
        label: 'Llevar a tu amigo más gracioso de pareja falsa',
        description: 'La boda se recordará por tu entrada.',
        effect: {money: -60, happiness: 25, adventures: 20, relationships: 10, log: 'Se coló en la boda con una pareja falsa y mucho estilo'},
      },
    ],
  },
  {
    id: 'e3_club_lectura',
    stage: 3,
    title: 'UN CLUB DE LECTURA MUY MISTERIOSO',
    subtitle: 'Nadie ha terminado el libro, pero todos opinan.',
    situation: 'Te invitan a un club donde se habla más de chismes que de libros.',
    category: 'friendship',
    options: [
      {
        key: 'A',
        label: 'Unirte y llevar galletas',
        description: 'Haces amistades que duran años.',
        effect: {money: -30, relationships: 30, happiness: 20, log: 'Se unió a un club de lectura de pura chismosería'},
      },
      {
        key: 'B',
        label: 'Fundar tu propio club de películas',
        description: 'Más trabajo, pero a tu manera.',
        effect: {money: -80, energy: -1, relationships: 25, career: 10, happiness: 20, log: 'Fundó su propio club de cine entre amigos'},
      },
      {
        key: 'C',
        label: 'Agradecer y dormir temprano',
        description: 'Tu almohada nunca te juzga.',
        effect: {energy: 2, happiness: 10, log: 'Se quedó durmiendo en lugar de ir al club'},
      },
    ],
  },
  {
    id: 'e3_curso_ceramica',
    stage: 3,
    title: 'UN CURSO DE CERÁMICA A MEDIANOCHE',
    subtitle: 'El profesor insiste en que el barro habla.',
    situation: 'Hay un último cupo en una clase rara pero muy popular.',
    category: 'impulsive',
    options: [
      {
        key: 'A',
        label: 'Inscribirte y hacer tazas torcidas',
        description: 'Terminas con una vajilla única.',
        effect: {money: -120, happiness: 30, adventures: 15, log: 'Aprendió cerámica y hizo tazas torcidas pero queridas'},
      },
      {
        key: 'B',
        label: 'Vender tus piezas en un mercadito',
        description: 'Poco dinero, mucha gente simpática.',
        effect: {money: 250, career: 15, relationships: 15, happiness: 20, log: 'Vendió su cerámica en el mercadito del barrio'},
      },
      {
        key: 'C',
        label: 'Dejarlo para otro día',
        description: 'Ahorras, pero te quedas con la duda.',
        effect: {money: 60, happiness: -5, log: 'Dejó pasar el curso de cerámica'},
      },
    ],
  },

  // ---------- ETAPA 4 ----------
  {
    id: 'e4_reencuentro_secundaria',
    stage: 4,
    title: 'REENCUENTRO DE LA SECUNDARIA',
    subtitle: 'Veinte años después, todos fingen estar mejor que tú.',
    situation: 'Organizan una cena para ver quién cambió más.',
    category: 'friendship',
    options: [
      {
        key: 'A',
        label: 'Ir y contar la verdad de tu vida',
        description: 'Todos se relajan y se ríen contigo.',
        effect: {relationships: 35, happiness: 30, log: 'Se reencontró con sus compañeros de secundaria'},
      },
      {
        key: 'B',
        label: 'Llegar en un auto prestado para impresionar',
        description: 'Funciona hasta que pide la cuenta.',
        effect: {money: -250, happiness: 5, adventures: 10, log: 'Presumió un auto prestado en el reencuentro'},
      },
      {
        key: 'C',
        label: 'Proponer un viaje juntos',
        description: 'La cena termina en planes de aventura.',
        effect: {money: -150, adventures: 35, relationships: 25, happiness: 30, log: 'Organizó un viaje con sus viejos compañeros'},
      },
    ],
  },
  {
    id: 'e4_mentora_jovenes',
    stage: 4,
    title: 'UNA JOVEN TE PIDE CONSEJO',
    subtitle: 'Cree que ya lo sabes todo.',
    situation: 'Una chica de veintitantos quiere que le cuentes cómo se hace la vida.',
    category: 'life_change',
    options: [
      {
        key: 'A',
        label: 'Ser su mentora cada semana',
        description: 'Aprendes tanto como enseñas.',
        effect: {energy: -1, career: 20, relationships: 35, happiness: 40, log: 'Fue mentora de una joven que empezaba su vida'},
      },
      {
        key: 'B',
        label: 'Darle tres frases y un chocolate',
        description: 'Corto, dulce y suficiente.',
        effect: {happiness: 20, relationships: 10, log: 'Le dio un consejo breve y un chocolate'},
      },
      {
        key: 'C',
        label: 'Escribir un libro con todo lo vivido',
        description: 'Te toma meses, pero queda precioso.',
        effect: {money: 400, energy: -1, career: 30, happiness: 35, log: 'Escribió un libro con las lecciones de su vida'},
      },
    ],
  },
  {
    id: 'e4_tormenta_casa',
    stage: 4,
    title: 'UNA TORMENTA TE DEJA SIN LUZ',
    subtitle: 'El techo gotea justo sobre tu sofá favorito.',
    situation: 'Toda la calle queda a oscuras y los vecinos salen con velas.',
    category: 'crisis',
    options: [
      {
        key: 'A',
        label: 'Organizar una cena a la luz de las velas',
        description: 'La calle entera comparte lo que tiene.',
        effect: {relationships: 40, happiness: 35, log: 'Hizo una cena de vecinos a la luz de las velas'},
      },
      {
        key: 'B',
        label: 'Arreglar el techo tú misma',
        description: 'Aprendes algo útil y te duele la espalda.',
        effect: {money: -200, energy: -1, career: 10, happiness: 15, log: 'Reparó su propio techo bajo la lluvia'},
      },
      {
        key: 'C',
        label: 'Mudarte unos días a la playa',
        description: 'Escapas de la tormenta con una maleta.',
        effect: {money: -300, energy: 2, adventures: 25, happiness: 30, log: 'Huyó de la tormenta con unos días de playa'},
      },
    ],
  },
  {
    id: 'e4_festival_pueblo',
    stage: 4,
    title: 'EL FESTIVAL DEL PUEBLO NECESITA ORGANIZADORA',
    subtitle: 'Nadie quiere, todos opinan.',
    situation: 'La alcaldesa te mira fijamente mientras reparte las tareas.',
    category: 'fame',
    options: [
      {
        key: 'A',
        label: 'Aceptar y poner música para todos',
        description: 'El festival es un éxito rotundo.',
        effect: {money: 300, energy: -1, reputation: 20, relationships: 30, happiness: 35, log: 'Organizó el festival del pueblo con enorme éxito'},
      },
      {
        key: 'B',
        label: 'Ayudar solo con la comida',
        description: 'Cocinas y desapareces entre los puestos.',
        effect: {money: 100, happiness: 20, relationships: 15, log: 'Cocinó para el festival del pueblo'},
      },
      {
        key: 'C',
        label: 'Esconderte entre los globos',
        description: 'No te salvas, pero te ríes.',
        effect: {happiness: 10, energy: 1, log: 'Se escondió entre globos para no organizar el festival'},
      },
    ],
  },

  // ---------- ETAPA 5 ----------
  {
    id: 'e5_carta_a_ti',
    stage: 5,
    title: 'UNA CARTA DE TU YO MÁS JOVEN',
    subtitle: 'La escribiste hace años y la olvidaste.',
    situation: 'Encuentras un sobre arrugado con tu letra de veintitantos.',
    category: 'life_change',
    options: [
      {
        key: 'A',
        label: 'Leerla en voz alta con una sonrisa',
        description: 'Casi todo lo que soñabas se cumplió, a su manera.',
        effect: {happiness: 40, log: 'Leyó una carta que le escribió su yo más joven'},
      },
      {
        key: 'B',
        label: 'Contestarle con otra carta',
        description: 'Le cuentas que todo va a estar bien.',
        effect: {happiness: 35, relationships: 10, log: 'Le respondió a su yo más joven'},
      },
      {
        key: 'C',
        label: 'Guardarla para abrirla más tarde',
        description: 'Hay cosas que se leen cuando llega el momento.',
        effect: {energy: 1, happiness: 20, log: 'Guardó la carta de su yo joven para más adelante'},
      },
    ],
  },
  {
    id: 'e5_cena_amigos',
    stage: 5,
    title: 'LA CENA CON TODA TU GENTE',
    subtitle: 'Amigos, familia y gatos cuya procedencia nadie recuerda.',
    situation: 'Preparan una mesa enorme en tu honor. Falta que digas unas palabras.',
    category: 'friendship',
    options: [
      {
        key: 'A',
        label: 'Brindar por todos los que te acompañaron',
        description: 'Se juntan lágrimas, risas y más postre.',
        effect: {relationships: 40, happiness: 40, log: 'Brindó rodeada de toda su gente'},
      },
      {
        key: 'B',
        label: 'Tocar una canción improvisada',
        description: 'Desafina, pero nadie quiere que pare.',
        effect: {adventures: 20, happiness: 35, relationships: 20, log: 'Improvisó una canción en la cena de despedida'},
      },
      {
        key: 'C',
        label: 'Servir el postre y no decir nada',
        description: 'A veces el pastel habla mejor.',
        effect: {happiness: 25, relationships: 20, log: 'Dejó que el postre hablara por ella'},
      },
    ],
  },
  {
    id: 'e5_ultimo_viaje',
    stage: 5,
    title: 'UN ÚLTIMO VIAJE SIN PLAN',
    subtitle: 'Un mapa viejo y una mochila ligera.',
    situation: 'Hay un tren que sale en una hora hacia un lugar que no conoces.',
    category: 'travel',
    options: [
      {
        key: 'A',
        label: 'Subir al tren sin pensarlo',
        description: 'Todo se arregla en el camino.',
        effect: {money: -150, adventures: 35, happiness: 35, log: 'Tomó un tren sin destino ni plan'},
      },
      {
        key: 'B',
        label: 'Invitar a alguien querido',
        description: 'El paisaje se disfruta el doble.',
        effect: {money: -200, adventures: 25, relationships: 30, happiness: 35, log: 'Viajó en tren con alguien muy querido'},
      },
      {
        key: 'C',
        label: 'Quedarte mirando pasar los trenes',
        description: 'También se vive desde el andén.',
        effect: {energy: 1, happiness: 20, log: 'Se quedó mirando pasar los trenes'},
      },
    ],
  },
  {
    id: 'e5_huerto_final',
    stage: 5,
    title: 'EL HUERTO QUE NUNCA PLANTASTE',
    subtitle: 'Hay una semilla en tu bolsillo y mucho sol.',
    situation: 'El jardín está vacío y la tierra, lista.',
    category: 'life_change',
    options: [
      {
        key: 'A',
        label: 'Plantarla con paciencia',
        description: 'Verás florecer algo que tarda años.',
        effect: {energy: 1, happiness: 35, log: 'Plantó un árbol que tardará años en crecer'},
      },
      {
        key: 'B',
        label: 'Regalar la semilla a tus vecinos',
        description: 'Pronto la calle está llena de verde.',
        effect: {relationships: 30, happiness: 30, log: 'Repartió semillas entre sus vecinos'},
      },
      {
        key: 'C',
        label: 'Poner una hamaca y mirar el cielo',
        description: 'Ya tendrás tiempo para sembrar mañana.',
        effect: {energy: 2, happiness: 25, log: 'Se tumbó en una hamaca a mirar las nubes'},
      },
    ],
  },
  {
    id: 'e5_foto_familiar',
    stage: 5,
    title: 'LA FOTO FAMILIAR DE TODOS LOS AÑOS',
    subtitle: 'Alguien siempre sale parpadeando.',
    situation: 'Todos se acomodan, el temporizador corre y falta un lugar a tu lado.',
    category: 'family',
    options: [
      {
        key: 'A',
        label: 'Sentarte en medio y sonreír',
        description: 'Sales perfecta, aunque con la boca abierta.',
        effect: {relationships: 30, happiness: 35, log: 'Posó en la foto familiar de todos los años'},
      },
      {
        key: 'B',
        label: 'Sacar la foto tú misma desde lejos',
        description: 'Capturas el momento con toda la gente riendo.',
        effect: {adventures: 10, relationships: 20, happiness: 30, log: 'Retrató a su familia riendo desde lejos'},
      },
      {
        key: 'C',
        label: 'Pedirle a un perro que apriete el botón',
        description: 'El resultado es memorable.',
        effect: {happiness: 30, adventures: 15, log: 'Dejó que un perro sacara la foto familiar'},
      },
    ],
  },
];

export const GAME_EVENTS: BoardEvent[] = [...BASE_EVENTS, ...EXTRA_EVENTS];
