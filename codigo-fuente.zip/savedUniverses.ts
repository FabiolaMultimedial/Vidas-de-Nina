import {EndingUniverse, NinaStats, SavedUniverse} from './types';

const STORAGE_KEY = 'las_mil_vidas_de_nina_universos';

export function getSavedUniverses(): SavedUniverse[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    console.warn('Error reading saved universes:', e);
    return [];
  }
}

export function saveUniverseResult(
  ending: EndingUniverse,
  stats: NinaStats,
  storyTimeline: string[],
): SavedUniverse {
  const all = getSavedUniverses();

  const newEntry: SavedUniverse = {
    id: ending.id,
    universeCode: ending.universeCode,
    shortName: ending.shortName,
    title: ending.title,
    quote: ending.quote,
    profession: ending.profession,
    wealthLevel: ending.wealthLevel,
    lifestyle: ending.lifestyle,
    happiness: stats.happiness,
    adventures: stats.adventures,
    energy: stats.energy,
    fortune: stats.money,
    storyTimeline,
    date: new Date().toLocaleDateString('es-ES', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    }),
    accentColor: ending.accentColor,
    visual: ending.visual,
  };

  const existingIdx = all.findIndex((u) => u.id === ending.id);
  if (existingIdx >= 0) {
    all[existingIdx] = newEntry;
  } else {
    all.unshift(newEntry);
  }

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
  } catch (e) {
    console.warn('Error saving universe:', e);
  }

  return newEntry;
}
