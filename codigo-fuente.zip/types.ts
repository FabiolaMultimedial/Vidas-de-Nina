// tslint:disable
/* eslint-disable */
/** 3D Vector. */
export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

/** 3D Position as a tuple. */
export type Position3D = [number, number, number];

/** Represents an object in the 3D scene. */
export interface Entity3D {
  id: string | number;
  type?: string;
  position: Vec3 | Position3D;
  rotation?: Vec3 | Position3D;
  scale?: Vec3 | Position3D;
  velocity?: Vec3;
  active?: boolean;
  [key: string]: any;
}

/** Represents a particle in a particle system. */
export interface Particle {
  id: string | number;
  position: Vec3 | Position3D;
  velocity?: Vec3 | Position3D;
  life: number;
  maxLife: number;
  color?: string;
  size?: number;
  [key: string]: any;
}

/** Internal variables tracking Nina's trajectory */
export interface NinaStats {
  money: number;
  happiness: number;
  energy: number; // 1 to 5 (cinco corazones de vitalidad)
  career: number;
  relationships: number;
  adventures: number;
  luck?: number;
  risk?: number;
  reputation?: number;
}

/** Decision option effect */
export interface DecisionEffect {
  money?: number;
  happiness?: number;
  energy?: number; // delta in energy (-2, -1, 0, +1, +2)
  career?: number;
  relationships?: number;
  adventures?: number;
  luck?: number;
  risk?: number;
  reputation?: number;
  tag?: string;
  log?: string;
}

export interface DecisionOption {
  key: 'A' | 'B' | 'C';
  label: string;
  description: string;
  effect: DecisionEffect;
}

export type EventCategory =
  | 'work'
  | 'money'
  | 'love'
  | 'friendship'
  | 'travel'
  | 'impulsive'
  | 'absurd'
  | 'crisis'
  | 'fame'
  | 'family'
  | 'life_change'
  | 'extraordinary';

export interface BoardEvent {
  id: string;
  stage: 1 | 2 | 3 | 4 | 5;
  title: string;
  subtitle?: string;
  situation: string;
  category: EventCategory;
  options: DecisionOption[];
  requiresTag?: string; // Appears only if a previous choice unlocked this tag
  excludesTag?: string; // Appears only if tag is NOT present
}

export interface TileData {
  index: number;
  position: [number, number, number];
  stage: 1 | 2 | 3 | 4 | 5;
  type: 'start' | 'career' | 'love' | 'money' | 'adventure' | 'twist' | 'goal';
  label: string;
  color: string;
  accentColor: string;
}

export interface NinaVisualConfig {
  skinColor: string;
  hairColor: string;
  outfitColor: string;
  pantsColor: string;
  accessory: 'none' | 'glasses' | 'sunglasses' | 'crown' | 'backpack' | 'cat' | 'hat' | 'scarf' | 'chef';
  auraColor?: string;
}

export interface EndingUniverse {
  id: string;
  universeCode: string;
  shortName: string; // e.g. "La magnate accidental", "La reina de los gatos"
  title: string;
  quote: string;
  profession: string;
  wealthLevel: string;
  lifestyle: string;
  summary: string;
  bgGradient: [string, string];
  accentColor: string;
  visual: NinaVisualConfig;
  requirements?: (stats: NinaStats, tags: string[]) => boolean;
}

export interface SavedUniverse {
  id: string;
  universeCode: string;
  shortName: string;
  title: string;
  quote: string;
  profession: string;
  wealthLevel: string;
  lifestyle: string;
  happiness: number;
  adventures: number;
  energy: number;
  fortune: number;
  storyTimeline: string[];
  date: string;
  accentColor: string;
  visual: NinaVisualConfig;
}
