import ts from 'typescript';
import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
async function load(file) {
  const {outputText} = ts.transpileModule(readFileSync(file,'utf8'), {compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}});
  return import('data:text/javascript;base64,'+Buffer.from(outputText).toString('base64'));
}
const {determineEnding,ALL_ENDINGS} = await load('endingsData.ts');
const {GAME_EVENTS} = await load('eventsData.ts');
const base={money:1000,happiness:70,energy:4,career:20,relationships:30,adventures:15};
const fixtures = [
 ['magnate_accidental',['wealthy_investor'],{money:4000,career:65}],
 ['reina_gatos',['first_cat','cat_queen'],{}],
 ['duena_cafeteria',['cafe_owner'],{}],
 ['chef_estelar',['master_chef'],{career:65}],
 ['celeb_accidental',['viral_celebrity'],{money:2600,career:50}],
 ['reina_alpacas',['alpaca_dream'],{adventures:50}],
 ['viajera_eterna',['wanderlust_init'],{adventures:75}],
 ['capitana_mar',['sea_captain'],{adventures:85}],
 ['directora_ejecutiva',['corporate_ladder','tech_savvy','green_ceo'],{career:100,money:3000}],
 ['bancarrota_dramatica',[],{money:0}],
 ['rica_pero_estresada',[],{money:3500,energy:1}],
 ['campeona_siesta',['deep_rest'],{energy:5}],
 ['frente_al_mar',['ocean_life'],{adventures:80}],
 ['vida_bohemia_feliz',['artisan_soul'],{}],
 ['vida_sencilla_feliz',[],{happiness:90,relationships:80,energy:3}],
];
for (const [id,tags,stats] of fixtures) assert.equal(determineEnding({...base,...stats},tags).id,id);
assert.equal(determineEnding({...base,money:4000,career:70},['crypto_ruined','wealthy_investor']).id,'magnate_accidental');
assert.equal(determineEnding({...base,money:3000,career:65},['viral_celebrity']).id,'celeb_accidental');
assert.equal(determineEnding({...base,adventures:90},['first_cat','sea_captain']).id,'capitana_mar');
// Reproducible full-game simulation: dice, eligible events, choices, clamped stats.
let seed=123456;const random=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
const distribution={};
for(let run=0;run<20000;run++){
 let stats={...base},tags=[],seen=[],tile=1;
 while(tile<50){
  tile=Math.min(50,tile+1+Math.floor(random()*6));if(tile===50)break;
  const stage=Math.min(5,Math.floor((tile-1)/10)+1);
  const eligible=GAME_EVENTS.filter(e=>e.stage===stage&&(!e.requiresTag||tags.includes(e.requiresTag))&&(!e.excludesTag||!tags.includes(e.excludesTag)));
  const unplayed=eligible.filter(e=>!seen.includes(e.id));const pool=unplayed;
  const event=pool[Math.floor(random()*pool.length)];if(!event)continue;seen.push(event.id);
  const effect=event.options[Math.floor(random()*event.options.length)].effect;
  for(const key of Object.keys(stats))stats[key]=Math.max(key==='energy'?1:0,Math.min(key==='money'?Infinity:key==='energy'?5:100,stats[key]+(effect[key]||0)));
  if(effect.tag&&!tags.includes(effect.tag))tags.push(effect.tag);
 }
 const ending=determineEnding(stats,tags).id;distribution[ending]=(distribution[ending]||0)+1;
 assert.equal(determineEnding(stats,tags).id,ending);
}
console.log(distribution);

assert.equal(Object.keys(distribution).length,ALL_ENDINGS.length,'All endings reachable in simulated games');
assert.ok(distribution.vida_sencilla_feliz/20000<0.15,'Calm ending does not dominate');
console.log('Passed: 15 destination profiles, regression cases, determinism and 20,000 simulated games.');
console.log(distribution);
